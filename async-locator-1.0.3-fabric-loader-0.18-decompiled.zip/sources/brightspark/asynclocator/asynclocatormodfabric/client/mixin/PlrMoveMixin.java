package brightspark.asynclocator.asynclocatormodfabric.client.mixin;

import brightspark.asynclocator.asynclocatormodfabric.client.SilentRot;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin({ClientPlayerEntity.class})
public abstract class PlrMoveMixin {
   @Unique
   private boolean al$save;
   @Unique
   private float al$y;
   @Unique
   private float al$p;
   @Unique
   private float al$ly;
   @Unique
   private float al$lp;
   @Unique
   private boolean al$mv;
   @Unique
   private float al$my;
   @Unique
   private float al$mp;
   @Unique
   private float al$mly;
   @Unique
   private float al$mlp;
   @Unique
   private float al$ry;
   @Unique
   private float al$lry;
   @Unique
   private float al$rp;
   @Unique
   private float al$lrp;
   @Unique
   private float al$by;
   @Unique
   private float al$hy;
   @Unique
   private float al$lby;
   @Unique
   private float al$lhy;

   @Inject(
      method = {"tickMovement"},
      at = {@At("HEAD")}
   )
   private void al$tmHead(CallbackInfo ci) {
      if (SilentRot.on()) {
         ClientPlayerEntity p = (ClientPlayerEntity)this;
         this.al$my = p.getYaw();
         this.al$mp = p.getPitch();
         this.al$mly = p.lastYaw;
         this.al$mlp = p.lastPitch;
         this.al$ry = p.renderYaw;
         this.al$lry = p.lastRenderYaw;
         this.al$rp = p.renderPitch;
         this.al$lrp = p.lastRenderPitch;
         this.al$by = p.bodyYaw;
         this.al$hy = p.headYaw;
         this.al$lby = p.lastBodyYaw;
         this.al$lhy = p.lastHeadYaw;
         this.al$mv = true;
         SilentRot.beginMove(this.al$my);
         float wy = SilentRot.yaw();
         float wp = SilentRot.pitch();
         p.setYaw(wy);
         p.setPitch(wp);
         p.lastYaw = wy;
         p.lastPitch = wp;
      }
   }

   @Inject(
      method = {"tickMovement"},
      at = {@At("TAIL")}
   )
   private void al$tmTail(CallbackInfo ci) {
      if (this.al$mv) {
         ClientPlayerEntity p = (ClientPlayerEntity)this;
         p.setYaw(this.al$my);
         p.setPitch(this.al$mp);
         p.lastYaw = this.al$mly;
         p.lastPitch = this.al$mlp;
         p.renderYaw = this.al$ry;
         p.lastRenderYaw = this.al$lry;
         p.renderPitch = this.al$rp;
         p.lastRenderPitch = this.al$lrp;
         p.bodyYaw = this.al$by;
         p.headYaw = this.al$hy;
         p.lastBodyYaw = this.al$lby;
         p.lastHeadYaw = this.al$lhy;
         SilentRot.endMove();
         this.al$mv = false;
      }
   }

   @Inject(
      method = {"sendMovementPackets"},
      at = {@At("HEAD")}
   )
   private void al$smHead(CallbackInfo ci) {
      if (SilentRot.on()) {
         ClientPlayerEntity p = (ClientPlayerEntity)this;
         this.al$y = p.getYaw();
         this.al$p = p.getPitch();
         this.al$ly = p.lastYaw;
         this.al$lp = p.lastPitch;
         this.al$save = true;
         float wy = SilentRot.yaw();
         float wp = SilentRot.pitch();
         p.setYaw(wy);
         p.setPitch(wp);
         p.lastYaw = wy;
         p.lastPitch = wp;
      }
   }

   @Inject(
      method = {"sendMovementPackets"},
      at = {@At("TAIL")}
   )
   private void al$smTail(CallbackInfo ci) {
      if (this.al$save) {
         ClientPlayerEntity p = (ClientPlayerEntity)this;
         p.setYaw(this.al$y);
         p.setPitch(this.al$p);
         p.lastYaw = this.al$ly;
         p.lastPitch = this.al$lp;
         this.al$save = false;
      }
   }
}
