package brightspark.asynclocator.asynclocatormodfabric.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
public record Rot(double yaw, double pitch) {
}
