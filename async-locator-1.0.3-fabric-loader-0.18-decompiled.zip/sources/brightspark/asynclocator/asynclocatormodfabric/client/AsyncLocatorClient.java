package brightspark.asynclocator.asynclocatormodfabric.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.KeyBinding.Category;
import net.minecraft.client.util.InputUtil.Type;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public class AsyncLocatorClient implements ClientModInitializer {
   public static KeyBinding key;
   private static final b catcher = new b();

   public void onInitializeClient() {
      Category cat = Category.create(Identifier.of("asynclocator", "main"));
      key = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.async-locator.async", Type.MOUSE, 2, cat));
   }

   public static void onClientTick() {
      catcher.f();
   }

   public static boolean held() {
      return key != null && key.isPressed();
   }
}
