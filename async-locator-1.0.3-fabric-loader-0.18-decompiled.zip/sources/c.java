import java.util.HashMap;
import java.util.Map;

public class c {
   static Map a = new HashMap();

   public static int a(Object object, int i) {
      return (Integer)a.get(object) ^ i;
   }
}
