import brightspark.asynclocator.asynclocatormodfabric.client.AsyncLocatorClient;
import brightspark.asynclocator.asynclocatormodfabric.client.Rot;
import brightspark.asynclocator.asynclocatormodfabric.client.SilentRot;
import brightspark.asynclocator.asynclocatormodfabric.client.mixin.SlotSync;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

@Environment(EnvType.CLIENT)
public final class b {
   private static final int h = 20;
   private int m;
   private static final float f = 4.0F;
   private static final int j = 60;
   private static final double c = 1.5;
   private long a;
   private int d;
   private static final boolean b = true;
   private static final double f = 0.2;
   private int t;
   private int i;
   private float b;
   private static final int f = 2;
   private final MinecraftClient a = MinecraftClient.getInstance();
   private float d;
   private int k;
   private static final double e = 0.03;
   private Vec3d b;
   private static final int l = 3;
   private int c;
   private static final boolean d = true;
   private int q;
   private boolean a;
   private float e;
   private static final int a = 0;
   private static final boolean c = false;
   private static final int r = 6;
   private static final float a = 60.0F;
   private boolean e;
   private static final int g = 5;
   private static final int o = 4;
   private int n;
   private float c;
   private static final double g = 0.0;
   private static final double b = 10.0;
   private static final double a = 0.99;
   private static final int p = 2;
   private static final int s = 100;
   private int b = 0;
   private static final double d = 1.0;
   private Vec3d a;
   private static final int e = 1;
   private static final String a = "By HitsOnly";
   private static final String b = "By HitsOnly";
   private static final String c = "By HitsOnly";
   private static final String d = "By HitsOnly";
   private static final String e = "By HitsOnly";
   private static final String f = "By HitsOnly";
   private static final String g = "By HitsOnly";
   private static final String h = "By HitsOnly";
   private static final String i = "By HitsOnly";
   private static final String j = "By HitsOnly";
   private static final String k = "By HitsOnly";
   private static final String l = "By HitsOnly";
   private static final String m = "By HitsOnly";
   private static final String n = "By HitsOnly";
   private static final String o = "By HitsOnly";
   private static final String p = "By HitsOnly";
   private static final String q = "By HitsOnly";
   private static final String r = "By HitsOnly";
   private static final String s = "By HitsOnly";
   private static final String t = "By HitsOnly";
   private static final String u = "By HitsOnly";
   private static final String v = "By HitsOnly";
   private static final String w = "By HitsOnly";
   private static final String x = "By HitsOnly";
   private static final String y = "By HitsOnly";
   private static final String z = "By HitsOnly";
   private static final String A = "By HitsOnly";
   private static final String B = "By HitsOnly";
   private static final String C = "By HitsOnly";
   private static final String D = "By HitsOnly";
   private static final String E = "By HitsOnly";
   private static final String F = "By HitsOnly";
   private static final String G = "By HitsOnly";
   private static final String H = "By HitsOnly";
   private static final String I = "By HitsOnly";
   private static final String J = "By HitsOnly";
   private static final String K = "By HitsOnly";
   private static final String L = "By HitsOnly";
   private static final String M = "By HitsOnly";
   private static final String N = "By HitsOnly";
   private static final String O = "By HitsOnly";
   private static final String P = "By HitsOnly";
   private static final String Q = "By HitsOnly";
   private static final String R = "By HitsOnly";
   private static final String S = "By HitsOnly";
   private static final String T = "By HitsOnly";
   private static final String U = "By HitsOnly";
   private static final String V = "By HitsOnly";
   private static final String W = "By HitsOnly";
   private static final String X = "By HitsOnly";
   private static final String Y = "By HitsOnly";
   private static final String Z = "By HitsOnly";
   private static final String 0 = "By HitsOnly";
   private static final String 1 = "By HitsOnly";
   private static final String 2 = "By HitsOnly";
   private static final String 3 = "By HitsOnly";
   private static final String 4 = "By HitsOnly";
   private static final String 5 = "By HitsOnly";
   private static final String 6 = "By HitsOnly";
   private static final String 7 = "By HitsOnly";
   private static final String 8 = "By HitsOnly";
   private static final String 9 = "By HitsOnly";
   private static final String _ = "By HitsOnly";
   private static final String $ = "By HitsOnly";
   private static final String aa = "By HitsOnly";
   private static final String ab = "By HitsOnly";
   private static final String ac = "By HitsOnly";
   private static final String ad = "By HitsOnly";
   private static final String ae = "By HitsOnly";
   private static final String af = "By HitsOnly";
   private static final String ag = "By HitsOnly";
   private static final String ah = "By HitsOnly";
   private static final String ai = "By HitsOnly";
   private static final String aj = "By HitsOnly";
   private static final String ak = "By HitsOnly";
   private static final String al = "By HitsOnly";
   private static final String am = "By HitsOnly";
   private static final String an = "By HitsOnly";
   private static final String ao = "By HitsOnly";
   private static final String ap = "By HitsOnly";
   private static final String aq = "By HitsOnly";
   private static final String ar = "By HitsOnly";
   private static final String as = "By HitsOnly";
   private static final String at = "By HitsOnly";
   private static final String au = "By HitsOnly";
   private static final String av = "By HitsOnly";
   private static final String aw = "By HitsOnly";
   private static final String ax = "By HitsOnly";
   private static final String ay = "By HitsOnly";
   private static final String az = "By HitsOnly";
   private static final String aA = "By HitsOnly";
   private static final String aB = "By HitsOnly";
   private static final String aC = "By HitsOnly";
   private static final String aD = "By HitsOnly";
   private static final String aE = "By HitsOnly";
   private static final String aF = "By HitsOnly";
   private static final String aG = "By HitsOnly";
   private static final String aH = "By HitsOnly";
   private static final String aI = "By HitsOnly";
   private static final String aJ = "By HitsOnly";
   private static final String aK = "By HitsOnly";
   private static final String aL = "By HitsOnly";
   private static final String aM = "By HitsOnly";
   private static final String aN = "By HitsOnly";
   private static final String aO = "By HitsOnly";
   private static final String aP = "By HitsOnly";
   private static final String aQ = "By HitsOnly";
   private static final String aR = "By HitsOnly";
   private static final String aS = "By HitsOnly";
   private static final String aT = "By HitsOnly";
   private static final String aU = "By HitsOnly";
   private static final String aV = "By HitsOnly";
   private static final String aW = "By HitsOnly";
   private static final String aX = "By HitsOnly";
   private static final String aY = "By HitsOnly";
   private static final String aZ = "By HitsOnly";
   private static final String a0 = "By HitsOnly";
   private static final String a1 = "By HitsOnly";
   private static final String a2 = "By HitsOnly";
   private static final String a3 = "By HitsOnly";
   private static final String a4 = "By HitsOnly";
   private static final String a5 = "By HitsOnly";
   private static final String a6 = "By HitsOnly";
   private static final String a7 = "By HitsOnly";
   private static final String a8 = "By HitsOnly";
   private static final String a9 = "By HitsOnly";
   private static final String a_ = "By HitsOnly";
   private static final String a$ = "By HitsOnly";
   private static final String ba = "By HitsOnly";
   private static final String bb = "By HitsOnly";
   private static final String bc = "By HitsOnly";
   private static final String bd = "By HitsOnly";
   private static final String be = "By HitsOnly";
   private static final String bf = "By HitsOnly";
   private static final String bg = "By HitsOnly";
   private static final String bh = "By HitsOnly";
   private static final String bi = "By HitsOnly";
   private static final String bj = "By HitsOnly";
   private static final String bk = "By HitsOnly";
   private static final String bl = "By HitsOnly";
   private static final String bm = "By HitsOnly";
   private static final String bn = "By HitsOnly";
   private static final String bo = "By HitsOnly";
   private static final String bp = "By HitsOnly";
   private static final String bq = "By HitsOnly";
   private static final String br = "By HitsOnly";
   private static final String bs = "By HitsOnly";
   private static final String bt = "By HitsOnly";
   private static final String bu = "By HitsOnly";
   private static final String bv = "By HitsOnly";
   private static final String bw = "By HitsOnly";
   private static final String bx = "By HitsOnly";
   private static final String by = "By HitsOnly";
   private static final String bz = "By HitsOnly";
   private static final String bA = "By HitsOnly";
   private static final String bB = "By HitsOnly";
   private static final String bC = "By HitsOnly";
   private static final String bD = "By HitsOnly";
   private static final String bE = "By HitsOnly";
   private static final String bF = "By HitsOnly";
   private static final String bG = "By HitsOnly";
   private static final String bH = "By HitsOnly";
   private static final String bI = "By HitsOnly";
   private static final String bJ = "By HitsOnly";
   private static final String bK = "By HitsOnly";
   private static final String bL = "By HitsOnly";
   private static final String bM = "By HitsOnly";
   private static final String bN = "By HitsOnly";
   private static final String bO = "By HitsOnly";
   private static final String bP = "By HitsOnly";
   private static final String bQ = "By HitsOnly";
   private static final String bR = "By HitsOnly";
   private static final String bS = "By HitsOnly";
   private static final String bT = "By HitsOnly";
   private static final String bU = "By HitsOnly";
   private static final String bV = "By HitsOnly";
   private static final String bW = "By HitsOnly";
   private static final String bX = "By HitsOnly";
   private static final String bY = "By HitsOnly";
   private static final String bZ = "By HitsOnly";
   private static final String b0 = "By HitsOnly";
   private static final String b1 = "By HitsOnly";
   private static final String b2 = "By HitsOnly";
   private static final String b3 = "By HitsOnly";
   private static final String b4 = "By HitsOnly";
   private static final String b5 = "By HitsOnly";
   private static final String b6 = "By HitsOnly";
   private static final String b7 = "By HitsOnly";
   private static final String b8 = "By HitsOnly";
   private static final String b9 = "By HitsOnly";
   private static final String b_ = "By HitsOnly";
   private static final String b$ = "By HitsOnly";
   private static final String ca = "By HitsOnly";
   private static final String cb = "By HitsOnly";
   private static final String cc = "By HitsOnly";
   private static final String cd = "By HitsOnly";
   private static final String ce = "By HitsOnly";
   private static final String cf = "By HitsOnly";
   private static final String cg = "By HitsOnly";
   private static final String ch = "By HitsOnly";
   private static final String ci = "By HitsOnly";
   private static final String cj = "By HitsOnly";
   private static final String ck = "By HitsOnly";
   private static final String cl = "By HitsOnly";
   private static final String cm = "By HitsOnly";
   private static final String cn = "By HitsOnly";
   private static final String co = "By HitsOnly";
   private static final String cp = "By HitsOnly";
   private static final String cq = "By HitsOnly";
   private static final String cr = "By HitsOnly";
   private static final String cs = "By HitsOnly";
   private static final String ct = "By HitsOnly";
   private static final String cu = "By HitsOnly";
   private static final String cv = "By HitsOnly";
   private static final String cw = "By HitsOnly";
   private static final String cx = "By HitsOnly";
   private static final String cy = "By HitsOnly";
   private static final String cz = "By HitsOnly";
   private static final String cA = "By HitsOnly";
   private static final String cB = "By HitsOnly";
   private static final String cC = "By HitsOnly";
   private static final String cD = "By HitsOnly";
   private static final String cE = "By HitsOnly";
   private static final String cF = "By HitsOnly";
   private static final String cG = "By HitsOnly";
   private static final String cH = "By HitsOnly";
   private static final String cI = "By HitsOnly";
   private static final String cJ = "By HitsOnly";
   private static final String cK = "By HitsOnly";
   private static final String cL = "By HitsOnly";
   private static final String cM = "By HitsOnly";
   private static final String cN = "By HitsOnly";
   private static final String cO = "By HitsOnly";
   private static final String cP = "By HitsOnly";
   private static final String cQ = "By HitsOnly";
   private static final String cR = "By HitsOnly";
   private static final String cS = "By HitsOnly";
   private static final String cT = "By HitsOnly";
   private static final String cU = "By HitsOnly";
   private static final String cV = "By HitsOnly";
   private static final String cW = "By HitsOnly";
   private static final String cX = "By HitsOnly";
   private static final String cY = "By HitsOnly";
   private static final String cZ = "By HitsOnly";
   private static final String c0 = "By HitsOnly";
   private static final String c1 = "By HitsOnly";
   private static final String c2 = "By HitsOnly";
   private static final String c3 = "By HitsOnly";
   private static final String c4 = "By HitsOnly";
   private static final String c5 = "By HitsOnly";

   private void h() {
      this.a = this.a();
   }

   private boolean a() {
      if (this.a.world != null && this.i >= 0) {
         double var1 = this.b();
         Vec3d var3 = this.a.player.getMovement();
         double var4 = var3.y;
         if (!this.a.player.isGliding()) {
            int var6 = (int)var1;

            for (int var7 = 0; var7 < var6; var7++) {
               var4 = (var4 - 0.08) * 0.98;
            }

            double var21 = var1 - var6;
            if (var21 > 0.0) {
               var4 += ((var4 - 0.08) * 0.98 - var4) * var21;
            }
         }

         Vec3d var20 = new Vec3d(var3.x, this.a.player.isOnGround() ? 0.0 : var4, var3.z);
         Vec3d var22 = new Vec3d(this.a.player.getX(), this.a.player.getEyeY(), this.a.player.getZ()).add(var3.x * var1, var3.y * var1, var3.z * var1);
         double var8 = this.a.player.age - this.i + var1;
         if (var8 < 0.0) {
            var8 = 0.0;
         }

         Vec3d var10 = this.a;
         Vec3d var11 = this.b;
         int var12 = (int)var8;

         for (int var13 = 0; var13 < var12; var13++) {
            var11 = new Vec3d(var11.x, var11.y - 0.03, var11.z).multiply(0.99);
            var10 = var10.add(var11);
         }

         double var23 = var8 - var12;
         if (var23 > 0.0) {
            Vec3d var15 = new Vec3d(var11.x, var11.y - 0.03, var11.z).multiply(0.99);
            var10 = var10.add(var15.multiply(var23));
         }

         double var24 = this.a(var22, var20, var10, var11);
         if (var24 <= 0.0) {
            return false;
         } else {
            Vec3d var17 = this.a(var10, var11, var24);
            var17 = new Vec3d(var17.x, var17.y - 0.2, var17.z);
            Vec3d var18 = var17.subtract(var22).subtract(var20.multiply(var24));
            if (var18.lengthSquared() < 1.0E-6) {
               return false;
            } else {
               Rot var19 = a.a(var18);
               this.d = (float)var19.yaw();
               this.b = MathHelper.clamp((float)var19.pitch(), -90.0F, 90.0F);
               return true;
            }
         }
      } else {
         return false;
      }
   }

   public void f() {
      if (this.a.player == null || this.a.world == null) {
         SilentRot.stop(this);
         this.t = -1;
         this.q = -1;
      } else if (this.a.currentScreen != null) {
         if (this.b != 0) {
            this.b();
         }

         this.c();
      } else {
         boolean var1 = AsyncLocatorClient.held();
         if (this.b == 0 && var1 && !this.a) {
            this.d();
         }

         this.a = var1;
         if (this.b != 0 && this.c >= 0 && this.a.player.age - this.c > 60) {
            this.b();
         }

         if (this.q >= 0) {
            if (this.a.player.age < this.q) {
               this.a();
            } else {
               this.c();
            }
         }

         switch (this.b) {
            case 1:
               int var4 = this.a(Items.ENDER_PEARL);
               if (var4 < 0) {
                  this.b();
               } else {
                  this.a(var4);
                  this.b = 2;
                  this.h();
               }
               break;
            case 2:
               if (this.q < 0 && this.a(this.c())) {
                  if (this.a.player.getMainHandStack().getItem() == Items.ENDER_PEARL) {
                     this.a.interactionManager.interactItem(this.a.player, Hand.MAIN_HAND);
                     Vec3d var3 = this.a.player.getMovement();
                     this.a = new Vec3d(this.a.player.getX(), this.a.player.getEyeY(), this.a.player.getZ());
                     this.b = a.a(this.a.player.getYaw(), this.a.player.getPitch())
                        .multiply(1.5)
                        .add(var3.x, this.a.player.isOnGround() ? 0.0 : var3.y, var3.z);
                     this.i = this.a.player.age;
                     this.b = this.a() <= 0.0 ? 4 : 3;
                  } else {
                     this.b();
                  }

                  this.h();
               }
               break;
            case 3:
               if (this.a(this.a())) {
                  this.b = 4;
                  this.h();
               }
               break;
            case 4:
               int var2 = this.a(Items.WIND_CHARGE);
               if (var2 < 0) {
                  this.b();
               } else {
                  this.a(var2);
                  this.b = 5;
                  this.h();
                  this.m = 0;
                  this.e = false;
                  if (this.a()) {
                     this.e();
                  }
               }
               break;
            case 5:
               this.g();
               break;
            case 6:
               this.b();
         }
      }
   }

   private void g() {
      if (!this.e) {
         if (this.a.player.getMainHandStack().getItem() == Items.WIND_CHARGE) {
            if (this.a(this.c())) {
               this.m++;
               if (this.a()) {
                  this.e();
                  boolean var1 = this.t >= 0 && this.a.player.age > this.t;
                  boolean var2 = Math.abs(MathHelper.wrapDegrees(this.c - this.d)) <= 4.0F && Math.abs(this.e - this.b) <= 4.0F;
                  if (var1 && var2) {
                     this.a(true);
                  }
               } else {
                  if (this.m > 20) {
                     if (this.t >= 0 && this.a.player.age > this.t) {
                        this.a(true);
                     } else if (this.t < 0) {
                        this.a(false);
                     }
                  }
               }
            }
         }
      }
   }

   private void d() {
      if (this.a(Items.ENDER_PEARL) >= 0 && this.a(Items.WIND_CHARGE) >= 0) {
         this.k = this.a.player.getInventory().getSelectedSlot();
         this.i = -1;
         this.e = false;
         this.c = this.a.player.age;
         this.b = 1;
         this.h();
      }
   }

   private double a(Vec3d eye, Vec3d extra, Vec3d pos, Vec3d vel) {
      Vec3d var5 = pos;
      Vec3d var6 = vel;
      double var7 = pos.subtract(eye).length();

      for (int var9 = 1; var9 <= 100; var9++) {
         var6 = new Vec3d(var6.x, var6.y - 0.03, var6.z).multiply(0.99);
         var5 = var5.add(var6);
         double var10 = 1.5 * Math.max(0.0, var9 - 1.0);
         double var12 = var5.subtract(eye).subtract(extra.multiply(var9)).length() - var10;
         if (var12 <= 0.0) {
            double var14 = var7 - var12;
            double var16 = var14 <= 1.0E-9 ? 0.0 : var7 / var14;
            return var9 - 1 + var16;
         }

         var7 = var12;
      }

      return 0.0;
   }

   public b() {
      this.k = -1;
      this.a = false;
      this.a = this.a();
      this.a = Vec3d.ZERO;
      this.b = Vec3d.ZERO;
      this.i = -1;
      this.t = -1;
      this.n = -1;
      this.q = -1;
      this.m = 0;
      this.c = -1;
      this.d = 50;
   }

   private void a() {
      SilentRot.set(this.c, this.e, this);
   }

   private void a(int slot) {
      this.a.player.getInventory().setSelectedSlot(slot);
      ((SlotSync)this.a.interactionManager).al$sync();
   }

   private double a() {
      return 0.0;
   }

   private void b() {
      this.b = 0;
      this.k = -1;
      this.m = 0;
      this.e = false;
      this.i = -1;
   }

   private void a(boolean silent) {
      if (silent) {
         float var2 = this.a.player.getYaw();
         float var3 = this.a.player.getPitch();
         this.a.player.setYaw(this.c);
         this.a.player.setPitch(this.e);
         this.a.interactionManager.interactItem(this.a.player, Hand.MAIN_HAND);
         this.a.player.setYaw(var2);
         this.a.player.setPitch(var3);
         this.q = this.a.player.age + 2;
      } else {
         this.a.interactionManager.interactItem(this.a.player, Hand.MAIN_HAND);
      }

      this.e = true;
      this.b = 6;
      this.h();
   }

   private float a() {
      double var1 = (Double)this.a.options.getMouseSensitivity().getValue();
      double var3 = var1 * 0.6 + 0.2;
      double var5 = var3 * var3 * var3 * 8.0;
      return (float)var5 * 0.15F;
   }

   private long a() {
      return System.nanoTime() / 1000000L;
   }

   private boolean a(double d) {
      return this.a() - this.a >= d;
   }

   private int a(Item it) {
      for (int var2 = 0; var2 < 9; var2++) {
         ItemStack var3 = this.a.player.getInventory().getStack(var2);
         if (!var3.isEmpty() && var3.getItem() == it) {
            return var2;
         }
      }

      return -1;
   }

   private double c() {
      return 0.0;
   }

   private void e() {
      if (this.n == this.a.player.age) {
         this.a();
      } else {
         this.n = this.a.player.age;
         float var1 = this.a();
         int var2 = Math.max(1, (int)(60.0F / var1));
         float var3 = this.t >= 0 ? this.c : this.a.player.getYaw();
         float var4 = this.t >= 0 ? this.e : MathHelper.clamp(this.a.player.getPitch(), -90.0F, 90.0F);
         float var5 = MathHelper.wrapDegrees(this.d - var3);
         int var6 = Math.round(var5 / var1);
         if (var6 > var2) {
            var6 = var2;
         } else if (var6 < -var2) {
            var6 = -var2;
         }

         this.c = var3 + var6 * var1;
         float var7 = this.b - var4;
         int var8 = Math.round(var7 / var1);
         if (var8 > var2) {
            var8 = var2;
         } else if (var8 < -var2) {
            var8 = -var2;
         }

         int var9 = (int)Math.floor((90.0F - var4) / var1);
         int var10 = (int)Math.ceil((-90.0F - var4) / var1);
         if (var8 > var9) {
            var8 = var9;
         }

         if (var8 < var10) {
            var8 = var10;
         }

         this.e = MathHelper.clamp(var4 + var8 * var1, -90.0F, 90.0F);
         if (this.t < 0) {
            this.t = this.a.player.age;
         }

         this.a();
      }
   }

   private double b() {
      try {
         ClientPlayNetworkHandler var1 = this.a.getNetworkHandler();
         if (var1 != null && this.a.player != null) {
            PlayerListEntry var2 = var1.getPlayerListEntry(this.a.player.getUuid());
            if (var2 != null && var2.getLatency() > 0) {
               this.d = Math.min(var2.getLatency(), 400);
            }
         }
      } catch (Throwable var3) {
      }

      return this.d / 50.0;
   }

   private Vec3d a(Vec3d pos, Vec3d vel, double t) {
      int var5 = (int)Math.floor(t);
      Vec3d var6 = pos;
      Vec3d var7 = vel;

      for (int var8 = 0; var8 < var5; var8++) {
         var7 = new Vec3d(var7.x, var7.y - 0.03, var7.z).multiply(0.99);
         var6 = var6.add(var7);
      }

      double var11 = t - var5;
      if (var11 > 0.0) {
         var7 = new Vec3d(var7.x, var7.y - 0.03, var7.z).multiply(0.99);
         var6 = var6.add(var7.multiply(var11));
      }

      return var6;
   }

   private void c() {
      SilentRot.stop(this);
      this.c = 0.0F;
      this.e = 0.0F;
      this.t = -1;
      this.n = -1;
      this.q = -1;
   }
}
