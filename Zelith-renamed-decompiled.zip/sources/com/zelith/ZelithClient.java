package com.zelith;

import com.zelith.gui.ClickGUI;
import com.zelith.gui.notification.NotificationManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.EndTick;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ZelithClient implements ClientModInitializer {
   public static final Logger LOGGER = LoggerFactory.getLogger("zelith");
   private static KeyBinding rightShiftKey;

   public void onInitializeClient() {
      LOGGER.info("Initialisiere Zelith Client (Yarn Mappings)\n--- Cracked by github.com/TrilliumSolutions ---");
      SwapHelper.HwidGen.Module();
      Object v1 = new net.minecraft.client.option.KeyBinding.Category(Identifier.of("zelith", "category"));
      rightShiftKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.zelith.toggle_menu", 344, v1));
      HudRenderCallback.EVENT.register((HudRenderCallback)(v0, v1x) -> {
         Module_NameTags.HwidGen(v0, v1x.getTickProgress(false));
         Module_Hud.HwidGen(v0);
         Module_SpotifyHUD.HwidGen(v0);
         NotificationManager.INSTANCE.render(v0);
      });
      ClientTickEvents.END_CLIENT_TICK.register((EndTick)v1x -> {
         SwapHelper.HwidGen.Category();

         while (rightShiftKey.wasPressed()) {
            if (v1x.currentScreen == null || v1x.currentScreen instanceof TitleScreen) {
               v1x.setScreen(new ClickGUI());
            }
         }

         if (v1x.currentScreen == null && v1x.getWindow() != null) {
            for (Object v3 : SwapHelper.HwidGen.KeyFile()) {
               int i4 = v3.KeyFile();
               Object v5 = v3 instanceof Object v6 ? v6 : null;
               int i6 = v5 != null ? v5.HwidGen() : 0;
               if (i4 != 0) {
                  try {
                     int i7 = GLFW.glfwGetKey(v1x.getWindow().getHandle(), i4) == 1;
                     if (i7 && !v3.LicenseResult && i6 != i4) {
                        v3.LicenseResult();
                     }

                     v3.LicenseResult = i7;
                  } catch (Exception var11) {
                  }
               }

               if (v5 != null && i6 != 0) {
                  try {
                     int var12 = GLFW.glfwGetKey(v1x.getWindow().getHandle(), i6) == 1;
                     if (var12 && !v5.HwidGen) {
                        v5.KeyFile();
                     }

                     v5.HwidGen = var12;
                  } catch (Exception var10) {
                  }
               }
            }
         }
      });
   }
}
