package com.zelith.gui;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Locale;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;
import org.lwjgl.glfw.GLFW;

public final class HudEditor {
   public static final HudEditor INSTANCE = new HudEditor();
   private static final int HANDLE_BG = 1712330788;
   private static final int HANDLE_ACTIVE_BG = -1726998492;
   private static final int HANDLE_TEXT = -1511950;
   private static final int HANDLE_MUTED = -6642510;
   private String dragging = null;
   private int grabOffsetX;
   private int grabOffsetY;
   private boolean isDragging = false;

   private HudEditor() {
   }

   public boolean onMouseClick(double d, double e, int i) {
      if (i != 0) {
         this.dragging = null;
         this.isDragging = false;
         return false;
      } else {
         for (p var9 : HudElement.values()) {
            if (Module_Hud.HwidGen(var9)) {
               int[] var10 = handlePos(var9);
               int var11 = handleW(var9);
               int var12 = handleH(var9);
               if (d >= var10[0] && d <= var10[0] + var11 && e >= var10[1] && e <= var10[1] + var12) {
                  this.dragging = var9.name();
                  this.grabOffsetX = (int)(d - var10[0]);
                  this.grabOffsetY = (int)(e - var10[1]);
                  this.isDragging = true;
                  return true;
               }
            }
         }

         this.dragging = null;
         this.isDragging = false;
         return false;
      }
   }

   public boolean isDragging() {
      return this.dragging != null && this.isDragging;
   }

   public void onMouseDrag(double d, double e) {
      if (this.dragging != null && this.isDragging) {
         MinecraftClient var5 = MinecraftClient.getInstance();
         if (var5 != null && var5.getWindow() != null) {
            long var6 = var5.getWindow().getHandle();
            if (var6 != 0L && GLFW.glfwGetMouseButton(var6, 0) != 1) {
               this.onMouseRelease();
               return;
            }
         }

         try {
            p var15 = HudElement.valueOf(this.dragging);
            int var7 = (int)Math.round(d - this.grabOffsetX);
            int var8 = (int)Math.round(e - this.grabOffsetY);
            if (var5 != null && var5.getWindow() != null) {
               int var9 = var5.getWindow().getScaledWidth();
               int var10 = var5.getWindow().getScaledHeight();
               int var11 = handleW(var15);
               int var12 = handleH(var15);
               if (var11 < 1) {
                  var11 = 1;
               }

               if (var12 < 1) {
                  var12 = 1;
               }

               if (var9 > 0) {
                  int var13 = Math.max(0, var9 - var11);
                  if (var7 < 0) {
                     var7 = 0;
                  } else if (var7 > var13) {
                     var7 = var13;
                  }
               }

               if (var10 > 0) {
                  int var20 = Math.max(0, var10 - var12);
                  if (var8 < 0) {
                     var8 = 0;
                  } else if (var8 > var20) {
                     var8 = var20;
                  }
               }
            }

            if (var15 == HudElement.LicenseResult) {
               int var16 = Obj_dr.SwapHelper(var7 + handleW(var15));
               int var18 = Obj_dr.Module_j(var8);
               Module_Hud.HwidGen(var15, var16, var18);
            } else {
               int var17 = Obj_dr.SwapHelper(var7);
               int var19 = Obj_dr.Module_j(var8);
               Module_Hud.HwidGen(var15, var17, var19);
            }
         } catch (Exception var14) {
         }
      }
   }

   public void onMouseRelease() {
      this.dragging = null;
      this.isDragging = false;
   }

   public boolean onMouseScroll(double d, double e, double f) {
      if (f == 0.0) {
         return false;
      } else if (!Module_Hud.HwidGen(HudElement.Module)) {
         return false;
      } else {
         int[] var7 = Module_Hud.HwidGen(HudElement.Module);
         int var8 = Obj_dr.Category(var7[0]);
         int var9 = Obj_dr.Module(var7[1]);
         int var10 = Module_SpotifyHUD.c();
         int var11 = Module_SpotifyHUD.LicenseResult();
         if (!(d < var8) && !(d > var8 + var10) && !(e < var9) && !(e > var9 + var11)) {
            float var12 = (float)(f * 0.08);
            Module_SpotifyHUD.HwidGen(Module_SpotifyHUD.HwidGen() + var12);
            return true;
         } else {
            return false;
         }
      }
   }

   private static int[] handlePos(p arg) {
      if (arg == HudElement.LicenseResult) {
         int[] var2 = Module_Hud.HwidGen();
         return new int[]{var2[0], var2[1]};
      } else {
         int[] var1 = Module_Hud.KeyFile(arg);
         return new int[]{var1[0], var1[1]};
      }
   }

   private static int handleW(p arg) {
      if (arg == HudElement.LicenseResult) {
         return Module_Hud.HwidGen()[2];
      } else if (arg == HudElement.Module) {
         return Module_SpotifyHUD.c();
      } else {
         MinecraftClient var1 = MinecraftClient.getInstance();
         return var1 == null ? 80 : Module_Hud.KeyFile(arg)[2];
      }
   }

   private static int handleH(p arg) {
      if (arg == HudElement.LicenseResult) {
         return Module_Hud.HwidGen()[3];
      } else {
         return arg == HudElement.Module ? Module_SpotifyHUD.LicenseResult() : Module_Hud.KeyFile(arg)[3];
      }
   }

   public void render(DrawContext drawContext, int i, int j) {
      MinecraftClient var4 = MinecraftClient.getInstance();
      if (var4 != null) {
         int var5 = Module_zelith.Category();
         float var6 = Obj_dr.Module_ActiveModules();

         for (p var10 : HudElement.values()) {
            if (Module_Hud.HwidGen(var10)) {
               int[] var11 = handlePos(var10);
               int var12 = handleW(var10);
               int var13 = handleH(var10);
               boolean var14 = var10.name().equals(this.dragging);
               if (var10 != HudElement.LicenseResult) {
                  if (var10 == HudElement.LicenseState) {
                     TextRenderer var27 = var4.textRenderer;
                     ArrayList var28 = new ArrayList(var4.player.getStatusEffects());
                     if (!var28.isEmpty()) {
                        var28.sort(Comparator.comparingInt(statusEffectInstance -> var27.getWidth(Module_Hud.HwidGen(statusEffectInstance))));
                        int[] var30 = Module_Hud.HwidGen(HudElement.LicenseState);
                        int var32 = Obj_dr.Module(var30[1]);
                        int var33 = Obj_dr.Category(var30[0]);

                        for (StatusEffectInstance var35 : var28) {
                           String var36 = Module_Hud.HwidGen(var35);
                           int var37 = var27.getWidth(var36) + Math.round(14.0F * var6);
                           int var38 = Math.round(14.0F * var6);
                           drawHandle(drawContext, var4, var33, var32, var37, var38, var36, var14, var5);
                           var32 += var38 + Math.round(3.0F * var6);
                        }
                     } else if (var14) {
                        drawHandle(drawContext, var4, var11[0], var11[1], var12, var13, "Potion Effects", true, var5);
                     }
                  } else {
                     float var26 = var10 == HudElement.HwidGen ? 6.0F * var6 : 5.0F * var6;
                     if (var10 == HudElement.Module) {
                        var26 = 2.0F * Module_SpotifyHUD.HwidGen() * var6;
                     }

                     drawHandle(drawContext, var4, var11[0], var11[1], var12, var13, displayName(var10), var14, var5, var26);
                  }
               } else {
                  TextRenderer var15 = var4.textRenderer;
                  ArrayList var16 = new ArrayList();

                  for (Module var18 : SwapHelper.HwidGen.KeyFile()) {
                     if (var18.HwidGen() && var18.HwidGen() != Category.Module_f) {
                        var16.add(var18);
                     }
                  }

                  if (var16.isEmpty()) {
                     if (var14) {
                        drawHandle(drawContext, var4, var11[0], var11[1], var12, var13, "Module List", true, var5);
                     }
                  } else {
                     var16.sort(Comparator.<h>comparingInt(arg -> var15.getWidth(arg.c())).reversed());
                     int[] var29 = Module_Hud.HwidGen(HudElement.LicenseResult);
                     int var31 = Obj_dr.Module(var29[1]);
                     int var19 = Obj_dr.Category(var29[0]);

                     for (Module var21 : var16) {
                        String var22 = var21.c();
                        int var23 = var15.getWidth(var22) + Math.round(14.0F * var6);
                        int var24 = Math.round(14.0F * var6);
                        int var25 = var19 - var23;
                        drawHandle(drawContext, var4, var25, var31, var23, var24, var22, var14, var5);
                        var31 += var24 + Math.round(4.0F * var6);
                     }
                  }
               }
            }
         }
      }
   }

   private static void drawHandle(DrawContext drawContext, MinecraftClient minecraftClient, int i, int j, int k, int l, String string, boolean bl, int m) {
      drawHandle(drawContext, minecraftClient, i, j, k, l, string, bl, m, 6.0F);
   }

   private static void drawHandle(
      DrawContext drawContext, MinecraftClient minecraftClient, int i, int j, int k, int l, String string, boolean bl, int m, float f
   ) {
      float var10 = Obj_dr.Module_ActiveModules();
      int var11 = Math.max(Math.round(28.0F * var10), k);
      int var12 = Math.max(Math.round(14.0F * var10), l);
      Obj_dr.HwidGen(drawContext, (float)i, (float)j, (float)var11, (float)var12, f, bl ? -1726998492 : 1712330788, false);
      Obj_dr.HwidGen(drawContext, (float)i, (float)j, (float)var11, (float)var12, f, bl ? 1.4F * var10 : 1.0F * var10, bl ? m : withAlpha(m, 150), false);
      Obj_dr.HwidGen(
         drawContext,
         (float)(i + Math.round(3.0F * var10)),
         (float)(j + Math.round(3.0F * var10)),
         (float)Math.round(3.0F * var10),
         (float)Math.max(Math.round(4.0F * var10), var12 - Math.round(6.0F * var10)),
         1.5F * var10,
         m,
         false
      );
      if (string != null && !string.isBlank() && var11 >= Math.round(54.0F * var10)) {
         String var13 = trimToWidth(minecraftClient, string, var11 - Math.round(14.0F * var10));
         drawContext.drawText(minecraftClient.textRenderer, var13, i + Math.round(10.0F * var10), j + (var12 - 9) / 2, bl ? -1511950 : -6642510, false);
      }
   }

   private static String displayName(p arg) {
      String var1 = arg.name().toLowerCase(Locale.ROOT).replace('_', ' ');
      StringBuilder var2 = new StringBuilder(var1.length());
      boolean var3 = true;

      for (int var4 = 0; var4 < var1.length(); var4++) {
         char var5 = var1.charAt(var4);
         if (var3 && Character.isLetter(var5)) {
            var2.append(Character.toUpperCase(var5));
            var3 = false;
         } else {
            var2.append(var5);
         }

         if (var5 == ' ') {
            var3 = true;
         }
      }

      return var2.toString();
   }

   private static String trimToWidth(MinecraftClient minecraftClient, String string, int i) {
      if (minecraftClient.textRenderer.getWidth(string) <= i) {
         return string;
      } else {
         String var3 = string;

         while (var3.length() > 1 && minecraftClient.textRenderer.getWidth(var3 + "...") > i) {
            var3 = var3.substring(0, var3.length() - 1);
         }

         return var3 + "...";
      }
   }

   private static int withAlpha(int i, int j) {
      return i & 16777215 | Math.max(0, Math.min(255, j)) << 24;
   }
}
