package com.zelith.gui;

record ClickGUI$ColorPickerLayout() {
   final int fieldX;
   final int fieldY;
   final int fieldW;
   final int fieldH;
   final int hueX;
   final int hueY;
   final int hueW;
   final int hueH;

   ClickGUI$ColorPickerLayout(int i, int j, int k, int l, int m, int n, int o, int p) {
      this.fieldX = i;
      this.fieldY = j;
      this.fieldW = k;
      this.fieldH = l;
      this.hueX = m;
      this.hueY = n;
      this.hueW = o;
      this.hueH = p;
   }
}
