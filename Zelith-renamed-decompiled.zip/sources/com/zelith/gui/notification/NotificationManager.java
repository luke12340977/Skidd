package com.zelith.gui.notification;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Util;

public final class NotificationManager {
   public static final NotificationManager INSTANCE = new NotificationManager();
   private static final long DISPLAY_MS = 3500L;
   private static final long ANIMATION_MS = 220L;
   private static final int MAX_NOTIFICATIONS = 5;
   private static final float CARD_WIDTH = 180.0F;
   private static final float CARD_HEIGHT = 44.0F;
   private static final float CARD_GAP = 6.0F;
   private static final float CARD_RADIUS = 6.0F;
   private static final int PANEL_BG = -401534696;
   private static final int TEXT = -1513234;
   private static final int MUTED = -7368550;
   private static final int OUTLINE = -1439287222;
   private static final int DARK = -15921901;
   private final List notifications = new CopyOnWriteArrayList();

   private NotificationManager() {
   }

   public void pushToggle(String string, boolean bl) {
      this.pushToggle(string, bl, ItemStack.EMPTY);
   }

   public void pushToggle(String string, boolean bl, ItemStack itemStack) {
      this.push(string, bl ? "ON" : "OFF", itemStack, Module_zelith.Category());
   }

   public void renderToasts(DrawContext drawContext) {
      this.render(drawContext);
   }

   public void push(String string, String string2, ItemStack itemStack, int i) {
      this.notifications
         .add(
            0,
            new NotificationManager$NotificationEntry(
               string == null ? "" : string,
               string2 == null ? "" : string2,
               itemStack == null ? ItemStack.EMPTY : itemStack.copy(),
               i,
               Util.getMeasuringTimeMs()
            )
         );

      while (this.notifications.size() > 5) {
         this.notifications.remove(this.notifications.size() - 1);
      }
   }

   public void render(DrawContext drawContext) {
      if (!this.notifications.isEmpty()) {
         MinecraftClient var2 = MinecraftClient.getInstance();
         TextRenderer var3 = var2.textRenderer;
         long var4 = Util.getMeasuringTimeMs();
         this.notifications.removeIf(notificationEntry -> notificationEntry.isExpired(var4));
         if (!this.notifications.isEmpty()) {
            drawContext.createNewRootLayer();
            float var6 = Obj_dr.Module_ActiveModules();
            float var7 = 180.0F * var6;
            float var8 = 44.0F * var6;
            float var9 = 6.0F * var6;
            float var10 = 6.0F * var6;
            float var11 = 6.0F * var6;
            float var12 = var2.getWindow().getScaledWidth() - var7 - var11;
            float var13 = var2.getWindow().getScaledHeight() - var8 - var11;

            for (int var14 = 0; var14 < this.notifications.size(); var14++) {
               NotificationManager$NotificationEntry var15 = (NotificationManager$NotificationEntry)this.notifications.get(var14);
               float var16 = var15.getVisibility(var4);
               if (!(var16 <= 0.0F)) {
                  float var17 = var12 + (1.0F - var16) * (var7 + 8.0F * var6);
                  float var18 = var13 - var14 * (var8 + var9);
                  int var19 = withAlpha(-401534696, var16);
                  int var20 = withAlpha(-1439287222, var16);
                  int var21 = withAlpha(-1513234, var16);
                  int var22 = withAlpha(-7368550, var16);
                  int var23 = withAlpha(var15.accentColor, var16);
                  if (Module_zelith.Module()) {
                     Obj_dr.HwidGen(drawContext, var17 + 2.0F * var6, var18 + 3.0F * var6, var7, var8, var10, withAlpha(1996488704, var16), false);
                  }

                  Obj_dr.HwidGen(drawContext, var17, var18, var7, var8, var10, var19, false);
                  Obj_dr.HwidGen(drawContext, var17, var18, var7, var8, var10, 1.0F * var6, var20, false);
                  Obj_dr.HwidGen(
                     drawContext,
                     var17 + 1.0F * var6,
                     var18 + 1.0F * var6,
                     var7 - 2.0F * var6,
                     14.0F * var6,
                     var10,
                     var10,
                     2.0F * var6,
                     2.0F * var6,
                     false,
                     withAlpha(-266790621, var16)
                  );
                  long var24 = var4 - var15.createdAt;
                  float var26 = 1.0F;
                  if (var24 > 220L) {
                     var26 = 1.0F - Math.min(1.0F, (float)(var24 - 220L) / 3280.0F);
                  }

                  float var27 = Math.max(0.0F, (var7 - 16.0F * var6) * var26);
                  if (var27 > 0.0F) {
                     Obj_dr.HwidGen(drawContext, var17 + 8.0F * var6, var18 + 14.0F * var6, var27, 1.0F * var6, 0.5F * var6, var23, false);
                  }

                  int var28 = Math.round(var17 + 8.0F * var6);
                  int var29 = Math.round(var18 + 22.0F * var6);
                  Obj_dr.HwidGen(drawContext, (float)var28, (float)var29, 16.0F * var6, 16.0F * var6, 4.0F * var6, -15921901, false);
                  if (!var15.stack.isEmpty()) {
                     drawContext.getMatrices().pushMatrix();
                     drawContext.getMatrices().translate(var28 + Math.round(8.0F * var6), var29 + Math.round(8.0F * var6));
                     drawContext.getMatrices().scale(var6, var6);
                     drawContext.drawItem(var15.stack, -8, -8);
                     drawContext.getMatrices().popMatrix();
                  }

                  int var30 = Math.round(var17 + 30.0F * var6);
                  int var31 = Math.max(Math.round(40.0F * var6), Math.round(var7 - 36.0F * var6));
                  String var32 = var3.trimToWidth(var15.message.toUpperCase(Locale.ROOT), Math.round(var31 / var6));
                  String var33 = var15.details.toUpperCase(Locale.ROOT);
                  drawContext.getMatrices().pushMatrix();
                  drawContext.getMatrices().translate(var30, Math.round(var29 + 1.0F * var6));
                  drawContext.getMatrices().scale(var6, var6);
                  drawContext.drawText(var3, var32, 0, 0, var21, false);
                  drawContext.getMatrices().popMatrix();
                  int var34 = var15.details.equals("ON") ? var23 : var22;
                  drawContext.getMatrices().pushMatrix();
                  drawContext.getMatrices().translate(var30, Math.round(var29 + 11.0F * var6));
                  drawContext.getMatrices().scale(var6, var6);
                  drawContext.drawText(var3, var33, 0, 0, var34, false);
                  drawContext.getMatrices().popMatrix();
               }
            }
         }
      }
   }

   private static int withAlpha(int i, float f) {
      int var2 = Math.max(0, Math.min(255, Math.round((i >>> 24 & 0xFF) * f)));
      return i & 16777215 | var2 << 24;
   }
}
