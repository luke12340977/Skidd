package com.zelith.gui.notification;

import net.minecraft.item.ItemStack;

final class NotificationManager$NotificationEntry {
   final String message;
   final String details;
   final ItemStack stack;
   final int accentColor;
   final long createdAt;

   NotificationManager$NotificationEntry(String string, String string2, ItemStack itemStack, int i, long l) {
      this.message = string;
      this.details = string2;
      this.stack = itemStack;
      this.accentColor = i | 0xFF000000;
      this.createdAt = l;
   }

   boolean isExpired(long l) {
      return l - this.createdAt >= 3500L;
   }

   float getVisibility(long l) {
      long var3 = l - this.createdAt;
      if (var3 <= 0L) {
         return 0.0F;
      } else if (var3 < 220L) {
         return this.easeOutCubic((float)var3 / 220.0F);
      } else {
         long var5 = 3280L;
         if (var3 > var5) {
            float var7 = 1.0F - (float)(var3 - var5) / 220.0F;
            return this.easeOutCubic(Math.max(0.0F, var7));
         } else {
            return 1.0F;
         }
      }
   }

   private float easeOutCubic(float f) {
      float var2 = 1.0F - Math.max(0.0F, Math.min(1.0F, f));
      return 1.0F - var2 * var2 * var2;
   }
}
