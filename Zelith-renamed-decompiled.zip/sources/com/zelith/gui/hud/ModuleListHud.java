package com.zelith.gui.hud;

import com.zelith.gui.ClickGUI;
import java.util.ArrayList;
import java.util.Comparator;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class ModuleListHud {
   public static final ModuleListHud INSTANCE = new ModuleListHud();
   private static final int PANEL_COLOR = -652993496;
   private static final int OUTLINE_COLOR = -869253035;
   private static final int TEXT_COLOR = -854277;
   private static int ACCENT_COLOR = -9710683;
   private static final float RADIUS = 6.0F;
   private static final int TOP_OFFSET = 72;

   private ModuleListHud() {
   }

   public void render(DrawContext drawContext) {
      ACCENT_COLOR = Module_zelith.Category();
      MinecraftClient var2 = MinecraftClient.getInstance();
      if (var2 != null && var2.options != null && !var2.getDebugHud().shouldShowDebugHud()) {
         if (!(var2.currentScreen instanceof ClickGUI)) {
            TextRenderer var3 = var2.textRenderer;
            ArrayList var4 = new ArrayList();

            for (Module var6 : SwapHelper.HwidGen.KeyFile()) {
               if (var6.HwidGen()) {
                  var4.add(var6);
               }
            }

            if (!var4.isEmpty()) {
               var4.sort(Comparator.<h>comparingInt(arg -> var3.getWidth(arg.c())).reversed());
               float var15 = Obj_dr.Module_ActiveModules();
               int var16 = var2.getWindow().getScaledWidth() - Math.round(10.0F * var15);
               int var7 = Math.round(72.0F * var15);

               for (Module var9 : var4) {
                  String var10 = var9.c();
                  int var11 = Math.round(var3.getWidth(var10) * var15);
                  int var12 = var11 + Math.round(14.0F * var15);
                  int var13 = Math.round(14.0F * var15);
                  int var14 = var16 - var12;
                  Obj_dr.HwidGen(drawContext, (float)var14, (float)var7, (float)var12, (float)var13, 6.0F * var15, -652993496, false);
                  Obj_dr.HwidGen(drawContext, (float)var14, (float)var7, (float)var12, (float)var13, 6.0F * var15, 1.0F * var15, -869253035, false);
                  Obj_dr.HwidGen(
                     drawContext,
                     (float)var14,
                     (float)(var7 + Math.round(1.0F * var15)),
                     2.0F * var15,
                     (float)(var13 - Math.round(2.0F * var15)),
                     1.0F * var15,
                     ACCENT_COLOR,
                     false
                  );
                  drawContext.getMatrices().pushMatrix();
                  drawContext.getMatrices().translate(var14 + Math.round(6.0F * var15), var7 + Math.round(3.0F * var15));
                  drawContext.getMatrices().scale(var15, var15);
                  drawContext.drawText(var3, var10, 0, 0, -854277, false);
                  drawContext.getMatrices().popMatrix();
                  var7 += var13 + Math.round(4.0F * var15);
               }
            }
         }
      }
   }
}
