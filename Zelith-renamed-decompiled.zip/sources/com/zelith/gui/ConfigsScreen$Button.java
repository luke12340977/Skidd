package com.zelith.gui;

final class ConfigsScreen$Button {
   final int Module_AutoInvTotem;
   final int Module_AutoTotem;
   final int Module_AutoDoubleHand;
   final int Module;
   final String label;
   final Runnable action;

   ConfigsScreen$Button(int i, int j, int k, int l, String string, Runnable runnable) {
      this.Module_AutoInvTotem = i;
      this.Module_AutoTotem = j;
      this.Module_AutoDoubleHand = k;
      this.Module = l;
      this.label = string;
      this.action = runnable;
   }

   boolean contains(int i, int j) {
      return i >= this.Module_AutoInvTotem
         && i <= this.Module_AutoInvTotem + this.Module_AutoDoubleHand
         && j >= this.Module_AutoTotem
         && j <= this.Module_AutoTotem + this.Module;
   }
}
