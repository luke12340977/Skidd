package com.zelith.gui;

enum ConfigsScreen$View {
   MAIN,
   CREATE,
   LOAD,
   SHARE,
   GENERATE,
   REDEEM;
}
