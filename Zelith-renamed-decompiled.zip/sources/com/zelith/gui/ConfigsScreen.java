package com.zelith.gui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.joml.Matrix4f;
import org.lwjgl.glfw.GLFW;

public final class ConfigsScreen extends Screen {
   private static final int PANEL_W = 320;
   private static final int BTN_W = 270;
   private static final int BTN_H = 28;
   private static final int BTN_GAP = 6;
   private static final int PANEL_PAD = 18;
   private static final int HEADER_H = 34;
   private static final int FIELD_H = 26;
   private static final int LIST_VISIBLE = 6;
   private static final int COLOR_SCREEN_BG = -1073214962;
   private static final int COLOR_PANEL_BG = -401599200;
   private static final int COLOR_PANEL_LINE = 1075981632;
   private static final int COLOR_HEADER_BG = -401269200;
   private static final int COLOR_ROW_BG = -1206839003;
   private static final int COLOR_ROW_HOVER = -669242818;
   private static final int COLOR_FIELD_BG = -1207300068;
   private static final int COLOR_TEXT = -1511947;
   private static final int COLOR_TEXT_MUTED = -2137480525;
   private static final int COLOR_SUCCESS = -13380502;
   private static final int COLOR_ERROR = -48043;
   private final m module;
   private ConfigsScreen$View view = ConfigsScreen$View.MAIN;
   private boolean closing = false;
   private final List buttons = new ArrayList();
   private String inputText = "";
   private int listScroll = 0;
   private List currentList = new ArrayList();
   private String generatedCode = "";
   private boolean showCopyConfirm = false;
   private String toast = null;
   private long toastUntil = 0L;
   private Matrix4f proj;

   public ConfigsScreen(m arg) {
      super(Text.literal("Configs"));
      this.module = arg;
   }

   protected void init() {
      this.proj = Obj_dr.HwidGen(this.width, this.height);
      this.rebuild();
   }

   private int contentHeight() {
      return switch (this.view) {
         case MAIN, SHARE -> 166;
         case CREATE, REDEEM -> 168;
         case LOAD -> {
            int var1 = Math.min(6, Math.max(1, this.currentList.size()));
            yield 52 + var1 * 28 + (var1 - 1) * 6 + 10 + 28 + 18;
         }
         case GENERATE -> 168;
      };
   }

   private void rebuild() {
      this.buttons.clear();
      int var1 = this.contentHeight();
      int var2 = (this.width - 320) / 2;
      int var3 = (this.height - var1) / 2;
      int var4 = var2 + 25;
      int var5 = var3 + 34 + 18;
      switch (this.view) {
         case MAIN:
            this.button(var4, var5, 270, 28, "Create Config", () -> {
               this.view = ConfigsScreen$View.CREATE;
               this.inputText = "";
               this.rebuild();
            });
            var5 += 34;
            this.button(var4, var5, 270, 28, "Load Config", () -> {
               this.view = ConfigsScreen$View.LOAD;
               this.currentList = ConfigMan.Module();
               this.listScroll = 0;
               this.rebuild();
            });
            var5 += 34;
            this.button(var4, var5, 270, 28, "Share Config", () -> {
               this.view = ConfigsScreen$View.SHARE;
               this.rebuild();
            });
            break;
         case CREATE:
            var5 += 36;
            short var23 = 132;
            this.button(var4, var5, var23, 28, "Save", () -> {
               if (ConfigMan.Module(this.inputText)) {
                  this.showToast("Saved as " + ConfigMan.sanitize(this.inputText), true);
                  this.view = ConfigsScreen$View.MAIN;
                  this.rebuild();
               } else {
                  this.showToast("Invalid name", false);
               }
            });
            this.button(var4 + var23 + 6, var5, var23, 28, "Cancel", () -> {
               this.view = ConfigsScreen$View.MAIN;
               this.rebuild();
            });
            var5 += 34;
            this.button(var4, var5, 270, 28, "Back", () -> {
               this.view = ConfigsScreen$View.MAIN;
               this.rebuild();
            });
            break;
         case LOAD:
            if (this.currentList.isEmpty()) {
               var5 += 40;
            } else {
               int var22 = Math.min(this.currentList.size(), this.listScroll + 6);

               for (int var7 = this.listScroll; var7 < var22; var7++) {
                  String var8 = (String)this.currentList.get(var7);
                  short var9 = 228;
                  this.button(var4, var5, var9, 28, var8, () -> {
                     if (ConfigMan.SwapHelper(var8)) {
                        this.showToast("Loaded " + var8, true);
                     } else {
                        this.showToast("Failed to load", false);
                     }
                  });
                  this.button(var4 + var9 + 6, var5, 30, 28, "X", () -> {
                     ConfigMan.Module_j(var8);
                     this.currentList = ConfigMan.Module();
                     this.listScroll = Math.max(0, Math.min(this.listScroll, this.currentList.size() - 1));
                     this.rebuild();
                  });
                  var5 += 34;
               }
            }

            var5 += 10;
            this.button(var4, var5, 270, 28, "Back", () -> {
               this.view = ConfigsScreen$View.MAIN;
               this.rebuild();
            });
            break;
         case SHARE:
            this.button(var4, var5, 270, 28, "Generate Share Code", () -> {
               String var1x = ConfigMan.Module_AutoTotem();
               if (var1x != null) {
                  this.generatedCode = var1x;
                  this.view = ConfigsScreen$View.GENERATE;
                  this.rebuild();
                  this.showToast("Code generated", true);
               } else {
                  this.showToast("Failed to generate", false);
               }
            });
            var5 += 34;
            this.button(var4, var5, 270, 28, "Redeem Share Code", () -> {
               this.view = ConfigsScreen$View.REDEEM;
               this.inputText = "";
               this.rebuild();
            });
            var5 += 34;
            this.button(var4, var5, 270, 28, "Back", () -> {
               this.view = ConfigsScreen$View.MAIN;
               this.rebuild();
            });
            break;
         case GENERATE:
            var5 += 36;
            short var21 = 132;
            this.button(var4, var5, var21, 28, "Copy", () -> {
               ConfigMan.HudElement(this.generatedCode);
               this.showCopyConfirm = true;
               this.showToast("Copied to clipboard", true);
            });
            this.button(var4 + var21 + 6, var5, var21, 28, "Back", () -> {
               this.view = ConfigsScreen$View.SHARE;
               this.rebuild();
            });
            var5 += 34;
            this.button(var4, var5, 270, 28, "Done", () -> {
               this.view = ConfigsScreen$View.MAIN;
               this.rebuild();
            });
            break;
         case REDEEM:
            var5 += 36;
            short var6 = 132;
            this.button(var4, var5, var6, 28, "Paste", () -> {
               this.inputText = ConfigMan.Module_DoubleAnchor();
               if (this.inputText == null) {
                  this.inputText = "";
               }
            });
            this.button(var4 + var6 + 6, var5, var6, 28, "Apply", () -> {
               if (ConfigMan.Module_ActiveModules(this.inputText)) {
                  this.showToast("Config applied", true);
                  this.view = ConfigsScreen$View.MAIN;
                  this.rebuild();
               } else {
                  this.showToast("Invalid code", false);
               }
            });
            var5 += 34;
            this.button(var4, var5, 270, 28, "Back", () -> {
               this.view = ConfigsScreen$View.SHARE;
               this.rebuild();
            });
      }
   }

   private void button(int i, int j, int k, int l, String string, Runnable runnable) {
      this.buttons.add(new ConfigsScreen$Button(i, j, k, l, string, runnable));
   }

   private void showToast(String string, boolean bl) {
      this.toast = string;
      this.toastUntil = System.currentTimeMillis() + 2200L;
   }

   public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
      int var5 = this.contentHeight();
      int var6 = (this.width - 320) / 2;
      int var7 = (this.height - var5) / 2;
      int var8 = Module_zelith.Category();
      context.fill(0, 0, this.width, this.height, -1073214962);
      Obj_dr.HwidGen(this.proj, (float)(var6 + 3), (float)(var7 + 5), 320.0F, (float)var5, 10.0F, 1140850688, false);
      Obj_dr.HwidGen(this.proj, (float)(var6 + 1), (float)(var7 + 2), 320.0F, (float)var5, 10.0F, 570425344, false);
      Obj_dr.HwidGen(this.proj, (float)var6, (float)var7, 320.0F, (float)var5, 10.0F, -401599200, false);
      Obj_dr.HwidGen(this.proj, (float)var6, (float)var7, 320.0F, 34.0F, 10.0F, 10.0F, 4.0F, 4.0F, false, -401269200);
      Obj_dr.HwidGen(this.proj, (float)(var6 + 18), (float)(var7 + 34 - 2), 284.0F, 2.0F, 1.0F, var8, false);
      Obj_dr.HwidGen(this.proj, (float)var6, (float)var7, 320.0F, (float)var5, 10.0F, 1.0F, 1075981632, false);

      String var9 = switch (this.view) {
         case MAIN -> "Configs";
         case CREATE -> "Create Config";
         case LOAD -> "Load Config";
         case SHARE -> "Share Config";
         case GENERATE -> "Generated Share Code";
         case REDEEM -> "Redeem Share Code";
      };

      String var10 = switch (this.view) {
         case MAIN -> "⚙ ";
         case CREATE -> "+ ";
         case LOAD -> "↑ ";
         case SHARE -> "↔ ";
         case GENERATE -> "# ";
         case REDEEM -> "↓ ";
      };
      context.drawText(this.textRenderer, var10 + var9, var6 + 18, var7 + (34 - 9) / 2, -1511947, false);
      int var11 = var6 + 25;
      int var12 = var7 + 34 + 18;
      if (this.view == ConfigsScreen$View.CREATE || this.view == ConfigsScreen$View.REDEEM) {
         String var13 = this.view == ConfigsScreen$View.CREATE ? "Name" : "Code";
         context.drawText(this.textRenderer, var13, var11, var12 - 10, -2137480525, false);
         this.drawField(context, var11, var12, 270, 26, this.inputText, var8, true);
         if (this.view == ConfigsScreen$View.CREATE && !this.inputText.isEmpty()) {
            String var14 = ConfigMan.sanitize(this.inputText);
            if (!var14.equals(this.inputText.trim())) {
               int var15 = this.textRenderer.getWidth("Preview: " + var14);
               context.drawText(this.textRenderer, "Preview: " + var14, var6 + 320 - 18 - var15, var12 + 26 + 4, -2137480525, false);
            }
         }
      }

      if (this.view == ConfigsScreen$View.GENERATE) {
         context.drawText(this.textRenderer, "Code", var11, var12 - 10, -2137480525, false);
         this.drawField(context, var11, var12, 270, 26, this.generatedCode, var8, false);
      }

      if (this.view == ConfigsScreen$View.LOAD && this.currentList.isEmpty()) {
         String var21 = "No saved configs yet.";
         int var24 = this.textRenderer.getWidth(var21);
         context.drawText(this.textRenderer, var21, var6 + (320 - var24) / 2, var12 + 6, -2137480525, false);
      }

      for (ConfigsScreen$Button var25 : this.buttons) {
         boolean var27 = var25.contains(mouseX, mouseY);
         int var16 = this.view == ConfigsScreen$View.LOAD && var25.label.equals("X") ? (var27 ? -12320768 : 3342336) : (var27 ? -669242818 : -1206839003);
         int var17 = this.view == ConfigsScreen$View.LOAD && var25.label.equals("X") ? (var27 ? -48043 : -2137480525) : -1511947;
         Obj_dr.HwidGen(
            this.proj,
            (float)var25.Module_AutoInvTotem,
            (float)var25.Module_AutoTotem,
            (float)var25.Module_AutoDoubleHand,
            (float)var25.Module,
            6.0F,
            var16,
            false
         );
         if (!var25.label.equals("X")) {
            Obj_dr.HwidGen(
               this.proj, (float)(var25.Module_AutoInvTotem + 2), (float)(var25.Module_AutoTotem + 3), 3.0F, (float)(var25.Module - 6), 1.5F, var8, false
            );
         }

         Obj_dr.HwidGen(
            this.proj,
            (float)var25.Module_AutoInvTotem,
            (float)var25.Module_AutoTotem,
            (float)var25.Module_AutoDoubleHand,
            (float)var25.Module,
            6.0F,
            1.0F,
            var27 ? var8 : 1075981632,
            false
         );
         int var18 = this.textRenderer.getWidth(var25.label);
         int var19 = var25.Module_AutoTotem + (var25.Module - 9) / 2;
         int var20 = var25.Module_AutoInvTotem + (var25.Module_AutoDoubleHand - var18) / 2;
         context.drawText(this.textRenderer, var25.label, var20, var19, var17, false);
      }

      String var23 = "ESC to close";
      int var26 = this.textRenderer.getWidth(var23);
      context.drawText(this.textRenderer, var23, (this.width - var26) / 2, var7 + var5 + 6, -2137480525, false);
      if (this.toast != null && System.currentTimeMillis() < this.toastUntil) {
         int var28 = this.textRenderer.getWidth(this.toast) + 24;
         byte var29 = 22;
         int var30 = (this.width - var28) / 2;
         int var31 = var7 - var29 - 10;
         Obj_dr.HwidGen(this.proj, (float)var30, (float)var31, (float)var28, (float)var29, 6.0F, -536870912, false);
         Obj_dr.HwidGen(this.proj, (float)var30, (float)var31, (float)var28, (float)var29, 6.0F, 1.0F, var8, false);
         context.drawText(this.textRenderer, this.toast, var30 + 12, var31 + (var29 - 9) / 2, -1511947, false);
      }
   }

   private void drawField(DrawContext drawContext, int i, int j, int k, int l, String string, int m, boolean bl) {
      Obj_dr.HwidGen(this.proj, (float)i, (float)j, (float)k, (float)l, 6.0F, -1207300068, false);
      Obj_dr.HwidGen(this.proj, (float)i, (float)j, (float)k, (float)l, 6.0F, 1.0F, bl ? m : 1075981632, false);
      if (string == null) {
         string = "";
      }

      String var9 = string;
      int var10 = k - 12;

      while (this.textRenderer.getWidth(var9) > var10 && var9.length() > 1) {
         var9 = var9.substring(1);
      }

      int var11 = j + (l - 9) / 2;
      drawContext.drawText(this.textRenderer, var9, i + 6, var11, -1511947, false);
      if (bl) {
         long var12 = System.currentTimeMillis() / 500L;
         if ((var12 & 1L) == 0L) {
            int var14 = i + 6 + this.textRenderer.getWidth(var9);
            drawContext.fill(var14, var11 - 1, var14 + 1, var11 + 9, m);
         }
      }
   }

   public boolean mouseClicked(Click click, boolean doubled) {
      if (click.button() == 0) {
         int var3 = (int)click.x();
         int var4 = (int)click.y();

         for (ConfigsScreen$Button var6 : this.buttons) {
            if (var6.contains(var3, var4)) {
               var6.action.run();
               return true;
            }
         }
      }

      return super.mouseClicked(click, doubled);
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      if (this.view == ConfigsScreen$View.LOAD && !this.currentList.isEmpty()) {
         int var9 = Math.max(0, this.currentList.size() - 6);
         this.listScroll = Math.max(0, Math.min(var9, this.listScroll - (int)Math.signum(verticalAmount)));
         this.rebuild();
         return true;
      } else {
         return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
      }
   }

   public boolean charTyped(CharInput input) {
      if (this.view == ConfigsScreen$View.CREATE || this.view == ConfigsScreen$View.REDEEM) {
         String var2 = input.asString();
         if (var2 != null && !var2.isEmpty()) {
            StringBuilder var3 = new StringBuilder(this.inputText);
            var2.codePoints().filter(i -> !Character.isISOControl(i)).forEach(var3::appendCodePoint);
            this.inputText = var3.toString();
            return true;
         }
      }

      return super.charTyped(input);
   }

   public boolean keyPressed(KeyInput input) {
      if (this.view == ConfigsScreen$View.CREATE || this.view == ConfigsScreen$View.REDEEM) {
         int var2 = input.getKeycode();
         if (var2 == 259) {
            if (!this.inputText.isEmpty()) {
               int var7 = this.inputText.offsetByCodePoints(this.inputText.length(), -1);
               this.inputText = this.inputText.substring(0, var7);
            }

            return true;
         }

         if (var2 == 257 || var2 == 335) {
            if (this.view == ConfigsScreen$View.CREATE) {
               if (ConfigMan.Module(this.inputText)) {
                  this.showToast("Saved as " + ConfigMan.sanitize(this.inputText), true);
                  this.view = ConfigsScreen$View.MAIN;
                  this.rebuild();
               } else {
                  this.showToast("Invalid name", false);
               }
            } else if (ConfigMan.Module_ActiveModules(this.inputText)) {
               this.showToast("Config applied", true);
               this.view = ConfigsScreen$View.MAIN;
               this.rebuild();
            } else {
               this.showToast("Invalid code", false);
            }

            return true;
         }

         if (var2 == 86) {
            long var3 = MinecraftClient.getInstance().getWindow().getHandle();
            boolean var5 = GLFW.glfwGetKey(var3, 341) == 1 || GLFW.glfwGetKey(var3, 345) == 1;
            if (var5) {
               String var6 = ConfigMan.Module_DoubleAnchor();
               if (var6 != null) {
                  this.inputText = this.inputText + var6;
               }

               return true;
            }
         }
      }

      return super.keyPressed(input);
   }

   public boolean shouldPause() {
      return false;
   }

   public void close() {
      if (this.closing) {
         super.close();
      } else {
         this.closing = true;
         super.close();
         if (this.module != null && this.module.HwidGen()) {
            this.module.HwidGen(false);
         }
      }
   }
}
