package com.zelith.gui;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;

public class ZelithChatScreen extends ChatScreen {
   public ZelithChatScreen(String string) {
      super(string, false);
   }

   public boolean mouseClicked(Click click, boolean doubled) {
      double var3 = click.x();
      double var5 = click.y();
      int var7 = click.button();
      if (var7 == 0) {
         if (Module_SpotifyHUD.HwidGen(var3, var5)) {
            return true;
         }

         if (HudEditor.INSTANCE.onMouseClick(var3, var5, var7)) {
            return true;
         }
      }

      return super.mouseClicked(click, doubled);
   }

   public boolean mouseDragged(Click click, double offsetX, double offsetY) {
      if (HudEditor.INSTANCE.isDragging()) {
         HudEditor.INSTANCE.onMouseDrag(click.x(), click.y());
         return true;
      } else {
         return super.mouseDragged(click, offsetX, offsetY);
      }
   }

   public boolean mouseReleased(Click click) {
      HudEditor.INSTANCE.onMouseRelease();
      return super.mouseReleased(click);
   }

   public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
      super.render(context, mouseX, mouseY, deltaTicks);
      HudEditor.INSTANCE.render(context, mouseX, mouseY);
   }
}
