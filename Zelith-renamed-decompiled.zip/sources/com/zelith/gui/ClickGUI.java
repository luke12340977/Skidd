package com.zelith.gui;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.entity.EntityType;
import net.minecraft.item.Item;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ClickGUI extends Screen {
   private static final g[] CATEGORIES = new Category[]{Category.c, Category.KeyFile, Category.LicenseState, Category.HwidGen, Category.Module_f};
   private float uiScale = 1.0F;
   private static final int PANEL_BG = -401534696;
   private static final int PANEL_TOP = -266790621;
   private static final int ROW_BG = 1118488;
   private static final int ROW_HOVER = 1999120950;
   private static int ROW_ACTIVE = -5620494;
   private static final int OUTLINE = -1439287222;
   private static final int TEXT = -1513234;
   private static final int MUTED = -7368550;
   private static final int DARK = -15921901;
   private static final int SHADOW = 1996488704;
   public static ClickGUI INSTANCE;
   private int verticalScroll = 0;
   private h popupModule = null;
   private boolean settingsView = false;
   private int popupX = 0;
   private int popupY = 0;
   private int popupScroll = 0;
   private h listeningBind = null;
   private f listeningActivationBind = null;
   private dd editingString = null;
   private dd draggingNumber = null;
   private h draggingNumberModule = null;
   private dd draggingColor = null;
   private int draggingColorChannel = -1;
   private dd expandedChoice = null;
   private dd collectionSearchSetting = null;
   private boolean collectionSearchActive = false;
   private String collectionSearch = "";
   private String searchQuery = "";
   private boolean searchFocused = false;
   private final EnumMap collapsedCategories = new EnumMap<>(Category.class);
   private final EnumMap categoryOffsets = new EnumMap<>(Category.class);
   private g draggingCategory = null;
   private int dragGrabX = 0;
   private int dragGrabY = 0;
   private int dragStartMouseX = 0;
   private int dragStartMouseY = 0;
   private boolean categoryDragMoved = false;
   private final int[] searchOffset = new int[2];
   private boolean draggingSearch = false;
   private int searchGrabX = 0;
   private int searchGrabY = 0;
   private int searchDragStartMouseX = 0;
   private int searchDragStartMouseY = 0;
   private boolean searchDragMoved = false;
   private final HashMap animValues = new HashMap();
   private long lastAnimNanos = 0L;
   private float frameDt = 0.016666668F;

   private float scale() {
      return 1.0F;
   }

   private float menuScale() {
      return Math.min(1.0F, Module_zelith.Module() / 6.0F);
   }

   private int panelW() {
      return Math.round(148.0F * this.scale());
   }

   private int headerH() {
      return Math.max(20, Math.round(29.0F * this.scale()));
   }

   private int rowH() {
      return Math.max(16, Math.round(21.0F * this.scale()));
   }

   private int panelGap() {
      return Math.max(6, Math.round(12.0F * this.scale()));
   }

   private int startX() {
      return Math.round(18.0F * this.scale());
   }

   private int startY() {
      return Math.round(36.0F * this.scale());
   }

   private int settingsW() {
      return Math.max(180, Math.round(292.0F * this.scale()));
   }

   private int settingH() {
      return Math.max(16, Math.round(24.0F * this.scale()));
   }

   private int scrollStep() {
      return Math.max(8, Math.round(24.0F * this.scale()));
   }

   private int uiWidth() {
      return Math.round(this.width / Math.max(1.0E-4F, this.uiScale));
   }

   private int uiHeight() {
      return Math.round(this.height / Math.max(1.0E-4F, this.uiScale));
   }

   private void refreshUiScale() {
      this.uiScale = Math.min(this.width / 960.0F, this.height / 540.0F) * this.menuScale();
   }

   public ClickGUI() {
      super(Text.literal("zelith Menu"));
      INSTANCE = this;
   }

   public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
      int var5 = Module_zelith.Category();
      ROW_ACTIVE = 0xFF000000 | var5 & 16777215;
      this.updateAnimDt();
      this.verticalScroll = this.clamp(this.verticalScroll, this.minScroll(), 0);
      this.refreshUiScale();
      int var6 = Math.round(mouseX / this.uiScale);
      int var7 = Math.round(mouseY / this.uiScale);
      if (this.settingsView && this.popupModule != null) {
         context.fill(0, 0, this.width, this.height, -1728053248);
      }

      context.getMatrices().pushMatrix();
      context.getMatrices().scale(this.uiScale, this.uiScale);
      if (this.settingsView && this.popupModule != null) {
         this.drawSettingsPopup(context, var6, var7, var5);
      } else {
         for (int var8 = 0; var8 < CATEGORIES.length; var8++) {
            int[] var9 = this.categoryPos(CATEGORIES[var8]);
            this.drawCategoryPanel(context, CATEGORIES[var8], var9[0], var9[1], var6, var7, var5);
         }

         int var10 = this.searchPanelX();
         this.drawSearchPanel(context, var10, this.searchPanelY(), var6, var7, var5);
      }

      context.getMatrices().popMatrix();
      this.pollBindKeys();
   }

   private void drawCategoryPanel(DrawContext drawContext, g arg, int i, int j, int k, int l, int m) {
      List var8 = this.modules(arg);
      boolean var9 = this.isCollapsed(arg);
      int var10 = this.headerH() + (var9 ? 4 : var8.size() * this.rowH() + 6);
      if (Module_zelith.Module()) {
         Obj_dr.HwidGen(drawContext, (float)(i + 4), (float)(j + 5), (float)this.panelW(), (float)var10, 8.0F, 1996488704, false);
      }

      Obj_dr.HwidGen(drawContext, (float)i, (float)j, (float)this.panelW(), (float)var10, 8.0F, -401534696, false);
      Obj_dr.HwidGen(drawContext, (float)i, (float)j, (float)this.panelW(), (float)var10, 8.0F, 1.0F, -1439287222, false);
      Obj_dr.HwidGen(drawContext, (float)i, (float)j, (float)this.panelW(), (float)this.headerH(), 8.0F, 8.0F, 3.0F, 3.0F, false, -266790621);
      Obj_dr.HwidGen(drawContext, (float)(i + 8), (float)(j + this.headerH() - 2), (float)(this.panelW() - 16), 1.0F, 0.5F, m, false);
      drawContext.drawText(this.textRenderer, arg.c().toUpperCase(Locale.ROOT), i + 12, j + 9, -1513234, false);
      if (!var9) {
         int var11 = j + this.headerH();

         for (Module var13 : var8) {
            boolean var14 = this.in(k, l, i, var11, this.panelW(), this.rowH());
            float var15 = this.anim("hover/" + arg.name() + "/" + var13.c(), var14 ? 1.0F : 0.0F, 16.0F);
            float var16 = this.anim("enabled/" + arg.name() + "/" + var13.c(), var13.HwidGen() ? 1.0F : 0.0F, 14.0F);
            int var17 = this.blend(this.blend(1118488, 1999120950, var15), ROW_ACTIVE, var16);
            if (var17 != 0) {
               Obj_dr.HwidGen(drawContext, (float)(i + 4), (float)(var11 + 1), (float)(this.panelW() - 8), (float)(this.rowH() - 2), 5.0F, var17, false);
            }

            int var18 = var13.HwidGen() ? -1 : -7368550;
            drawContext.drawText(this.textRenderer, this.trim(var13.c().toUpperCase(Locale.ROOT), this.panelW() - 16), i + 10, var11 + 6, var18, false);
            String var19 = getKeyDisplayNameStatic(var13.KeyFile());
            if (var13.HwidGen() && !var19.isEmpty()) {
               drawContext.drawText(this.textRenderer, var19, i + this.panelW() - 8 - this.textRenderer.getWidth(var19), var11 + 6, -2308609, false);
            }

            var11 += this.rowH();
         }
      }
   }

   private void drawSettingsPopup(DrawContext drawContext, int i, int j, int k) {
      int var5 = Math.min(Math.max(220, this.uiHeight() - 70), Math.max(136, this.popupContentHeight() + 54));
      this.popupX = (this.uiWidth() - this.settingsW()) / 2;
      this.popupY = (this.uiHeight() - var5) / 2;
      if (Module_zelith.Module()) {
         Obj_dr.HwidGen(drawContext, (float)(this.popupX + 5), (float)(this.popupY + 7), (float)this.settingsW(), (float)var5, 10.0F, 1996488704, false);
      }

      Obj_dr.HwidGen(drawContext, (float)this.popupX, (float)this.popupY, (float)this.settingsW(), (float)var5, 10.0F, -401534696, false);
      Obj_dr.HwidGen(drawContext, (float)this.popupX, (float)this.popupY, (float)this.settingsW(), (float)var5, 10.0F, 1.2F, k, false);
      Obj_dr.HwidGen(drawContext, (float)this.popupX, (float)this.popupY, (float)this.settingsW(), 42.0F, 10.0F, 10.0F, 4.0F, 4.0F, false, -266790621);
      Obj_dr.HwidGen(drawContext, (float)(this.popupX + 12), (float)(this.popupY + 40), (float)(this.settingsW() - 24), 1.0F, 0.5F, k, false);
      drawContext.drawText(
         this.textRenderer,
         this.trim(this.popupModule.c().toUpperCase(Locale.ROOT), this.settingsW() - 24),
         this.popupX + 12,
         this.popupY + 10,
         -1513234,
         false
      );
      drawContext.drawText(this.textRenderer, "SETTINGS - ESC TO GO BACK", this.popupX + 12, this.popupY + 24, -7368550, false);
      int var6 = this.popupY + 52;
      int var7 = var5 - 62;
      int var8 = Math.max(0, this.popupContentHeight() - var7);
      this.popupScroll = this.clamp(this.popupScroll, 0, var8);
      int var9 = var6 - this.popupScroll;
      var9 = this.drawBindRows(drawContext, var9, i, j, k);

      for (Setting var11 : this.popupModule.HwidGen()) {
         if (var11.K()) {
            int var12 = this.settingRowHeight(var11);
            if (var9 + var12 >= var6 && var9 <= var6 + var7) {
               this.drawSetting(drawContext, var11, this.popupX + 10, var9, this.settingsW() - 20, i, j, k);
            }

            var9 += var12 + 6;
         }
      }

      if (var8 > 0) {
         float var14 = Math.max(18.0F, var7 * ((float)var7 / (var7 + var8)));
         float var15 = var6 + (var7 - var14) * ((float)this.popupScroll / var8);
         Obj_dr.HwidGen(drawContext, (float)(this.popupX + this.settingsW() - 6), (float)var6, 2.0F, (float)var7, 1.0F, -15921901, false);
         Obj_dr.HwidGen(drawContext, (float)(this.popupX + this.settingsW() - 7), var15, 4.0F, var14, 2.0F, k, false);
      }
   }

   private int drawBindRows(DrawContext drawContext, int i, int j, int k, int l) {
      this.drawSimpleRow(
         drawContext,
         this.popupX + 10,
         i,
         this.settingsW() - 20,
         "BIND",
         this.listeningBind == this.popupModule ? "PRESS KEY" : this.none(this.popupModule.KeyFile()),
         j,
         k,
         l
      );
      i += this.settingH() + 6;
      if (this.popupModule instanceof Module_f var6) {
         this.drawSimpleRow(
            drawContext,
            this.popupX + 10,
            i,
            this.settingsW() - 20,
            "ACTIVATION",
            this.listeningActivationBind == var6 ? "PRESS KEY" : this.none(var6.HwidGen()),
            j,
            k,
            l
         );
         i += this.settingH() + 6;
      }

      return i;
   }

   private void drawSetting(DrawContext drawContext, dd arg, int i, int j, int k, int l, int m, int n) {
      if (arg instanceof Settingdc) {
         drawContext.drawText(this.textRenderer, arg.c().toUpperCase(Locale.ROOT), i + 2, j + 6, n, false);
         Obj_dr.HwidGen(drawContext, (float)i, (float)(j + 20), (float)k, 1.0F, 0.5F, -1439287222, false);
      } else {
         Object var9 = arg.HwidGen();
         if (var9 instanceof Boolean var10) {
            this.drawSimpleRow(drawContext, i, j, k, arg.c(), var10 ? "ON" : "OFF", l, m, var10 ? n : -7368550);
         } else if (this.isNumberSetting(arg)) {
            this.drawSlider(drawContext, arg, i, j, k, n);
         } else if (arg instanceof Misc_cy var11) {
            this.drawSimpleRow(drawContext, i, j, k, arg.c(), (String)var11.HwidGen(), l, m, n);
         } else if (arg instanceof Settingdb var12) {
            this.drawChoiceSetting(drawContext, var12, i, j, k, l, m, n);
         } else if (arg instanceof Settingda var13) {
            this.drawChoiceSetting(drawContext, var13, i, j, k, l, m, n);
         } else if (arg instanceof SettingBlock var14) {
            this.drawCollectionSetting(drawContext, arg, var14.Module_AutoCrystal(), i, j, k, l, m, n);
         } else if (arg instanceof SettingMob var15) {
            this.drawCollectionSetting(drawContext, arg, var15.Module_AutoCrystal(), i, j, k, l, m, n);
         } else if (arg instanceof SettingItem var16) {
            this.drawCollectionSetting(drawContext, arg, var16.Module_AutoCrystal(), i, j, k, l, m, n);
         } else if (var9 instanceof Color var17) {
            this.drawColorSetting(drawContext, arg, var17, i, j, k, l, m, n);
         } else if (var9 instanceof String var18) {
            this.drawSimpleRow(drawContext, i, j, k, arg.c(), this.editingString == arg ? var18 + "_" : var18, l, m, n);
         } else if (arg instanceof Setting_cu var19) {
            this.drawSimpleRow(drawContext, i, j, k, var19.c(), (String)var19.HwidGen(), l, m, n);
         } else {
            this.drawSimpleRow(drawContext, i, j, k, arg.c(), String.valueOf(var9), l, m, n);
         }
      }
   }

   private void drawSimpleRow(DrawContext drawContext, int i, int j, int k, String string, String string2, int l, int m, int n) {
      boolean var10 = this.in(l, m, i, j, k, this.settingH());
      Obj_dr.HwidGen(drawContext, (float)i, (float)j, (float)k, (float)this.settingH(), 7.0F, var10 ? 1999120950 : -2011884256, false);
      drawContext.drawText(this.textRenderer, this.trim(string.toUpperCase(Locale.ROOT), k / 2), i + 8, j + 8, -1513234, false);
      String var11 = this.trim(string2 != null && !string2.isEmpty() ? string2.toUpperCase(Locale.ROOT) : "NONE", k / 2 - 8);
      drawContext.drawText(this.textRenderer, var11, i + k - 8 - this.textRenderer.getWidth(var11), j + 8, n, false);
   }

   private void drawSlider(DrawContext drawContext, dd arg, int i, int j, int k, int l) {
      Obj_dr.HwidGen(drawContext, (float)i, (float)j, (float)k, (float)(this.settingH() + 10), 7.0F, -2011884256, false);
      drawContext.drawText(this.textRenderer, arg.c().toUpperCase(Locale.ROOT), i + 8, j + 6, -1513234, false);
      String var7 = this.formatNumber(arg.HwidGen());
      drawContext.drawText(this.textRenderer, var7, i + k - 8 - this.textRenderer.getWidth(var7), j + 6, -7368550, false);
      int var8 = i + 8;
      int var9 = j + 24;
      int var10 = k - 16;
      float var11 = this.numberPercent(arg);
      Obj_dr.HwidGen(drawContext, (float)var8, (float)var9, (float)var10, 4.0F, 2.0F, -15921901, false);
      Obj_dr.HwidGen(drawContext, (float)var8, (float)var9, (float)Math.max(4, Math.round(var10 * var11)), 4.0F, 2.0F, l, false);
   }

   private void drawColorSetting(DrawContext drawContext, dd arg, Color color, int i, int j, int k, int l, int m, int n) {
      this.drawSimpleRow(drawContext, i, j, k, arg.c(), "#" + Integer.toHexString(color.getRGB()).substring(2).toUpperCase(Locale.ROOT), l, m, n);
      Obj_dr.HwidGen(drawContext, (float)(i + k - 21), (float)(j + 6), 12.0F, 12.0F, 3.0F, color.getRGB(), false);
      if (this.expandedChoice == arg) {
         ClickGUI$ColorPickerLayout var10 = this.colorPickerLayout(i, j, k);
         float[] var11 = Color.RGBtoHSB(color.getRed(), color.getGreen(), color.getBlue(), null);
         this.drawColorField(drawContext, var10.fieldX, var10.fieldY, var10.fieldW, var10.fieldH, var11[0]);
         this.drawHueBar(drawContext, var10.hueX, var10.hueY, var10.hueW, var10.hueH);
         int var12 = var10.fieldX + Math.round(var11[1] * var10.fieldW);
         int var13 = var10.fieldY + Math.round((1.0F - var11[2]) * var10.fieldH);
         Obj_dr.HwidGen(drawContext, (float)(var12 - 3), (float)(var13 - 3), 6.0F, 6.0F, 3.0F, 1.5F, -1, false);
         Obj_dr.HwidGen(
            drawContext, (float)(var10.hueX + Math.round(var11[0] * var10.hueW) - 2), (float)(var10.hueY - 2), 4.0F, (float)(var10.hueH + 4), 2.0F, -1, false
         );
      }
   }

   private void drawColorField(DrawContext drawContext, int i, int j, int k, int l, float f) {
      for (byte var7 = 0; var7 < k; var7 += 3) {
         float var8 = (float)var7 / Math.max(1, k - 1);

         for (byte var9 = 0; var9 < l; var9 += 3) {
            float var10 = 1.0F - (float)var9 / Math.max(1, l - 1);
            int var11 = Color.HSBtoRGB(f, var8, var10) | 0xFF000000;
            Obj_dr.HwidGen(drawContext, (float)(i + var7), (float)(j + var9), (float)Math.min(3, k - var7), (float)Math.min(3, l - var9), 0.0F, var11, false);
         }
      }

      Obj_dr.HwidGen(drawContext, (float)i, (float)j, (float)k, (float)l, 5.0F, 1.0F, -1439287222, false);
   }

   private void drawHueBar(DrawContext drawContext, int i, int j, int k, int l) {
      for (byte var6 = 0; var6 < k; var6 += 3) {
         float var7 = (float)var6 / Math.max(1, k - 1);
         int var8 = Color.HSBtoRGB(var7, 1.0F, 1.0F) | 0xFF000000;
         Obj_dr.HwidGen(drawContext, (float)(i + var6), (float)j, (float)Math.min(3, k - var6), (float)l, 0.0F, var8, false);
      }

      Obj_dr.HwidGen(drawContext, (float)i, (float)j, (float)k, (float)l, 5.0F, 1.0F, -1439287222, false);
   }

   private void drawChoiceSetting(DrawContext drawContext, db arg, int i, int j, int k, int l, int m, int n) {
      this.drawSimpleRow(drawContext, i, j, k, arg.c(), arg.Module_AutoCrystal(), l, m, n);
      if (this.expandedChoice == arg) {
         int var9 = j + this.settingH() + 5;

         for (Rec_cz var11 : arg.Module_f()) {
            this.drawChoiceRow(drawContext, i + 6, var9, k - 12, var11.Module_AutoInvTotem(), arg.HwidGen(var11), l, m, n);
            var9 += 20;
         }
      }
   }

   private void drawChoiceSetting(DrawContext drawContext, da arg, int i, int j, int k, int l, int m, int n) {
      this.drawSimpleRow(drawContext, i, j, k, arg.c(), arg.Module_AutoCrystal(), l, m, n);
      if (this.expandedChoice == arg) {
         int var9 = j + this.settingH() + 5;

         for (Rec_cz var11 : arg.Module_f()) {
            this.drawChoiceRow(drawContext, i + 6, var9, k - 12, var11.Module_AutoInvTotem(), arg.HwidGen((cz)var11), l, m, n);
            var9 += 20;
         }
      }
   }

   private void drawCollectionSetting(DrawContext drawContext, dd arg, String string, int i, int j, int k, int l, int m, int n) {
      this.drawSimpleRow(drawContext, i, j, k, arg.c(), string, l, m, n);
      if (this.expandedChoice == arg) {
         int var10 = j + this.settingH() + 5;
         this.drawCollectionSearch(drawContext, i + 6, var10, k - 12, arg, n);
         var10 += 22;
         if (arg instanceof SettingBlock var11) {
            for (Block var16 : var11.KeyFile(this.searchFor(arg)).stream().sorted(Comparator.comparing(block -> !var11.KeyFile(block))).limit(8L).toList()) {
               this.drawChoiceRow(drawContext, i + 6, var10, k - 12, var11.KeyFile(var16), var11.KeyFile(var16), l, m, n);
               var10 += 20;
            }
         } else if (arg instanceof SettingMob var12) {
            for (EntityType var23 : var12.KeyFile(this.searchFor(arg))
               .stream()
               .sorted(Comparator.comparing(entityType -> !var12.c(entityType)))
               .limit(8L)
               .toList()) {
               this.drawChoiceRow(drawContext, i + 6, var10, k - 12, var12.HwidGen(var23), var12.c(var23), l, m, n);
               var10 += 20;
            }
         } else if (arg instanceof SettingItem var13) {
            List var20 = var13.KeyFile(this.searchFor(arg)).stream().limit(8L).toList();
            Item var22 = var13.HwidGen();

            for (Item var17 : var20) {
               this.drawChoiceRow(drawContext, i + 6, var10, k - 12, var13.HwidGen(var17), var17 == var22, l, m, n);
               var10 += 20;
            }
         }
      }
   }

   private void drawCollectionSearch(DrawContext drawContext, int i, int j, int k, dd arg, int l) {
      boolean var7 = this.collectionSearchActive && this.collectionSearchSetting == arg;
      Obj_dr.HwidGen(drawContext, (float)i, (float)j, (float)k, 18.0F, 5.0F, -1156772589, false);
      Obj_dr.HwidGen(drawContext, (float)i, (float)j, (float)k, 18.0F, 5.0F, 1.0F, var7 ? l : -1439287222, false);
      String var8 = this.searchFor(arg).isEmpty() ? "SEARCH..." : this.searchFor(arg);
      if (var7 && (System.currentTimeMillis() / 500L & 1L) == 0L) {
         var8 = var8 + "_";
      }

      drawContext.drawText(
         this.textRenderer, this.trim(var8.toUpperCase(Locale.ROOT), k - 14), i + 7, j + 5, this.searchFor(arg).isEmpty() && !var7 ? -7368550 : -1513234, false
      );
   }

   private void drawChoiceRow(DrawContext drawContext, int i, int j, int k, String string, boolean bl, int l, int m, int n) {
      boolean var10 = this.in(l, m, i, j, k, 18);
      Obj_dr.HwidGen(drawContext, (float)i, (float)j, (float)k, 18.0F, 6.0F, bl ? ROW_ACTIVE : (var10 ? 1999120950 : -15921901), false);
      drawContext.drawText(this.textRenderer, this.trim(string.toUpperCase(Locale.ROOT), k - 26), i + 7, j + 5, bl ? -1 : -7368550, false);
   }

   public boolean mouseClicked(Click click, boolean doubled) {
      this.refreshUiScale();
      int var3 = (int)Math.round(click.x() / this.uiScale);
      int var4 = (int)Math.round(click.y() / this.uiScale);
      int var5 = click.button();
      if (!this.settingsView && var5 == 0) {
         int var6 = this.searchPanelX();
         int var7 = this.searchPanelY();
         if (this.in(var3, var4, var6, var7, this.panelW(), this.headerH()) && !this.searchInputAt(var3, var4)) {
            this.draggingSearch = true;
            this.searchGrabX = var3 - var6;
            this.searchGrabY = var4 - var7;
            this.searchDragStartMouseX = var3;
            this.searchDragStartMouseY = var4;
            this.searchDragMoved = false;
            return true;
         }

         g var8 = this.categoryHeaderAt(var3, var4);
         if (var8 != null) {
            int[] var9 = this.categoryPos(var8);
            this.draggingCategory = var8;
            this.dragGrabX = var3 - var9[0];
            this.dragGrabY = var4 - var9[1];
            this.dragStartMouseX = var3;
            this.dragStartMouseY = var4;
            this.categoryDragMoved = false;
            return true;
         }
      }

      h var10 = this.moduleAt(var3, var4);
      if (!this.settingsView && var10 != null) {
         if (var5 == 0) {
            var10.c();
            return true;
         }

         if (var5 == 1) {
            this.popupModule = var10;
            this.settingsView = true;
            this.popupScroll = 0;
            this.expandedChoice = null;
            this.editingString = null;
            this.collectionSearchActive = false;
            return true;
         }
      }

      if (!this.settingsView) {
         if (var5 == 0 && this.searchInputAt(var3, var4)) {
            this.searchFocused = true;
            return true;
         }

         if (!this.searchFocused) {
            this.searchFocused = false;
         }

         h var11 = this.searchModuleAt(var3, var4);
         if (var11 != null) {
            if (var5 == 0) {
               var11.c();
               return true;
            }

            if (var5 == 1) {
               this.popupModule = var11;
               this.settingsView = true;
               this.popupScroll = 0;
               this.expandedChoice = null;
               this.editingString = null;
               this.collectionSearchActive = false;
               return true;
            }
         }
      }

      if (this.settingsView && this.popupModule != null && this.handlePopupClick(var3, var4, var5)) {
         return true;
      } else {
         if (!this.settingsView && var5 == 0 && !this.searchInputAt(var3, var4)) {
            this.searchFocused = false;
         }

         return super.mouseClicked(click, doubled);
      }
   }

   private boolean handlePopupClick(int i, int j, int k) {
      int var4 = this.popupX + 10;
      int var5 = this.settingsW() - 20;
      int var6 = this.popupY + 52 - this.popupScroll;
      if (this.in(i, j, var4, var6, var5, this.settingH())) {
         this.listeningBind = this.popupModule;
         this.listeningActivationBind = null;
         this.editingString = null;
         return true;
      } else {
         var6 += this.settingH() + 6;
         if (this.popupModule instanceof Module_f var7) {
            if (this.in(i, j, var4, var6, var5, this.settingH())) {
               this.listeningActivationBind = var7;
               this.listeningBind = null;
               this.editingString = null;
               return true;
            }

            var6 += this.settingH() + 6;
         }

         for (Setting var12 : this.popupModule.HwidGen()) {
            if (var12.K()) {
               int var9 = this.settingRowHeight(var12);
               if (this.in(i, j, var4, var6, var5, var9)) {
                  if (k == 1) {
                     this.clickSetting(var12, i, j, var4, var6, var5, 1);
                  } else if (k == 0) {
                     this.clickSetting(var12, i, j, var4, var6, var5);
                  }

                  return true;
               }

               var6 += var9 + 6;
            }
         }

         return this.in(i, j, this.popupX, this.popupY, this.settingsW(), Math.min(320, this.popupContentHeight() + 48));
      }
   }

   private void clickSetting(dd arg, int i, int j, int k, int l, int m) {
      this.clickSetting(arg, i, j, k, l, m, 0);
   }

   private void clickSetting(dd arg, int i, int j, int k, int l, int m, int n) {
      this.editingString = null;
      this.collectionSearchActive = false;
      Object var8 = arg.HwidGen();
      if (var8 instanceof Boolean var9) {
         arg.HwidGen(!var9);
      } else if (this.isNumberSetting(arg)) {
         this.draggingNumber = arg;
         this.draggingNumberModule = this.popupModule;
         this.updateNumber(arg, i, k, m);
      } else if (arg instanceof Misc_cy var10) {
         if (n == 1) {
            var10.Enum_ak();
         } else {
            var10.Module_BoneDropper();
         }
      } else if (arg instanceof Settingdb var11) {
         if (this.expandedChoice == var11) {
            int var14 = this.choiceIndexAt(j, l);
            if (var14 >= 0 && var14 < var11.Module_f().size()) {
               var11.Module_Hud(((Rec_cz)var11.Module_f().get(var14)).Module_AutoDoubleHand());
            }

            this.expandedChoice = null;
         } else {
            this.expandedChoice = var11;
         }
      } else if (arg instanceof Settingda var12) {
         if (this.expandedChoice == var12) {
            int var15 = this.choiceIndexAt(j, l);
            if (var15 >= 0 && var15 < var12.Module_f().size()) {
               var12.Module_Friends(((Rec_cz)var12.Module_f().get(var15)).Module_AutoDoubleHand());
            }
         } else {
            this.expandedChoice = var12;
         }
      } else if (!(arg instanceof SettingBlock) && !(arg instanceof SettingMob) && !(arg instanceof SettingItem)) {
         if (arg instanceof Setting_cu var13) {
            var13.Toast_ai();
         } else if (var8 instanceof Color) {
            if (this.expandedChoice == arg) {
               int var17 = this.colorPickerTargetAt(i, j, k, l, m);
               if (var17 >= 0) {
                  this.draggingColor = arg;
                  this.draggingColorChannel = var17;
                  this.updateColorPicker(this.draggingColor, var17, i, j, k, l, m);
               } else {
                  this.expandedChoice = null;
               }
            } else {
               this.expandedChoice = arg;
            }
         } else if (var8 instanceof String) {
            this.editingString = arg;
         }
      } else if (this.expandedChoice == arg) {
         int var16 = l + this.settingH() + 5;
         if (this.in(i, j, k + 6, var16, m - 12, 18)) {
            this.collectionSearchSetting = arg;
            this.collectionSearchActive = true;
            return;
         }

         this.clickCollection(arg, this.choiceIndexAt(j, l));
      } else {
         this.expandedChoice = arg;
         this.collectionSearchSetting = arg;
         this.collectionSearch = "";
      }
   }

   private void clickCollection(dd arg, int i) {
      if (i >= 0 && i < 8) {
         if (arg instanceof SettingBlock var3) {
            List var6 = var3.KeyFile(this.searchFor(arg)).stream().sorted(Comparator.comparing(block -> !var3.KeyFile(block))).limit(8L).toList();
            if (i < var6.size()) {
               var3.HwidGen((Block)var6.get(i));
            }
         } else if (arg instanceof SettingMob var4) {
            List var7 = var4.KeyFile(this.searchFor(arg)).stream().sorted(Comparator.comparing(entityType -> !var4.c(entityType))).limit(8L).toList();
            if (i < var7.size()) {
               var4.HwidGen((EntityType)var7.get(i));
            }
         } else if (arg instanceof SettingItem var5) {
            List var8 = var5.KeyFile(this.searchFor(arg)).stream().limit(8L).toList();
            if (i >= 0 && i < var8.size()) {
               var5.c((Item)var8.get(i));
            }
         }
      }
   }

   public boolean mouseDragged(Click click, double offsetX, double offsetY) {
      this.refreshUiScale();
      double var6 = click.x() / this.uiScale;
      double var8 = click.y() / this.uiScale;
      if (this.draggingNumber != null) {
         this.updateNumber(this.draggingNumber, var6, this.popupX + 10, this.settingsW() - 20);
         return true;
      } else if (this.draggingColor != null) {
         this.updateColorPicker(this.draggingColor, this.draggingColorChannel, var6, var8, this.popupX + 10, 0, this.settingsW() - 20);
         return true;
      } else if (this.draggingCategory != null) {
         int var16 = (int)var6 - this.dragStartMouseX;
         int var17 = (int)var8 - this.dragStartMouseY;
         if (Math.abs(var16) > 2 || Math.abs(var17) > 2) {
            this.categoryDragMoved = true;
         }

         int[] var18 = this.categoryOffsets.computeIfAbsent(this.draggingCategory, arg -> new int[2]);
         int var13 = 0;

         for (int var14 = 0; var14 < CATEGORIES.length; var14++) {
            if (CATEGORIES[var14] == this.draggingCategory) {
               var13 = var14;
               break;
            }
         }

         int var19 = this.startX() + var13 * (this.panelW() + this.panelGap());
         int var15 = this.startY() + this.verticalScroll;
         var18[0] = (int)var6 - this.dragGrabX - var19;
         var18[1] = (int)var8 - this.dragGrabY - var15;
         return true;
      } else if (!this.draggingSearch) {
         return super.mouseDragged(click, offsetX, offsetY);
      } else {
         int var10 = (int)var6 - this.searchDragStartMouseX;
         int var11 = (int)var8 - this.searchDragStartMouseY;
         if (Math.abs(var10) > 2 || Math.abs(var11) > 2) {
            this.searchDragMoved = true;
         }

         int var12 = this.startX() + CATEGORIES.length * (this.panelW() + this.panelGap());
         this.searchOffset[0] = (int)var6 - this.searchGrabX - var12;
         this.searchOffset[1] = (int)var8 - this.searchGrabY - (this.startY() + this.verticalScroll);
         return true;
      }
   }

   public boolean mouseReleased(Click click) {
      this.draggingNumber = null;
      this.draggingNumberModule = null;
      this.draggingColor = null;
      this.draggingColorChannel = -1;
      if (this.draggingCategory != null) {
         if (!this.categoryDragMoved) {
            this.collapsedCategories.put(this.draggingCategory, !this.isCollapsed(this.draggingCategory));
         }

         this.draggingCategory = null;
         return true;
      } else if (this.draggingSearch) {
         this.draggingSearch = false;
         return true;
      } else {
         return super.mouseReleased(click);
      }
   }

   public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      this.refreshUiScale();
      int var9 = (int)Math.signum(verticalAmount) * this.scrollStep();
      if (this.settingsView && this.popupModule != null) {
         this.popupScroll -= var9;
         return true;
      } else {
         this.verticalScroll -= var9;
         return true;
      }
   }

   public boolean charTyped(CharInput input) {
      if (this.searchFocused && !this.settingsView) {
         this.searchQuery = this.searchQuery + this.sanitize(input.asString());
         return true;
      } else if (this.collectionSearchActive && this.collectionSearchSetting != null) {
         this.collectionSearch = this.collectionSearch + this.sanitize(input.asString());
         return true;
      } else if (this.editingString == null) {
         return super.charTyped(input);
      } else {
         this.editingString.HwidGen((String)this.editingString.HwidGen() + this.sanitize(input.asString()));
         return true;
      }
   }

   public boolean keyPressed(KeyInput input) {
      if (this.settingsView && input.isEscape()) {
         this.settingsView = false;
         this.popupModule = null;
         this.popupScroll = 0;
         this.expandedChoice = null;
         this.editingString = null;
         this.listeningBind = null;
         this.listeningActivationBind = null;
         this.collectionSearchActive = false;
         return true;
      } else {
         if (this.searchFocused && !this.settingsView) {
            if (input.getKeycode() == 259) {
               this.searchQuery = this.removeLast(this.searchQuery);
               return true;
            }

            if (input.isEscape()) {
               this.searchFocused = false;
               this.searchQuery = "";
               return true;
            }

            if (input.isEnter()) {
               this.searchFocused = false;
               return true;
            }
         }

         if (this.collectionSearchActive && this.collectionSearchSetting != null) {
            if (input.getKeycode() == 259) {
               this.collectionSearch = this.removeLast(this.collectionSearch);
               return true;
            }

            if (input.isPaste()) {
               this.collectionSearch = this.collectionSearch + this.sanitize(MinecraftClient.getInstance().keyboard.getClipboard());
               return true;
            }

            if (input.isEscape() || input.isEnter()) {
               this.collectionSearchActive = false;
               return true;
            }
         }

         if (this.editingString != null) {
            if (input.getKeycode() == 259) {
               this.editingString.HwidGen(this.removeLast((String)this.editingString.HwidGen()));
               return true;
            }

            if (input.isPaste()) {
               this.editingString.HwidGen((String)this.editingString.HwidGen() + this.sanitize(MinecraftClient.getInstance().keyboard.getClipboard()));
               return true;
            }

            if (input.isEscape() || input.isEnter()) {
               this.editingString = null;
               return true;
            }
         }

         return super.keyPressed(input);
      }
   }

   private void pollBindKeys() {
      if (this.listeningBind != null || this.listeningActivationBind != null) {
         long var1 = MinecraftClient.getInstance().getWindow().getHandle();

         for (int var3 = 32; var3 <= 348; var3++) {
            if (GLFW.glfwGetKey(var1, var3) == 1) {
               if (var3 == 256) {
                  this.listeningBind = null;
                  this.listeningActivationBind = null;
                  return;
               }

               if (var3 == 259) {
                  if (this.listeningBind != null) {
                     this.listeningBind.c(0);
                  }

                  if (this.listeningActivationBind != null) {
                     this.listeningActivationBind.HwidGen(0);
                  }

                  this.listeningBind = null;
                  this.listeningActivationBind = null;
                  return;
               }

               if (this.listeningBind != null) {
                  this.listeningBind.c(var3);
               }

               if (this.listeningActivationBind != null) {
                  this.listeningActivationBind.HwidGen(var3);
               }

               this.listeningBind = null;
               this.listeningActivationBind = null;
               return;
            }
         }
      }
   }

   private h moduleAt(int i, int j) {
      for (int var3 = 0; var3 < CATEGORIES.length; var3++) {
         g var4 = CATEGORIES[var3];
         if (!this.isCollapsed(var4)) {
            int[] var5 = this.categoryPos(var4);
            int var6 = var5[0];
            int var7 = var5[1] + this.headerH();

            for (Module var9 : this.modules(var4)) {
               if (this.in(i, j, var6, var7, this.panelW(), this.rowH())) {
                  return var9;
               }

               var7 += this.rowH();
            }
         }
      }

      return null;
   }

   private List modules(g arg) {
      ArrayList var2 = new ArrayList(SwapHelper.HwidGen.HwidGen(arg));
      var2.sort(Comparator.comparing(Module::c, String.CASE_INSENSITIVE_ORDER));
      return var2;
   }

   private int searchPanelX() {
      int var1 = this.startX() + CATEGORIES.length * (this.panelW() + this.panelGap()) + this.searchOffset[0];
      return Math.min(var1, this.uiWidth() - this.panelW() - 4);
   }

   private int searchPanelY() {
      return this.startY() + this.verticalScroll + this.searchOffset[1];
   }

   private void drawSearchPanel(DrawContext drawContext, int i, int j, int k, int l, int m) {
      List var7 = this.searchModules(this.searchQuery);
      int var8 = this.headerH() + this.rowH() + 6 + (this.searchQuery.isEmpty() ? 0 : var7.size() * this.rowH());
      if (Module_zelith.Module()) {
         Obj_dr.HwidGen(drawContext, (float)(i + 4), (float)(j + 5), (float)this.panelW(), (float)var8, 8.0F, 1996488704, false);
      }

      Obj_dr.HwidGen(drawContext, (float)i, (float)j, (float)this.panelW(), (float)var8, 8.0F, -401534696, false);
      Obj_dr.HwidGen(drawContext, (float)i, (float)j, (float)this.panelW(), (float)var8, 8.0F, 1.0F, -1439287222, false);
      Obj_dr.HwidGen(drawContext, (float)i, (float)j, (float)this.panelW(), (float)this.headerH(), 8.0F, 8.0F, 3.0F, 3.0F, false, -266790621);
      Obj_dr.HwidGen(drawContext, (float)(i + 8), (float)(j + this.headerH() - 2), (float)(this.panelW() - 16), 1.0F, 0.5F, m, false);
      drawContext.drawText(this.textRenderer, "SEARCH", i + 12, j + 9, -1513234, false);
      int var9 = j + this.headerH() + 4;
      Obj_dr.HwidGen(drawContext, (float)(i + 4), (float)var9, (float)(this.panelW() - 8), (float)this.rowH(), 5.0F, -15921901, false);
      String var10 = this.searchQuery;
      if (this.searchFocused && (System.currentTimeMillis() / 500L & 1L) == 0L) {
         var10 = var10 + "_";
      }

      drawContext.drawText(
         this.textRenderer,
         this.trim(var10, this.panelW() - 16),
         i + 10,
         var9 + 6,
         this.searchQuery.isEmpty() && !this.searchFocused ? -7368550 : -1513234,
         false
      );
      if (!this.searchQuery.isEmpty()) {
         int var11 = var9 + this.rowH() + 2;

         for (Module var13 : var7) {
            boolean var14 = this.in(k, l, i, var11, this.panelW(), this.rowH());
            float var15 = this.anim("search/hover/" + var13.c(), var14 ? 1.0F : 0.0F, 16.0F);
            float var16 = this.anim("search/enabled/" + var13.c(), var13.HwidGen() ? 1.0F : 0.0F, 14.0F);
            int var17 = this.blend(this.blend(1118488, 1999120950, var15), ROW_ACTIVE, var16);
            if (var17 != 0) {
               Obj_dr.HwidGen(drawContext, (float)(i + 4), (float)(var11 + 1), (float)(this.panelW() - 8), (float)(this.rowH() - 2), 5.0F, var17, false);
            }

            int var18 = var13.HwidGen() ? -1 : -7368550;
            drawContext.drawText(this.textRenderer, this.trim(var13.c().toUpperCase(Locale.ROOT), this.panelW() - 16), i + 10, var11 + 6, var18, false);
            String var19 = getKeyDisplayNameStatic(var13.KeyFile());
            if (var13.HwidGen() && !var19.isEmpty()) {
               drawContext.drawText(this.textRenderer, var19, i + this.panelW() - 8 - this.textRenderer.getWidth(var19), var11 + 6, -2308609, false);
            }

            var11 += this.rowH();
         }
      }
   }

   private List searchModules(String string) {
      if (string != null && !string.isBlank()) {
         String var2 = string.toLowerCase(Locale.ROOT);
         return SwapHelper.HwidGen
            .KeyFile()
            .stream()
            .filter(arg -> arg.c().toLowerCase(Locale.ROOT).contains(var2))
            .sorted(Comparator.comparing(Module::c, String.CASE_INSENSITIVE_ORDER))
            .toList();
      } else {
         return List.of();
      }
   }

   private h searchModuleAt(int i, int j) {
      if (this.searchQuery.isEmpty()) {
         return null;
      } else {
         int var3 = this.searchPanelX();
         int var4 = this.searchPanelY();
         int var5 = var4 + this.headerH() + 4;
         int var6 = var5 + this.rowH() + 2;

         for (Module var9 : this.searchModules(this.searchQuery)) {
            if (this.in(i, j, var3, var6, this.panelW(), this.rowH())) {
               return var9;
            }

            var6 += this.rowH();
         }

         return null;
      }
   }

   private boolean searchInputAt(int i, int j) {
      int var3 = this.searchPanelX();
      int var4 = this.searchPanelY();
      int var5 = var4 + this.headerH() + 4;
      return this.in(i, j, var3, var5, this.panelW(), this.rowH());
   }

   private int categoryX(int i) {
      return this.categoryPos(CATEGORIES[i])[0];
   }

   private int[] categoryPos(g arg) {
      int[] var2 = this.categoryOffsets.computeIfAbsent(arg, argx -> new int[2]);
      int var3 = 0;

      for (int var4 = 0; var4 < CATEGORIES.length; var4++) {
         if (CATEGORIES[var4] == arg) {
            var3 = var4;
            break;
         }
      }

      return new int[]{this.startX() + var3 * (this.panelW() + this.panelGap()) + var2[0], this.startY() + this.verticalScroll + var2[1]};
   }

   private g categoryHeaderAt(int i, int j) {
      for (g var6 : CATEGORIES) {
         int[] var7 = this.categoryPos(var6);
         if (this.in(i, j, var7[0], var7[1], this.panelW(), this.headerH())) {
            return var6;
         }
      }

      return null;
   }

   private boolean isCollapsed(g arg) {
      return this.collapsedCategories.getOrDefault(arg, false);
   }

   private int minScroll() {
      int var1 = 0;

      for (g var5 : CATEGORIES) {
         int[] var6 = this.categoryOffsets.computeIfAbsent(var5, arg -> new int[2]);
         int var7 = this.headerH() + (this.isCollapsed(var5) ? 4 : this.modules(var5).size() * this.rowH() + 6);
         var1 = Math.max(var1, var6[1] + var7);
      }

      return Math.min(0, this.uiHeight() - this.startY() - var1 - 12);
   }

   private int popupContentHeight() {
      if (this.popupModule == null) {
         return 0;
      } else {
         int var1 = this.settingH() + 6;
         if (this.popupModule instanceof Module_f) {
            var1 += this.settingH() + 6;
         }

         for (Setting var3 : this.popupModule.HwidGen()) {
            if (var3.K()) {
               var1 += this.settingRowHeight(var3) + 6;
            }
         }

         return var1;
      }
   }

   private int settingRowHeight(dd arg) {
      if (arg instanceof Settingdc) {
         return 24;
      } else if (this.isNumberSetting(arg)) {
         return this.settingH() + 10;
      } else if (arg.HwidGen() instanceof Color && this.expandedChoice == arg) {
         return this.settingH() + 6 + 86;
      } else {
         if (this.expandedChoice == arg) {
            if (arg instanceof Settingdb var3) {
               return this.settingH() + 6 + var3.Module_f().size() * 20;
            }

            if (arg instanceof Settingda var2) {
               return this.settingH() + 6 + var2.Module_f().size() * 20;
            }

            if (arg instanceof SettingBlock || arg instanceof SettingMob || arg instanceof SettingItem) {
               return this.settingH() + 6 + 22 + 160;
            }
         }

         return this.settingH();
      }
   }

   private int choiceIndexAt(int i, int j) {
      int var3 = j + this.settingH() + 27;
      return i < var3 ? -1 : (i - var3) / 20;
   }

   private int colorPickerTargetAt(int i, int j, int k, int l, int m) {
      ClickGUI$ColorPickerLayout var6 = this.colorPickerLayout(k, l, m);
      if (this.in(i, j, var6.fieldX, var6.fieldY, var6.fieldW, var6.fieldH)) {
         return 0;
      } else {
         return this.in(i, j, var6.hueX, var6.hueY, var6.hueW, var6.hueH) ? 1 : -1;
      }
   }

   private void updateColorPicker(dd arg, int i, double d, double e, int j, int k, int l) {
      if (arg != null && i >= 0) {
         ClickGUI$ColorPickerLayout var10 = this.colorPickerLayout(j, this.currentColorRowY(), l);
         Color var11 = (Color)arg.HwidGen();
         float[] var12 = Color.RGBtoHSB(var11.getRed(), var11.getGreen(), var11.getBlue(), null);
         if (i == 0) {
            float var13 = this.clamp01((float)((d - var10.fieldX) / Math.max(1.0, (double)var10.fieldW)));
            float var14 = 1.0F - this.clamp01((float)((e - var10.fieldY) / Math.max(1.0, (double)var10.fieldH)));
            int var15 = Color.HSBtoRGB(var12[0], var13, var14);
            arg.HwidGen(new Color(var15 >> 16 & 0xFF, var15 >> 8 & 0xFF, var15 & 0xFF, var11.getAlpha()));
         } else {
            float var16 = this.clamp01((float)((d - var10.hueX) / Math.max(1.0, (double)var10.hueW)));
            int var17 = Color.HSBtoRGB(var16, var12[1], var12[2]);
            arg.HwidGen(new Color(var17 >> 16 & 0xFF, var17 >> 8 & 0xFF, var17 & 0xFF, var11.getAlpha()));
         }
      }
   }

   private int currentColorRowY() {
      if (this.draggingColor != null && this.popupModule != null) {
         int var1 = this.popupY + 52 - this.popupScroll + this.settingH() + 6;
         if (this.popupModule instanceof Module_f) {
            var1 += this.settingH() + 6;
         }

         for (Setting var3 : this.popupModule.HwidGen()) {
            if (var3.K()) {
               if (var3 == this.draggingColor) {
                  return var1;
               }

               var1 += this.settingRowHeight(var3) + 6;
            }
         }

         return this.popupY + 52 - this.popupScroll;
      } else {
         return this.popupY + 52 - this.popupScroll;
      }
   }

   private ClickGUI$ColorPickerLayout colorPickerLayout(int i, int j, int k) {
      int var4 = i + 6;
      int var5 = j + this.settingH() + 6;
      int var6 = k - 12;
      return new ClickGUI$ColorPickerLayout(var4, var5, var6, 58, var4, var5 + 64, var6, 10);
   }

   private float clamp01(float f) {
      return Math.max(0.0F, Math.min(1.0F, f));
   }

   private String searchFor(dd arg) {
      return this.collectionSearchSetting == arg ? this.collectionSearch : "";
   }

   private boolean isNumberSetting(dd arg) {
      return arg.HwidGen() instanceof Number && arg.KeyFile() instanceof Number && arg.c() instanceof Number;
   }

   private float numberPercent(dd arg) {
      double var2 = ((Number)arg.KeyFile()).doubleValue();
      double var4 = ((Number)arg.c()).doubleValue();
      double var6 = ((Number)arg.HwidGen()).doubleValue();
      return var4 <= var2 ? 0.0F : (float)Math.max(0.0, Math.min(1.0, (var6 - var2) / (var4 - var2)));
   }

   private void updateNumber(dd arg, double d, int i, int j) {
      double var6 = Math.max(0.0, Math.min(1.0, (d - (i + 8)) / Math.max(1.0, j - 16.0)));
      double var8 = ((Number)arg.KeyFile()).doubleValue();
      double var10 = ((Number)arg.c()).doubleValue();
      double var12 = var8 + (var10 - var8) * var6;
      boolean var14 = this.allowDecimal(this.draggingNumberModule);
      if (arg.HwidGen() instanceof Integer) {
         arg.HwidGen((int)Math.round(var12));
      } else if (arg.HwidGen() instanceof Float) {
         arg.HwidGen(var14 ? (float)var12 : (float)Math.round(var12));
      } else if (arg.HwidGen() instanceof Double) {
         arg.HwidGen(var14 ? var12 : Math.round(var12));
      }
   }

   private boolean allowDecimal(h arg) {
      if (arg == null) {
         return true;
      } else {
         String var2 = arg.c().toLowerCase(Locale.ROOT).replace(" ", "");
         return var2.contains("speed")
            || var2.contains("esp")
            || var2.contains("freecam")
            || var2.contains("hitbox")
            || var2.contains("spotify")
            || var2.contains("zelith");
      }
   }

   private String none(int i) {
      String var2 = getKeyDisplayNameStatic(i);
      return var2.isEmpty() ? "NONE" : var2;
   }

   public static String getKeyDisplayNameStatic(int i) {
      if (i == 0) {
         return "";
      } else {
         String var1 = GLFW.glfwGetKeyName(i, 0);
         if (var1 != null && !var1.isBlank()) {
            return var1.toUpperCase(Locale.ROOT);
         } else {
            return switch (i) {
               case 32 -> "SPACE";
               case 257 -> "ENTER";
               case 258 -> "TAB";
               case 340, 344 -> "SHIFT";
               case 341, 345 -> "CTRL";
               case 342, 346 -> "ALT";
               default -> "KEY " + i;
            };
         }
      }
   }

   private String trim(String string, int i) {
      if (string == null) {
         return "";
      } else if (this.textRenderer.getWidth(string) <= i) {
         return string;
      } else {
         String var3 = string;

         while (var3.length() > 1 && this.textRenderer.getWidth(var3 + "...") > i) {
            var3 = var3.substring(0, var3.length() - 1);
         }

         return var3 + "...";
      }
   }

   private String sanitize(String string) {
      if (string != null && !string.isEmpty()) {
         StringBuilder var2 = new StringBuilder();
         string.codePoints().filter(i -> !Character.isISOControl(i)).forEach(var2::appendCodePoint);
         return var2.toString();
      } else {
         return "";
      }
   }

   private String removeLast(String string) {
      return string != null && !string.isEmpty() ? string.substring(0, string.offsetByCodePoints(string.length(), -1)) : "";
   }

   private String formatNumber(Object object) {
      return !(object instanceof Float) && !(object instanceof Double)
         ? String.valueOf(object)
         : String.format(Locale.ROOT, "%.2f", ((Number)object).doubleValue());
   }

   private boolean in(double d, double e, int i, int j, int k, int l) {
      return d >= i && d <= i + k && e >= j && e <= j + l;
   }

   private int clamp(int i, int j, int k) {
      return Math.max(j, Math.min(k, i));
   }

   private void updateAnimDt() {
      long var1 = System.nanoTime();
      if (this.lastAnimNanos != 0L) {
         this.frameDt = Math.min(0.1F, (float)(var1 - this.lastAnimNanos) / 1.0E9F);
      }

      this.lastAnimNanos = var1;
   }

   private float anim(String string, float f, float g) {
      if (!Module_zelith.Category()) {
         this.animValues.put(string, f);
         return f;
      } else {
         float var4 = this.animValues.getOrDefault(string, f);
         float var5 = 1.0F - (float)Math.exp(-g * this.frameDt);
         float var6 = var4 + (f - var4) * var5;
         this.animValues.put(string, var6);
         return var6;
      }
   }

   private int blend(int i, int j, float f) {
      float var4 = this.clamp01(f);
      int var5 = i >>> 24 & 0xFF;
      int var6 = i >>> 16 & 0xFF;
      int var7 = i >>> 8 & 0xFF;
      int var8 = i & 0xFF;
      int var9 = j >>> 24 & 0xFF;
      int var10 = j >>> 16 & 0xFF;
      int var11 = j >>> 8 & 0xFF;
      int var12 = j & 0xFF;
      int var13 = Math.round(var5 + (var9 - var5) * var4);
      int var14 = Math.round(var6 + (var10 - var6) * var4);
      int var15 = Math.round(var7 + (var11 - var7) * var4);
      int var16 = Math.round(var8 + (var12 - var8) * var4);
      return var13 << 24 | var14 << 16 | var15 << 8 | var16;
   }

   public void renderBackground(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
   }

   public boolean shouldPause() {
      return false;
   }
}
