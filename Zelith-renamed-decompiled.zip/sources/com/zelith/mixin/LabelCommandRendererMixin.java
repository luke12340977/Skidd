package com.zelith.mixin;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.font.TextRenderer.TextLayerType;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.command.LabelCommandRenderer;
import net.minecraft.text.Text;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({LabelCommandRenderer.class})
public class LabelCommandRendererMixin {
   @Redirect(
      method = {"render"},
      Module_GrowthFinder = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/font/TextRenderer;draw(Lnet/minecraft/text/Text;FFIZLorg/joml/Matrix4f;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/font/TextRenderer$TextLayerType;II)V",
         ordinal = 1
      )
   )
   private void zelith$drawHealthLabelsWithOutline(
      TextRenderer textRenderer,
      Text text,
      float f,
      float g,
      int i,
      boolean bl,
      Matrix4f matrix4f,
      VertexConsumerProvider vertexConsumerProvider,
      TextLayerType textLayerType,
      int j,
      int k
   ) {
      if (!Obj_dk.KeyFile(text)) {
         textRenderer.draw(text, f, g, i, bl, matrix4f, vertexConsumerProvider, textLayerType, j, k);
      } else {
         textRenderer.drawWithOutline(text.asOrderedText(), f, g, i, -16777216, matrix4f, vertexConsumerProvider, k);
      }
   }
}
