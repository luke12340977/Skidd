package com.zelith.mixin;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientWorld.class})
public class WorldMixin {
   @Inject(
      method = {"setBlockBreakingInfo"},
      Module_GrowthFinder = {@At("HEAD")}
   )
   private void zelith$trackBlockBreaking(int i, BlockPos blockPos, int j, CallbackInfo callbackInfo) {
      Render_de.HwidGen(i, blockPos, j);
   }
}
