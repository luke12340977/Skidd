package com.zelith.mixin;

import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.FrameGraphBuilder;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.memory.ObjectAllocator;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({WorldRenderer.class})
public class WorldRendererMixin {
   private static final Matrix4f capturedMatrix = new Matrix4f();
   private static boolean hasCapturedMatrix;
   private static float capturedTickDelta = 1.0F;

   @Inject(
      method = {"render"},
      Module_GrowthFinder = {@At("HEAD")}
   )
   private void captureRenderState(
      ObjectAllocator objectAllocator,
      RenderTickCounter renderTickCounter,
      boolean bl,
      Camera camera,
      Matrix4f matrix4f,
      Matrix4f matrix4f2,
      Matrix4f matrix4f3,
      GpuBufferSlice gpuBufferSlice,
      Vector4f vector4f,
      boolean bl2,
      CallbackInfo callbackInfo
   ) {
      capturedMatrix.set(matrix4f);
      Render_dp.c.set(matrix4f);
      Render_dp.LicenseResult.set(matrix4f);
      Render_dp.KeyFile.set(matrix4f2);
      Render_dm.HwidGen(matrix4f, matrix4f2, camera.getCameraPos());
      hasCapturedMatrix = true;
      capturedTickDelta = renderTickCounter.getTickProgress(false);
   }

   @Inject(
      method = {"render"},
      Module_GrowthFinder = {@At("RETURN")}
   )
   private void onRender(CallbackInfo callbackInfo) {
      if (hasCapturedMatrix) {
         MatrixStack var2 = new MatrixStack();
         var2.multiplyPositionMatrix(capturedMatrix);
         SwapHelper.HwidGen.HwidGen(var2, capturedTickDelta);
      }
   }

   @Inject(
      method = {"renderWeather"},
      Module_GrowthFinder = {@At("HEAD")},
      cancellable = true
   )
   private void zelith$skipWeatherPass(FrameGraphBuilder frameGraphBuilder, GpuBufferSlice gpuBufferSlice, CallbackInfo callbackInfo) {
      if (Module_NoRender.J()) {
         callbackInfo.cancel();
      }
   }
}
