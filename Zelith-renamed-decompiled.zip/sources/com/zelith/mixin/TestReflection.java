package com.zelith.mixin;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import net.minecraft.client.Keyboard;

public class TestReflection {
   public static void main(String[] strings) {
      System.out.println("Methods in Keyboard:");

      for (Method var4 : Keyboard.class.getDeclaredMethods()) {
         if (var4.getName().equals("onChar")) {
            System.out.println(var4.getName());

            for (Parameter var8 : var4.getParameters()) {
               System.out.println("  " + var8.getType().getName());
            }
         }
      }
   }
}
