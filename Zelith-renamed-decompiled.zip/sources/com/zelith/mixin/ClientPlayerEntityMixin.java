package com.zelith.mixin;

import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientPlayerEntity.class})
public class ClientPlayerEntityMixin {
   @Inject(
      method = {"tickMovement"},
      Module_GrowthFinder = {@At("HEAD")}
   )
   private void onTickMovement(CallbackInfo callbackInfo) {
      if (Module_Freecam.HwidGen != null && Module_Freecam.HwidGen.HwidGen()) {
         ClientPlayerEntity var2 = (ClientPlayerEntity)this;
         var2.setSneaking(false);
         var2.setSprinting(false);
      }
   }
}
