package com.zelith.mixin;

import com.zelith.gui.ClickGUI;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({TitleScreen.class})
public class TitleScreenMixin {
   @Inject(
      method = {"init"},
      Module_GrowthFinder = {@At("TAIL")}
   )
   private void zelith$init(CallbackInfo callbackInfo) {
      TitleScreen var2 = (TitleScreen)this;
      MinecraftClient var3 = MinecraftClient.getInstance();
      ((ScreenInvoker)var2)
         .invokeAddDrawableChild(
            ButtonWidget.builder(Text.literal("zelith"), buttonWidget -> var3.setScreen(new ClickGUI()))
               .dimensions(var2.width - 62, var2.height - 25, 52, 20)
               .build()
         );
   }
}
