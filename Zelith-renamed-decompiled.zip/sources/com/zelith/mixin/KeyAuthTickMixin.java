package com.zelith.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({MinecraftClient.class})
public class KeyAuthTickMixin {
   private int zelith$checkTicks = 0;

   @Inject(
      method = {"render"},
      Module_GrowthFinder = {@At("HEAD")}
   )
   private void zelith$onRender(boolean bl, CallbackInfo callbackInfo) {
   }
}
