package com.zelith.mixin;

import io.netty.channel.ChannelFutureListener;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({ClientConnection.class})
public class ClientConnectionMixin {
   @Inject(
      method = {"handlePacket"},
      Module_GrowthFinder = {@At("HEAD")}
   )
   private static void onHandlePacket(Packet packet, PacketListener packetListener, CallbackInfo callbackInfo) {
      try {
         SwapHelper.HwidGen.HwidGen(packet);
      } catch (Exception var4) {
      }
   }

   @Inject(
      method = {"send(Lnet/minecraft/network/packet/Packet;Lio/netty/channel/ChannelFutureListener;Z)V"},
      Module_GrowthFinder = {@At("HEAD")},
      cancellable = true
   )
   private void onSend(Packet packet, ChannelFutureListener channelFutureListener, boolean bl, CallbackInfo callbackInfo) {
      try {
         if (SwapHelper.HwidGen.HwidGen(packet)) {
            callbackInfo.cancel();
         }
      } catch (Exception var6) {
      }
   }
}
