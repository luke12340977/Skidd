package com.zelith.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Entity.class})
public class EntityMixin {
   @Inject(
      method = {"changeLookDirection"},
      Module_GrowthFinder = {@At("HEAD")},
      cancellable = true
   )
   private void onChangeLookDirection(double d, double e, CallbackInfo callbackInfo) {
      Entity var6 = (Entity)this;
      if (var6 == MinecraftClient.getInstance().player) {
         if (Module_Freecam.HwidGen != null && Module_Freecam.HwidGen.HwidGen()) {
            Module_Freecam.HwidGen.KeyFile(d * 0.15 * Module_Freecam.HwidGen.SwapHelper(), e * 0.15 * Module_Freecam.HwidGen.SwapHelper());
            callbackInfo.cancel();
         } else {
            if (bp.HwidGen != null && bp.HwidGen.Module_AutoTotem()) {
               bp.HwidGen.HwidGen(d, e);
               callbackInfo.cancel();
            }
         }
      }
   }

   @Inject(
      method = {"isSneaking"},
      Module_GrowthFinder = {@At("HEAD")},
      cancellable = true
   )
   private void onIsSneaking(CallbackInfoReturnable callbackInfoReturnable) {
      if (Module_Freecam.HwidGen != null && Module_Freecam.HwidGen.HwidGen() && this == MinecraftClient.getInstance().player) {
         callbackInfoReturnable.setReturnValue(false);
      }
   }

   @Inject(
      method = {"shouldRender(D)Z"},
      Module_GrowthFinder = {@At("HEAD")},
      cancellable = true
   )
   private void onShouldRender(double d, CallbackInfoReturnable callbackInfoReturnable) {
      if (Module_Freecam.HwidGen != null && Module_Freecam.HwidGen.HwidGen() && d < 25600.0) {
         callbackInfoReturnable.setReturnValue(true);
      }
   }

   @Inject(
      method = {"getDisplayName"},
      Module_GrowthFinder = {@At("RETURN")},
      cancellable = true
   )
   private void onGetDisplayName(CallbackInfoReturnable callbackInfoReturnable) {
      if (Module_FakeRoles.Module_f()) {
         Text var2 = Module_FakeRoles.HwidGen((Text)callbackInfoReturnable.getReturnValue());
         if (var2 != callbackInfoReturnable.getReturnValue()) {
            callbackInfoReturnable.setReturnValue(var2);
            return;
         }
      }

      if (Module_NameProtect.HwidGen != null && Module_NameProtect.HwidGen.HwidGen() && MinecraftClient.getInstance().getSession() != null) {
         String var5 = MinecraftClient.getInstance().getSession().getUsername();
         if (var5 != null) {
            Text var3 = (Text)callbackInfoReturnable.getReturnValue();
            if (var3 != null) {
               String var4 = var3.getString();
               if (var4.contains(var5)) {
                  callbackInfoReturnable.setReturnValue(Text.literal(var4.replace(var5, Module_NameProtect.HwidGen.Module_zelith())));
               }
            }
         }
      }
   }

   @Inject(
      method = {"getName"},
      Module_GrowthFinder = {@At("RETURN")},
      cancellable = true
   )
   private void onGetName(CallbackInfoReturnable callbackInfoReturnable) {
      if (Module_FakeRoles.Module_f()) {
         Text var2 = Module_FakeRoles.HwidGen((Text)callbackInfoReturnable.getReturnValue());
         if (var2 != callbackInfoReturnable.getReturnValue()) {
            callbackInfoReturnable.setReturnValue(var2);
            return;
         }
      }

      if (Module_NameProtect.HwidGen != null && Module_NameProtect.HwidGen.HwidGen() && MinecraftClient.getInstance().getSession() != null) {
         String var5 = MinecraftClient.getInstance().getSession().getUsername();
         if (var5 != null) {
            Text var3 = (Text)callbackInfoReturnable.getReturnValue();
            if (var3 != null) {
               String var4 = var3.getString();
               if (var4.contains(var5)) {
                  callbackInfoReturnable.setReturnValue(Text.literal(var4.replace(var5, Module_NameProtect.HwidGen.Module_zelith())));
               }
            }
         }
      }
   }
}
