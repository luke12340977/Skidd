package com.zelith.mixin;

import com.zelith.gui.HudEditor;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ChatScreen.class})
public class ChatScreenMixin {
   @Inject(
      method = {"mouseClicked"},
      Module_GrowthFinder = {@At("HEAD")},
      cancellable = true
   )
   private void zelith$mouseClicked(Click click, boolean bl, CallbackInfoReturnable callbackInfoReturnable) {
      double var4 = click.x();
      double var6 = click.y();
      int var8 = click.button();
      if (var8 == 0) {
         if (Module_SpotifyHUD.HwidGen(var4, var6)) {
            callbackInfoReturnable.setReturnValue(true);
            return;
         }

         if (HudEditor.INSTANCE.onMouseClick(var4, var6, var8)) {
            callbackInfoReturnable.setReturnValue(true);
            return;
         }
      }
   }

   @Inject(
      method = {"render"},
      Module_GrowthFinder = {@At("TAIL")}
   )
   private void zelith$render(DrawContext drawContext, int i, int j, float f, CallbackInfo callbackInfo) {
      HudEditor.INSTANCE.render(drawContext, i, j);
   }
}
