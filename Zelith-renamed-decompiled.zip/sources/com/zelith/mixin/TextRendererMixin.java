package com.zelith.mixin;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.text.OrderedText;
import net.minecraft.text.StringVisitable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin({TextRenderer.class})
public class TextRendererMixin {
   @ModifyVariable(
      method = {"prepare(Ljava/lang/String;FFIZI)Lnet/minecraft/client/font/TextRenderer$GlyphDrawable;"},
      Module_GrowthFinder = @At("HEAD"),
      ordinal = 0,
      argsOnly = true
   )
   private String zelith$replacePreparedString(String string) {
      return Obj_di.Module_ActiveModules(string);
   }

   @ModifyVariable(
      method = {"prepare(Lnet/minecraft/text/OrderedText;FFIZZI)Lnet/minecraft/client/font/TextRenderer$GlyphDrawable;"},
      Module_GrowthFinder = @At("HEAD"),
      ordinal = 0,
      argsOnly = true
   )
   private OrderedText zelith$replacePreparedOrderedText(OrderedText orderedText) {
      return Obj_di.HwidGen(orderedText);
   }

   @ModifyVariable(
      method = {"drawWithOutline(Lnet/minecraft/text/OrderedText;FFIILorg/joml/Matrix4f;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"},
      Module_GrowthFinder = @At("HEAD"),
      ordinal = 0,
      argsOnly = true
   )
   private OrderedText zelith$replaceOutlinedOrderedText(OrderedText orderedText) {
      return Obj_di.HwidGen(orderedText);
   }

   @ModifyVariable(
      method = {"getWidth(Ljava/lang/String;)I"},
      Module_GrowthFinder = @At("HEAD"),
      ordinal = 0,
      argsOnly = true
   )
   private String zelith$replaceWidthString(String string) {
      return Obj_di.Module_ActiveModules(string);
   }

   @ModifyVariable(
      method = {"getWidth(Lnet/minecraft/text/StringVisitable;)I"},
      Module_GrowthFinder = @At("HEAD"),
      ordinal = 0,
      argsOnly = true
   )
   private StringVisitable zelith$replaceWidthVisitable(StringVisitable stringVisitable) {
      return Obj_di.HwidGen(stringVisitable);
   }

   @ModifyVariable(
      method = {"getWidth(Lnet/minecraft/text/OrderedText;)I"},
      Module_GrowthFinder = @At("HEAD"),
      ordinal = 0,
      argsOnly = true
   )
   private OrderedText zelith$replaceWidthOrderedText(OrderedText orderedText) {
      return Obj_di.HwidGen(orderedText);
   }
}
