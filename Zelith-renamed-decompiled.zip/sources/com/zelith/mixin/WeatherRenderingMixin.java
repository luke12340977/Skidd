package com.zelith.mixin;

import net.minecraft.client.render.WeatherRendering;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome.Precipitation;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({WeatherRendering.class})
public abstract class WeatherRenderingMixin {
   @Invoker("getPrecipitationAt")
   protected abstract Precipitation zelith$getPrecipitationAt(World world, BlockPos blockPos);

   @Redirect(
      method = {"buildPrecipitationPieces"},
      Module_GrowthFinder = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/WeatherRendering;getPrecipitationAt(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/world/biome/Biome$Precipitation;"
      )
   )
   private Precipitation zelith$filterRenderedPrecipitation(WeatherRendering weatherRendering, World world, BlockPos blockPos) {
      return Module_NoRender.HwidGen(this.zelith$getPrecipitationAt(world, blockPos));
   }

   @Redirect(
      method = {"addParticlesAndSound"},
      Module_GrowthFinder = @At(
         value = "INVOKE",
         target = "Lnet/minecraft/client/render/WeatherRendering;getPrecipitationAt(Lnet/minecraft/world/World;Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/world/biome/Biome$Precipitation;"
      )
   )
   private Precipitation zelith$filterWeatherParticlesAndSounds(WeatherRendering weatherRendering, World world, BlockPos blockPos) {
      return Module_NoRender.HwidGen(this.zelith$getPrecipitationAt(world, blockPos));
   }
}
