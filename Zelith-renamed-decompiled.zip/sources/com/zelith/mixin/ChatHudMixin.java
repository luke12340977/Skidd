package com.zelith.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin({ChatHud.class})
public class ChatHudMixin {
   @ModifyVariable(
      method = {"addMessage"},
      Module_GrowthFinder = @At("HEAD"),
      ordinal = 0,
      argsOnly = true
   )
   private Text modifyChatMessage(Text text) {
      if (text != null && Module_NameProtect.HwidGen != null && Module_NameProtect.HwidGen.HwidGen() && MinecraftClient.getInstance().getSession() != null) {
         String var2 = MinecraftClient.getInstance().getSession().getUsername();
         if (var2 != null) {
            String var3 = text.getString();
            if (var3.contains(var2)) {
               text = Text.literal(var3.replace(var2, Module_NameProtect.HwidGen.Module_zelith()));
            }
         }
      }

      return Module_FakeRoles.HwidGen(text);
   }
}
