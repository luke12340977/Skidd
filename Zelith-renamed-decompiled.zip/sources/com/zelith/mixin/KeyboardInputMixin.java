package com.zelith.mixin;

import net.minecraft.client.input.KeyboardInput;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec2f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({KeyboardInput.class})
public class KeyboardInputMixin {
   @Inject(
      method = {"tick()V"},
      Module_GrowthFinder = {@At("RETURN")}
   )
   private void onTickReturn(CallbackInfo callbackInfo) {
      if (Module_Freecam.HwidGen != null && Module_Freecam.HwidGen.HwidGen()) {
         InputAccessor var2 = (InputAccessor)this;
         boolean var3 = Module_Freecam.HwidGen.O;
         var2.zelith$setPlayerInput(new PlayerInput(var3, false, false, false, false, false, false));
         var2.zelith$setMovementVector(var3 ? new Vec2f(0.0F, 1.0F) : Vec2f.ZERO);
      }
   }
}
