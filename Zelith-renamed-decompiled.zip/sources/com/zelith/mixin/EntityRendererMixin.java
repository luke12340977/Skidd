package com.zelith.mixin;

import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({EntityRenderer.class})
public class EntityRendererMixin {
   @Inject(
      method = {"updateRenderState"},
      Module_GrowthFinder = {@At("TAIL")}
   )
   private void zelith$updateNametagState(Entity entity, EntityRenderState entityRenderState, float f, CallbackInfo callbackInfo) {
      if (entity instanceof LivingEntity var5 && Module_NameTags.Module_f()) {
         bs var6 = Module_NameTags.HwidGen;
         if (var6 != null && var6.HwidGen(var5, entityRenderState.squaredDistanceToCamera) && !entityRenderState.invisible) {
            Obj_dk.KeyFile(entityRenderState);
         } else {
            Obj_dk.HwidGen(entityRenderState);
         }
      } else {
         Obj_dk.HwidGen(entityRenderState);
      }
   }

   @Inject(
      method = {"renderLabelIfPresent"},
      Module_GrowthFinder = {@At("HEAD")},
      cancellable = true
   )
   private void zelith$renderCustomNametag(
      EntityRenderState entityRenderState,
      MatrixStack matrixStack,
      OrderedRenderCommandQueue orderedRenderCommandQueue,
      CameraRenderState cameraRenderState,
      CallbackInfo callbackInfo
   ) {
      if (Obj_dk.HwidGen(entityRenderState)) {
         callbackInfo.cancel();
      }
   }

   @Inject(
      method = {"getShadowRadius"},
      Module_GrowthFinder = {@At("RETURN")},
      cancellable = true
   )
   private void zelith$hitbox(EntityRenderState entityRenderState, CallbackInfoReturnable callbackInfoReturnable) {
      aa var3 = Module_Hitbox.HwidGen;
      if (var3 != null && var3.HwidGen()) {
         callbackInfoReturnable.setReturnValue((Float)callbackInfoReturnable.getReturnValue() + (Float)var3.P.HwidGen());
      }
   }
}
