package com.zelith.mixin;

import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ItemStack.class})
public class ItemStackMixin {
   @Inject(
      method = {"getName"},
      Module_GrowthFinder = {@At("HEAD")},
      cancellable = true
   )
   private void zelith$paperRigGetName(CallbackInfoReturnable callbackInfoReturnable) {
      ItemStack var2 = (ItemStack)this;
      az var3 = Module_PaperRig.HwidGen();
      if (var3 != null && var3.HwidGen()) {
         Text var4 = var2.getCustomName();
         if (var4 == null) {
            var4 = var2.getItemName();
         }

         String var5 = var3.HwidGen(var2, var4.getString());
         if (var5 != null) {
            callbackInfoReturnable.setReturnValue(Text.literal(var5).setStyle(var4.getStyle()));
         }
      }
   }
}
