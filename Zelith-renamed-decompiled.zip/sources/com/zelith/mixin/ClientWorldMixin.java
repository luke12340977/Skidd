package com.zelith.mixin;

import net.minecraft.client.world.ClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({ClientWorld.class})
public class ClientWorldMixin {
   @Inject(
      method = {"getLightningTicksLeft"},
      Module_GrowthFinder = {@At("HEAD")},
      cancellable = true
   )
   private void zelith$hideLightningFlash(CallbackInfoReturnable callbackInfoReturnable) {
      if (Module_NoRender.I()) {
         callbackInfoReturnable.setReturnValue(0);
      }
   }
}
