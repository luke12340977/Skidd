package com.zelith.mixin;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({AbstractClientPlayerEntity.class})
public abstract class AbstractClientPlayerEntityMixin {
   @Inject(
      method = {"getSkin"},
      Module_GrowthFinder = {@At("HEAD")},
      cancellable = true
   )
   private void zelith$overrideOwnSkin(CallbackInfoReturnable callbackInfoReturnable) {
      AbstractClientPlayerEntity var2 = (AbstractClientPlayerEntity)this;
      SkinTextures var3 = Module_SkinChanger.HwidGen(var2.getUuid());
      if (var3 != null) {
         callbackInfoReturnable.setReturnValue(var3);
      }
   }
}
