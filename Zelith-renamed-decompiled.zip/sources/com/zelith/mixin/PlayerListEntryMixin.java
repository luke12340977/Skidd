package com.zelith.mixin;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({PlayerListEntry.class})
public abstract class PlayerListEntryMixin {
   @Shadow
   public abstract GameProfile getProfile();

   @Inject(
      method = {"getSkinTextures"},
      Module_GrowthFinder = {@At("HEAD")},
      cancellable = true
   )
   private void zelith$overrideListEntrySkin(CallbackInfoReturnable callbackInfoReturnable) {
      GameProfile var2 = this.getProfile();
      if (var2 != null && var2.id() != null) {
         SkinTextures var3 = Module_SkinChanger.HwidGen(var2.id());
         if (var3 != null) {
            callbackInfoReturnable.setReturnValue(var3);
         }
      }
   }

   @Inject(
      method = {"getDisplayName"},
      Module_GrowthFinder = {@At("RETURN")},
      cancellable = true
   )
   private void zelith$fakeRoleDisplayName(CallbackInfoReturnable callbackInfoReturnable) {
      if (Module_FakeRoles.Module_f()) {
         GameProfile var2 = this.getProfile();
         MinecraftClient var3 = MinecraftClient.getInstance();
         if (var2 != null && var2.id() != null && var3 != null && var3.player != null) {
            if (var2.id().equals(var3.player.getUuid())) {
               Text var4 = Module_FakeRoles.HwidGen(var2.name());
               if (var4 != null) {
                  callbackInfoReturnable.setReturnValue(var4);
               }
            }
         }
      }
   }
}
