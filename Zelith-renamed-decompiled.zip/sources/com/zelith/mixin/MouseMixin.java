package com.zelith.mixin;

import com.zelith.gui.HudEditor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.ChatScreen;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Coerce;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({Mouse.class})
public class MouseMixin {
   private static double toScaledX(MinecraftClient minecraftClient, double d) {
      if (minecraftClient != null && minecraftClient.getWindow() != null) {
         double var3 = minecraftClient.getWindow().getWidth();
         return var3 <= 0.0 ? d : d * (minecraftClient.getWindow().getScaledWidth() / var3);
      } else {
         return d;
      }
   }

   private static double toScaledY(MinecraftClient minecraftClient, double d) {
      if (minecraftClient != null && minecraftClient.getWindow() != null) {
         double var3 = minecraftClient.getWindow().getHeight();
         return var3 <= 0.0 ? d : d * (minecraftClient.getWindow().getScaledHeight() / var3);
      } else {
         return d;
      }
   }

   @Inject(
      method = {"onMouseButton"},
      Module_GrowthFinder = {@At("HEAD")},
      cancellable = true,
      require = 0
   )
   private void zelith$hudEditorMouseButtonClick(long l, @Coerce Object object, int i, CallbackInfo callbackInfo) {
      MinecraftClient var6 = MinecraftClient.getInstance();
      if (var6 != null && var6.currentScreen instanceof ChatScreen) {
         if (object instanceof Click var7) {
            if (i == 1) {
               if (HudEditor.INSTANCE.onMouseClick(var7.x(), var7.y(), var7.button())) {
                  callbackInfo.cancel();
               }
            } else if (i == 0) {
               HudEditor.INSTANCE.onMouseRelease();
            }
         }
      }
   }

   @Inject(
      method = {"onCursorPos"},
      Module_GrowthFinder = {@At("HEAD")},
      require = 0
   )
   private void zelith$hudEditorCursorPos(long l, double d, double e, CallbackInfo callbackInfo) {
      MinecraftClient var8 = MinecraftClient.getInstance();
      if (var8 != null && var8.player != null) {
         if (var8.currentScreen instanceof ChatScreen) {
            if (HudEditor.INSTANCE.isDragging()) {
               if (GLFW.glfwGetMouseButton(l, 0) != 1) {
                  HudEditor.INSTANCE.onMouseRelease();
               } else {
                  HudEditor.INSTANCE.onMouseDrag(toScaledX(var8, d), toScaledY(var8, e));
               }
            }
         }
      }
   }

   @Inject(
      method = {"onMouseScroll"},
      Module_GrowthFinder = {@At("HEAD")},
      cancellable = true
   )
   private void zelith$useScrollForFreecamSpeed(long l, double d, double e, CallbackInfo callbackInfo) {
      if (Module_Freecam.HwidGen != null && Module_Freecam.HwidGen.HwidGen()) {
         if (MinecraftClient.getInstance().currentScreen == null) {
            double var8 = e != 0.0 ? e : d;
            if (var8 != 0.0) {
               Module_Freecam.HwidGen.HwidGen(var8);
               callbackInfo.cancel();
            }
         }
      }
   }

   @Inject(
      method = {"onMouseScroll"},
      Module_GrowthFinder = {@At("HEAD")},
      cancellable = true
   )
   private void zelith$hudEditorMouseScroll(long l, double d, double e, CallbackInfo callbackInfo) {
      MinecraftClient var8 = MinecraftClient.getInstance();
      if (var8 != null && var8.currentScreen instanceof ChatScreen) {
         double var9 = e != 0.0 ? e : d;
         if (var9 != 0.0) {
            double var11 = toScaledX(var8, var8.mouse.getX());
            double var13 = toScaledY(var8, var8.mouse.getY());
            if (HudEditor.INSTANCE.onMouseScroll(var11, var13, var9)) {
               callbackInfo.cancel();
            }
         }
      }
   }
}
