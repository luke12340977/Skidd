package com.zelith.mixin;

import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin({Camera.class})
public abstract class CameraMixin {
   @Shadow
   protected abstract void setPos(double d, double e, double f);

   @Shadow
   protected abstract void setRotation(float f, float g);

   @Shadow
   protected abstract float clipToSpace(float f);

   @Shadow
   protected abstract void moveBy(float f, float g, float h);

   @Inject(
      method = {"update"},
      Module_GrowthFinder = {@At("TAIL")}
   )
   private void onUpdate(World world, Entity entity, boolean bl, boolean bl2, float f, CallbackInfo callbackInfo) {
      if (Module_Freecam.HwidGen != null && Module_Freecam.HwidGen.HwidGen()) {
         Module_Freecam.HwidGen.Module_SpearSwap();
         double var15 = Module_Freecam.HwidGen.HwidGen(f);
         double var16 = Module_Freecam.HwidGen.KeyFile(f);
         double var11 = Module_Freecam.HwidGen.c(f);
         float var13 = Module_Freecam.HwidGen.KeyFile(f);
         float var14 = Module_Freecam.HwidGen.c(f);
         this.setPos(var15, var16, var11);
         this.setRotation(var13, var14);
      } else {
         bp var7 = bp.HwidGen;
         if (var7 != null && var7.Module_AutoTotem() && entity != null) {
            Vec3d var8 = entity.getCameraPosVec(f);
            this.setRotation(var7.LicenseResult(), var7.LicenseState());
            this.setPos(var8.x, var8.y, var8.z);
            float var9 = var7.Module_f();
            if (!var7.Module_DoubleAnchor()) {
               var9 = this.clipToSpace(var9);
            }

            this.moveBy(-var9, 0.0F, 0.0F);
         }
      }
   }

   @Inject(
      method = {"isThirdPerson"},
      Module_GrowthFinder = {@At("HEAD")},
      cancellable = true
   )
   private void onIsThirdPerson(CallbackInfoReturnable callbackInfoReturnable) {
      if (Module_Freecam.HwidGen != null && Module_Freecam.HwidGen.HwidGen()) {
         callbackInfoReturnable.setReturnValue(true);
      } else {
         if (bp.HwidGen != null && bp.HwidGen.Module_AutoTotem()) {
            callbackInfoReturnable.setReturnValue(true);
         }
      }
   }
}
