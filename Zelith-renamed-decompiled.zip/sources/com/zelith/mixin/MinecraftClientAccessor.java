package com.zelith.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({MinecraftClient.class})
public interface MinecraftClientAccessor {
   @Accessor("itemUseCooldown")
   int zelith$getItemUseCooldown();

   @Accessor("itemUseCooldown")
   void zelith$setItemUseCooldown(int i);
}
