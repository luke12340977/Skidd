package com.zelith.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({MinecraftClient.class})
public class MinecraftClientAttackMixin {
   @Inject(
      method = {"handleInputEvents"},
      Module_GrowthFinder = {@At("HEAD")},
      require = 0
   )
   private void zelith$preInput(CallbackInfo callbackInfo) {
      ad var2 = Module_SpearSwap.HwidGen;
      if (var2 != null && var2.HwidGen()) {
         MinecraftClient var3 = MinecraftClient.getInstance();
         if (var3 != null && var3.player != null && var3.options != null) {
            if (var3.currentScreen == null) {
               if (var3.options.attackKey.isPressed()) {
                  var2.Module_AutoDoubleHand();
               } else {
                  var2.Module_AutoInvTotem();
               }
            }
         }
      }
   }
}
