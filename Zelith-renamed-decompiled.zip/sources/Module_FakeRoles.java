import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;

public final class Module_FakeRoles extends Module {
   public static ar HwidGen;
   private final cy LicenseResult = new Misc_cy("Role", "None", "None", "SRMOD", "MEDIA", "SRADMIN", "DEV");
   private final cy LicenseState = new Misc_cy("Tag", "None", "None", "+", "++", "+++");

   public Module_FakeRoles() {
      super("Fake Roles", Category.LicenseState);
      HwidGen = this;
      this.HwidGen(this.LicenseResult);
      this.HwidGen(this.LicenseState);
   }

   public static boolean Module_f() {
      return HwidGen != null && HwidGen.HwidGen() && !HwidGen.LicenseResult.Module_f("None") && HwidGen != null && HwidGen.player != null;
   }

   public static String LicenseState() {
      return HwidGen != null && HwidGen.getSession() != null ? HwidGen.getSession().getUsername() : null;
   }

   public static Text HwidGen(Text text) {
      if (Module_f() && text != null) {
         String var1 = LicenseState();
         if (var1 != null && !var1.isBlank()) {
            String var2 = text.getString();
            if (!var2.contains(var1)) {
               return text;
            } else {
               Text var3 = KeyFile(var1);
               int var4 = var2.indexOf(var1);
               MutableText var5 = Text.empty();
               if (var4 > 0) {
                  var5.append(Text.literal(var2.substring(0, var4)));
               }

               var5.append(var3);
               int var6 = var4 + var1.length();
               if (var6 < var2.length()) {
                  var5.append(Text.literal(var2.substring(var6)));
               }

               return var5;
            }
         } else {
            return text;
         }
      } else {
         return text;
      }
   }

   public static Text HwidGen(String string) {
      return Module_f() && string != null ? KeyFile(string) : null;
   }

   private static int Module_Friends() {
      String var0 = (String)HwidGen.LicenseResult.HwidGen();

      return switch (var0) {
         case "SRMOD" -> 5635925;
         case "MEDIA" -> 16733695;
         case "SRADMIN" -> 16733525;
         case "DEV" -> 10683385;
         default -> 16777215;
      };
   }

   public static String Module_f() {
      if (!Module_f()) {
         return "";
      } else {
         String var0 = (String)HwidGen.LicenseResult.HwidGen();
         byte var1 = -1;
         switch (var0.hashCode()) {
            case 73234372:
               if (var0.equals("MEDIA")) {
                  var1 = 0;
               }
            default:
               return switch (var1) {
                  case 0 -> "\ud83d\udcf9";
                  default -> "★";
               };
         }
      }
   }

   public static int Module_Hud() {
      if (!Module_f()) {
         return 16777215;
      } else {
         String var0 = (String)HwidGen.LicenseResult.HwidGen();
         byte var1 = -1;
         switch (var0.hashCode()) {
            case 73234372:
               if (var0.equals("MEDIA")) {
                  var1 = 0;
               }
            default:
               return switch (var1) {
                  case 0 -> 16515236;
                  default -> Module_Friends();
               };
         }
      }
   }

   private static Text KeyFile(String string) {
      MutableText var1 = Text.empty();
      String var2 = HwidGen.LicenseState.Module_f("None") ? "" : (String)HwidGen.LicenseState.HwidGen();
      var1.append(Text.literal(Module_f()).setStyle(HwidGen(Module_Hud())));
      if (!var2.isEmpty()) {
         var1.append(Text.literal(var2).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(39918))));
      }

      var1.append(Text.literal(" ").setStyle(HwidGen(Module_Friends())));
      var1.append(Text.literal(string).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215))));
      return var1;
   }

   private static Style HwidGen(int i) {
      return Style.EMPTY.withColor(TextColor.fromRgb(i)).withBold(true);
   }
}
