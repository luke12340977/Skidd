import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;

public final class Module_ShieldBreaker extends Module {
   private final dd Q = new Setting("Switch Back", true);
   private final dd R = new Setting("Switch Delay", 0.0F, 0.0F, 500.0F);
   private boolean Module_Hud = false;
   private long Category = -1L;
   private boolean HudElement = false;
   private boolean Module_SpotifyHUD = false;
   private int Module_j = -1;

   public Module_ShieldBreaker() {
      super("Shield Breaker", Category.c);
      this.HwidGen(this.Q);
      this.HwidGen(this.R);
   }

   @Override
   public void LicenseState() {
      this.Module_AutoCrystal();
      super.LicenseState();
   }

   @Override
   public void Module_f() {
      if (this.HudElement && (Boolean)this.Q.HwidGen() && this.Module_SpotifyHUD && HwidGen.player != null) {
         this.Module_f(this.Module_j);
      }

      this.Module_AutoCrystal();
      super.Module_f();
   }

   private void Module_AutoCrystal() {
      this.Module_Hud = false;
      this.Category = -1L;
      this.HudElement = false;
      this.Module_SpotifyHUD = false;
      this.Module_j = -1;
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.world != null) {
         PlayerEntity var1 = this.HwidGen();
         if (var1 != null && var1.isBlocking()) {
            if (!this.Module_Hud) {
               this.Module_Hud = true;
               this.Category = System.currentTimeMillis();
            }

            long var2 = ((Float)this.R.HwidGen()).longValue();
            if (!this.HudElement && this.Category >= 0L && System.currentTimeMillis() - this.Category >= var2) {
               int var4 = this.Module_ActiveModules();
               if (var4 != -1) {
                  this.Module_j = HwidGen.player.getInventory().getSelectedSlot();
                  if (this.Module_j != var4) {
                     this.Module_f(var4);
                     this.Module_SpotifyHUD = true;
                  }

                  HwidGen.interactionManager.attackEntity(HwidGen.player, var1);
                  HwidGen.player.swingHand(Hand.MAIN_HAND);
                  this.HudElement = true;
               }
            }
         } else {
            if (this.Module_Hud) {
               this.Module_Hud = false;
               this.Category = -1L;
            }

            if (this.HudElement) {
               if ((Boolean)this.Q.HwidGen() && this.Module_SpotifyHUD && this.Module_j != -1) {
                  this.Module_f(this.Module_j);
               }

               this.HudElement = false;
               this.Module_SpotifyHUD = false;
               this.Module_j = -1;
            }
         }
      }
   }

   private PlayerEntity HwidGen() {
      return HwidGen.crosshairTarget != null
            && HwidGen.crosshairTarget.getType() == Type.ENTITY
            && ((EntityHitResult)HwidGen.crosshairTarget).getEntity() instanceof PlayerEntity var2
            && var2 != HwidGen.player
         ? var2
         : null;
   }

   private int Module_ActiveModules() {
      int var1 = -1;
      int var2 = -1;

      for (int var3 = 0; var3 < 9; var3++) {
         ItemStack var4 = HwidGen.player.getInventory().getStack(var3);
         if (var4.getItem() instanceof AxeItem) {
            int var5 = this.HwidGen(var4);
            if (var5 > var1) {
               var1 = var5;
               var2 = var3;
            }
         }
      }

      return var2;
   }

   private int HwidGen(ItemStack itemStack) {
      if (itemStack.isOf(Items.NETHERITE_AXE)) {
         return 6;
      } else if (itemStack.isOf(Items.DIAMOND_AXE)) {
         return 5;
      } else if (itemStack.isOf(Items.IRON_AXE)) {
         return 4;
      } else if (itemStack.isOf(Items.GOLDEN_AXE)) {
         return 3;
      } else if (itemStack.isOf(Items.STONE_AXE)) {
         return 2;
      } else {
         return itemStack.isOf(Items.WOODEN_AXE) ? 1 : 0;
      }
   }

   private void Module_f(int i) {
      if (HwidGen.player != null) {
         if (i >= 0 && i <= 8) {
            HwidGen.player.getInventory().setSelectedSlot(i);
         }
      }
   }
}
