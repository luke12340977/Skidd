import java.awt.Color;
import net.minecraft.util.math.Box;

record Rec_cs() {
   final Box HwidGen;
   final Color Module_j;

   Rec_cs(Box box, Color color) {
      this.HwidGen = box;
      this.Module_j = color;
   }
}
