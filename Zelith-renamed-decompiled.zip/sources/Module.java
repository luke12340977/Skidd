import com.zelith.gui.notification.NotificationManager;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.network.packet.Packet;

public abstract class Module {
   private final String Module_f;
   private final g Category;
   private boolean KeyFile;
   private int KeyFile = 0;
   private boolean c = false;
   public boolean LicenseResult = false;
   private final List HwidGen = new ArrayList();
   protected static final MinecraftClient HwidGen = MinecraftClient.getInstance();

   public Module(String string, g arg) {
      this.Module_f = string;
      this.Category = arg;
      this.KeyFile = false;
   }

   public void HwidGen(dd arg) {
      this.HwidGen.add(arg);
   }

   public List HwidGen() {
      return this.HwidGen;
   }

   public String c() {
      return this.Module_f;
   }

   public g HwidGen() {
      return this.Category;
   }

   public void HwidGen(boolean bl) {
      this.KeyFile = bl;
      if (bl) {
         this.LicenseState();
      } else {
         this.Module_f();
      }

      SwapHelper.HwidGen.Module_j();
   }

   public boolean HwidGen() {
      return this.KeyFile;
   }

   public void c() {
      this.HwidGen(!this.KeyFile);
      if (Module_zelith.SwapHelper()) {
         NotificationManager.INSTANCE.pushToggle(this.Module_f, this.KeyFile, this.Category.HwidGen());
      }
   }

   public void LicenseResult() {
      this.c();
   }

   public int KeyFile() {
      return this.KeyFile;
   }

   public void c(int i) {
      this.KeyFile = i;
      SwapHelper.HwidGen.Module_j();
   }

   void LicenseResult(int i) {
      this.KeyFile = i;
   }

   void KeyFile(boolean bl) {
      this.KeyFile = bl;
   }

   public void LicenseState() {
   }

   public void Module_f() {
   }

   public void Category() {
   }

   public void HwidGen(MatrixStack matrixStack, float f) {
   }

   public void HwidGen(Packet packet) {
   }

   public boolean HwidGen(Packet packet) {
      return false;
   }
}
