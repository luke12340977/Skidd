import java.util.Random;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

public final class Module_FakePayments extends Module {
   private final dd Module_EntityScanner = new Setting("Delay", 5, 1, 30);
   private final dd Module_FakePay = new Setting("Random Delay", false);
   private final dd Module_FakePayments = new Setting("Min Delay", 3, 1, 30);
   private final dd Module_FakeRoles = new Setting("Max Delay", 7, 1, 60);
   private final dd Module_FakeScoreboard = new Setting("Min Amount", "1m");
   private final dd Module_GrowthFinder = new Setting("Max Amount", "25m");
   private final Random KeyFile = new Random();
   private int Module_WaterMark = 0;
   private int Module_zelith = 0;
   private static final String[] HwidGen = new String[]{
      "SchneeSchuhHase",
      "g0Onboy312",
      "ArgonEnjoyer",
      "DrDiddy934",
      "esternomastoicle",
      "HERHAKE",
      "DIAboy",
      "YoxyC",
      "freaddyFAS",
      "itzmedr",
      "laps_",
      "Salem6542",
      "ZEN_2213",
      "Hulpic54",
      "kostbar_troll",
      "YukonCharlie",
      "GSMusie",
      "ImdarealFox",
      "ItzTerax",
      "MadGhast2",
      "Kloputzer337",
      "lejonrasmus",
      "Munkerlich",
      "LazerminerCivan",
      "GioRobit",
      "dih23",
      "mrpatao",
      "Nottis1",
      "ItsZanthrax",
      "TheRealOnixy",
      "isqpzzz",
      "itzdursum",
      "SKskellyfarm01",
      "Ethereums656",
      "loosal",
      "yourmom_6",
      "l6jq_",
      "LrexTTV",
      "VeriKuula",
      "Justsyncc",
      "cpvpGard",
      "ArchivePebroo",
      "Im_joe1",
      "1oan",
      "Test_Of_Fate",
      "PhoenixX626",
      "Crimsonfarmmaker",
      "soonmedia",
      "nolimitd0sh",
      "Steelghg",
      "BearHug",
      "neeisnee",
      "HawkVision",
      "itziran",
      "walksyv1",
      "CatGirllover2",
      "Xinox_",
      "NateHigger8888",
      "Popelesser34",
      "GoldfinchGlow",
      "HummingbirdHover",
      "WoodpeckerPeck",
      "KingfisherDive",
      "IshowPatar",
      "RyxoHD",
      "Stor08Glide",
      "Itzme_CraneDance",
      "IbisProbe",
      "Googoga41",
      "Frforealylias43",
      "GamingbeastYT",
      "BedrockB0t",
      "Ididdyty",
      "Puffifuffy",
      "baltopsoon3",
      "drccke",
      "0huzzaii",
      "simpasimpa"
   };

   public Module_FakePayments() {
      super("Fake Payments", Category.LicenseState);
      this.HwidGen(this.Module_EntityScanner);
      this.HwidGen(this.Module_FakePay);
      this.HwidGen(this.Module_FakePayments);
      this.HwidGen(this.Module_FakeRoles);
      this.HwidGen(this.Module_FakeScoreboard);
      this.HwidGen(this.Module_GrowthFinder);
   }

   @Override
   public void LicenseState() {
      this.Module_WaterMark = 0;
      this.Module_zelith = this.Module_Configs();
   }

   @Override
   public void Module_f() {
      this.Module_WaterMark = 0;
      this.Module_zelith = 0;
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.world != null) {
         this.Module_WaterMark++;
         if (this.Module_WaterMark >= this.Module_zelith) {
            this.Module_WaterMark = 0;
            this.Module_zelith = this.Module_Configs();
            this.G();
         }
      }
   }

   private int Module_Configs() {
      if ((Boolean)this.Module_FakePay.HwidGen()) {
         int var1 = (Integer)this.Module_FakePayments.HwidGen();
         int var2 = (Integer)this.Module_FakeRoles.HwidGen();
         if (var1 > var2) {
            var1 = var2;
         }

         int var3 = var1 + this.KeyFile.nextInt(var2 - var1 + 1);
         return var3 * 20;
      } else {
         return (Integer)this.Module_EntityScanner.HwidGen() * 20;
      }
   }

   private void G() {
      String var1 = HwidGen[this.KeyFile.nextInt(HwidGen.length)];
      if (this.KeyFile.nextInt(100) < 15) {
         var1 = "." + var1;
      }

      long var2 = this.HwidGen();
      String var4 = this.KeyFile(var2);
      String var5 = this.c(var2);
      MutableText var6 = Text.literal(var1).setStyle(Style.EMPTY.withColor(1024999));
      var6.append(Text.literal(" paid you ").setStyle(Style.EMPTY.withColor(11184810)));
      var6.append(Text.literal("$" + var4 + var5).setStyle(Style.EMPTY.withColor(5635925)));
      var6.append(Text.literal(".").setStyle(Style.EMPTY.withColor(11184810)));
      if (HwidGen.inGameHud != null) {
         HwidGen.inGameHud.getChatHud().addMessage(var6);
      }

      if (HwidGen.player != null) {
         HwidGen.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.0F);
      }

      as var7 = Module_FakeScoreboard.HwidGen();
      if (var7 != null && var7.HwidGen()) {
         var7.KeyFile(var2);
      }
   }

   private long HwidGen() {
      long var1 = this.KeyFile((String)this.Module_FakeScoreboard.HwidGen());
      long var3 = this.KeyFile((String)this.Module_GrowthFinder.HwidGen());
      if (var1 > var3) {
         var1 = var3;
      }

      long var5 = var1 + (long)(this.KeyFile.nextDouble() * (var3 - var1));
      if (var5 >= 10000000L) {
         return var5 / 5000000L * 5000000L;
      } else if (var5 >= 1000000L) {
         return var5 / 1000000L * 1000000L;
      } else if (var5 >= 100000L) {
         return var5 / 100000L * 100000L;
      } else {
         return var5 >= 10000L ? var5 / 10000L * 10000L : var5 / 1000L * 1000L;
      }
   }

   private long KeyFile(String string) {
      string = string.toLowerCase().trim();

      try {
         if (string.endsWith("Module_ActiveModules")) {
            return (long)(Double.parseDouble(string.substring(0, string.length() - 1)) * 1000.0);
         } else if (string.endsWith("Module_Configs")) {
            return (long)(Double.parseDouble(string.substring(0, string.length() - 1)) * 1000000.0);
         } else if (string.endsWith("KeyFile")) {
            return (long)(Double.parseDouble(string.substring(0, string.length() - 1)) * 1.0E9);
         } else {
            return string.endsWith("Module_zelith") ? (long)(Double.parseDouble(string.substring(0, string.length() - 1)) * 1.0E12) : Long.parseLong(string);
         }
      } catch (NumberFormatException var3) {
         return 1000L;
      }
   }

   private String KeyFile(long l) {
      if (l >= 1000000000000L) {
         return String.format("%.0f", l / 1.0E12);
      } else if (l >= 1000000000L) {
         return String.format("%.0f", l / 1.0E9);
      } else if (l >= 1000000L) {
         return String.format("%.0f", l / 1000000.0);
      } else {
         return l >= 1000L ? String.format("%.0f", l / 1000.0) : String.valueOf(l);
      }
   }

   private String c(long l) {
      if (l >= 1000000000000L) {
         return "T";
      } else if (l >= 1000000000L) {
         return "B";
      } else if (l >= 1000000L) {
         return "M";
      } else {
         return l >= 1000L ? "K" : "";
      }
   }
}
