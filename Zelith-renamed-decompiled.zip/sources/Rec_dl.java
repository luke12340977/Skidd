import net.minecraft.item.ItemStack;

public record Rec_dl() {
   private final ItemStack Category;

   public Rec_dl(ItemStack itemStack) {
      this.Category = itemStack;
   }

   public ItemStack KeyFile() {
      return this.Category;
   }
}
