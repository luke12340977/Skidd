class bl$1 extends Setting {
   bl$1(bl arg, String string, String string2) {
      super(string, string2);
   }

   @Override
   public boolean LicenseResult(String string) {
      return super.LicenseResult(string) || "Webhook URL".equalsIgnoreCase(string);
   }
}
