import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpResponse.BodyHandlers;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Base64;
import java.util.Locale;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.client.texture.PlayerSkinTextureDownloader;
import net.minecraft.entity.player.PlayerSkinType;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.AssetInfo.TextureAsset;

public final class Module_SkinChanger extends Module {
   private static final Duration c = Duration.ofSeconds(10L);
   private static final HttpClient LicenseResult = HttpClient.newBuilder().connectTimeout(c).followRedirects(Redirect.NORMAL).build();
   private static volatile SkinTextures HwidGen;
   private static volatile TextureAsset HwidGen;
   private final dd bI = new Setting("Player Name", "");
   private final AtomicInteger KeyFile = new AtomicInteger();
   private PlayerSkinTextureDownloader HwidGen;
   private String Module_DoubleAnchor = "";
   private String A = "";
   private long Module_Themes;

   public Module_SkinChanger() {
      super("Skin Changer", Category.HwidGen);
      this.HwidGen(this.bI);
   }

   @Override
   public void LicenseState() {
      super.LicenseState();
      this.Module_DoubleAnchor = Module((String)this.bI.HwidGen());
      this.A = "";
      this.Module_Themes = System.currentTimeMillis();
      if (this.Module_DoubleAnchor.isEmpty()) {
         Z();
      } else {
         this.Module_j(this.Module_DoubleAnchor);
      }
   }

   @Override
   public void Module_f() {
      super.Module_f();
      this.KeyFile.incrementAndGet();
      this.A = "";
      Z();
   }

   @Override
   public void Category() {
      String var1 = Module((String)this.bI.HwidGen());
      if (!Objects.equals(var1, this.Module_DoubleAnchor)) {
         this.Module_DoubleAnchor = var1;
         this.Module_Themes = System.currentTimeMillis();
      } else if (!var1.isEmpty()) {
         if (!Objects.equals(var1, this.A) && System.currentTimeMillis() - this.Module_Themes >= 600L) {
            this.Module_j(var1);
         }
      } else {
         if (HwidGen != null || HwidGen != null) {
            this.A = "";
            Z();
         }
      }
   }

   public static SkinTextures HwidGen(UUID uUID) {
      if (HwidGen != null && uUID != null) {
         UUID var1 = HwidGen();
         return var1 != null && var1.equals(uUID) ? HwidGen : null;
      } else {
         return null;
      }
   }

   private void Module_j(String string) {
      this.A = string;
      int var2 = this.KeyFile.incrementAndGet();
      CompletableFuture.<bx>supplyAsync(() -> this.HwidGen(string), Util.getIoWorkerExecutor().named("skinchanger-lookup"))
         .thenCompose(
            arg -> this.HwidGen()
               .downloadAndRegisterTexture(this.HwidGen(arg), this.HwidGen(arg.KeyFile()), arg.Module_AnchorMacro(), true)
               .thenApply(textureAsset -> new Rec_bw(arg, textureAsset))
         )
         .whenComplete((arg, throwable) -> HwidGen.execute(() -> {
            if (var2 == this.KeyFile.get() && this.HwidGen()) {
               if (throwable != null) {
                  this.Module_ActiveModules("Failed to apply skin for " + string + ": " + HwidGen(throwable));
               } else {
                  HwidGen(arg.HwidGen(), arg.HwidGen().HwidGen());
                  this.Module_ActiveModules("Applied skin from " + arg.HwidGen().Module_ActiveModules() + ".");
               }
            } else {
               if (arg != null) {
                  HwidGen(arg.HwidGen());
               }
            }
         }));
   }

   private PlayerSkinTextureDownloader HwidGen() {
      if (this.HwidGen == null) {
         this.HwidGen = new PlayerSkinTextureDownloader(HwidGen.getNetworkProxy(), HwidGen.getTextureManager(), HwidGen::execute);
      }

      return this.HwidGen;
   }

   private bx HwidGen(String string) {
      try {
         UUID var2 = this.HwidGen(string);
         by var3 = this.HwidGen(var2);
         return new Rec_bx(string, var2, var3.Module_AnchorMacro(), var3.HwidGen());
      } catch (InterruptedException var4) {
         Thread.currentThread().interrupt();
         throw new IllegalStateException("Request interrupted", var4);
      } catch (IOException var5) {
         throw new IllegalStateException(var5.getMessage(), var5);
      }
   }

   private UUID HwidGen(String string) throws IOException, InterruptedException {
      JsonObject var2 = this.HwidGen("https://api.mojang.com/users/profiles/minecraft/" + this.Category(string));
      if (var2 == null) {
         var2 = this.HwidGen("https://api.minecraftservices.com/minecraft/profile/lookup/name/" + this.Category(string));
      }

      if (var2 != null && var2.has("id")) {
         return KeyFile(var2.get("id").getAsString());
      } else {
         throw new IOException("Player not found");
      }
   }

   private by HwidGen(UUID uUID) throws IOException, InterruptedException {
      JsonObject var2 = this.HwidGen("https://sessionserver.mojang.com/session/minecraft/profile/" + uUID.toString().replace("-", ""));
      if (var2 != null && var2.has("properties")) {
         for (JsonElement var5 : var2.getAsJsonArray("properties")) {
            if (var5.isJsonObject()) {
               JsonObject var6 = var5.getAsJsonObject();
               if ("textures".equalsIgnoreCase(HwidGen(var6, "name")) && var6.has("value")) {
                  String var7 = new String(Base64.getDecoder().decode(var6.get("value").getAsString()), StandardCharsets.UTF_8);
                  JsonObject var8 = JsonParser.parseString(var7).getAsJsonObject();
                  JsonObject var9 = var8.getAsJsonObject("textures");
                  JsonObject var10 = var9 != null ? var9.getAsJsonObject("SKIN") : null;
                  if (var10 != null && var10.has("url")) {
                     String var11 = null;
                     JsonObject var12 = var10.getAsJsonObject("metadata");
                     if (var12 != null && var12.has("model")) {
                        var11 = var12.get("model").getAsString();
                     }

                     PlayerSkinType var13 = "slim".equalsIgnoreCase(var11) ? PlayerSkinType.SLIM : PlayerSkinType.WIDE;
                     return new Rec_by(var10.get("url").getAsString(), var13);
                  }
                  break;
               }
            }
         }

         throw new IOException("No usable skin texture found");
      } else {
         throw new IOException("Skin profile not found");
      }
   }

   private JsonObject HwidGen(String string) throws IOException, InterruptedException {
      HttpRequest var2 = HttpRequest.newBuilder(URI.create(string))
         .timeout(c)
         .header("Accept", "application/json")
         .header("User-Agent", "zelith-SkinChanger")
         .GET()
         .build();
      HttpResponse var3 = LicenseResult.send(var2, BodyHandlers.ofString());
      int var4 = var3.statusCode();
      if (var4 == 404 || var4 == 204) {
         return null;
      } else if (var4 >= 200 && var4 < 300) {
         String var5 = (String)var3.body();
         return var5 != null && !var5.isBlank() ? JsonParser.parseString(var5).getAsJsonObject() : null;
      } else {
         throw new IOException("HTTP " + var4);
      }
   }

   private static synchronized void HwidGen(TextureAsset textureAsset, PlayerSkinType playerSkinType) {
      HwidGen(HwidGen);
      HwidGen = textureAsset;
      HwidGen = SkinTextures.create(textureAsset, null, null, playerSkinType);
   }

   private static synchronized void Z() {
      HwidGen(HwidGen);
      HwidGen = null;
      HwidGen = null;
   }

   private static void HwidGen(TextureAsset textureAsset) {
      if (textureAsset != null && HwidGen != null) {
         try {
            HwidGen.getTextureManager().destroyTexture(textureAsset.texturePath());
         } catch (Throwable var3) {
         }

         try {
            if (!textureAsset.id().equals(textureAsset.texturePath())) {
               HwidGen.getTextureManager().destroyTexture(textureAsset.id());
            }
         } catch (Throwable var2) {
         }
      }
   }

   private void Module_ActiveModules(String string) {
      if (HwidGen != null && HwidGen.inGameHud != null) {
         try {
            HwidGen.inGameHud.getChatHud().addMessage(Text.literal("[SkinChanger] " + string));
         } catch (Throwable var3) {
         }
      }
   }

   private Identifier HwidGen(bx arg) {
      String var2 = arg.Module_ActiveModules().toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_]", "");
      if (var2.isEmpty()) {
         var2 = "player";
      }

      return Identifier.of("zelith", "skins/" + var2 + "_" + arg.KeyFile().toString().replace("-", ""));
   }

   private Path HwidGen(UUID uUID) {
      return HwidGen.runDirectory.toPath().resolve("zelith-cache").resolve("skins").resolve(uUID.toString().replace("-", "") + ".png");
   }

   private String Category(String string) {
      return URLEncoder.encode(string, StandardCharsets.UTF_8);
   }

   private static UUID KeyFile(String string) {
      String var1 = string.replace("-", "");
      return UUID.fromString(var1.replaceFirst("(\\p{XDigit}{8})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}+)", "$1-$2-$3-$4-$5"));
   }

   private static String Module(String string) {
      return string == null ? "" : string.trim();
   }

   private static String HwidGen(JsonObject jsonObject, String string) {
      return jsonObject.has(string) ? jsonObject.get(string).getAsString() : "";
   }

   private static String HwidGen(Throwable throwable) {
      Throwable var1 = throwable;

      while (var1.getCause() != null) {
         var1 = var1.getCause();
      }

      String var2 = var1.getMessage();
      return var2 != null && !var2.isBlank() ? var2 : var1.getClass().getSimpleName();
   }

   private static UUID HwidGen() {
      if (HwidGen == null) {
         return null;
      } else if (HwidGen.player != null) {
         return HwidGen.player.getUuid();
      } else {
         return HwidGen.getSession() != null ? HwidGen.getSession().getUuidOrNull() : null;
      }
   }
}
