import java.awt.Color;

public final class Module_Themes extends Module {
   public static r HwidGen;
   private final dd HudElement = new Setting("Custom Color", new Color(107, 211, 165, 255));
   private final cy HwidGen = new Misc_cy(
      "Theme Presets",
      "zelith Green",
      "zelith Green",
      "Sunset Orange",
      "Crimson Red",
      "Ocean Blue",
      "Royal Purple",
      "Hot Pink",
      "Cyber Cyan",
      "Sunshine Yellow",
      "Mint Fresh",
      "Midnight Gray",
      "Custom"
   );

   public Module_Themes() {
      super("Themes", Category.Module_f);
      this.HwidGen(this.HwidGen);
      this.HwidGen(this.HudElement);
      HwidGen = this;
   }

   public static Color KeyFile() {
      if (HwidGen == null) {
         return null;
      } else if ("Custom".equals(HwidGen.HwidGen.HwidGen())) {
         return (Color)HwidGen.HudElement.HwidGen();
      } else {
         String var0 = (String)HwidGen.HwidGen.HwidGen();

         return switch (var0) {
            case "Sunset Orange" -> new Color(255, 140, 50);
            case "Crimson Red" -> new Color(229, 75, 75);
            case "Ocean Blue" -> new Color(72, 160, 255);
            case "Royal Purple" -> new Color(170, 110, 240);
            case "Hot Pink" -> new Color(255, 100, 180);
            case "Cyber Cyan" -> new Color(80, 220, 230);
            case "Sunshine Yellow" -> new Color(250, 210, 80);
            case "Mint Fresh" -> new Color(120, 230, 180);
            case "Midnight Gray" -> new Color(160, 170, 185);
            case "zelith Green" -> new Color(107, 211, 165);
            default -> null;
         };
      }
   }
}
