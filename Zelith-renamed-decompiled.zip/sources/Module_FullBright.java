import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import net.minecraft.client.option.SimpleOption;

public final class Module_FullBright extends Module {
   private double KeyFile = 1.0;
   private boolean P = false;
   private Object HwidGen;
   private static Field HwidGen;

   public Module_FullBright() {
      super("Full Bright", Category.KeyFile);
   }

   @Override
   public void LicenseState() {
      if (HwidGen.options != null) {
         this.KeyFile = (Double)HwidGen.options.getGamma().getValue();
         this.KeyFile(10.0);
         this.P = true;
         this.HwidGen = HwidGen.world;
      }
   }

   @Override
   public void Module_f() {
      if (this.P) {
         this.KeyFile(this.KeyFile);
         this.P = false;
      }
   }

   @Override
   public void Category() {
      if (HwidGen.options != null) {
         if (HwidGen.world != this.HwidGen) {
            this.HwidGen = HwidGen.world;
            if (HwidGen.world != null) {
               if (!this.P) {
                  this.KeyFile = (Double)HwidGen.options.getGamma().getValue();
                  this.P = true;
               }

               this.KeyFile(10.0);
            }
         } else if (this.P) {
            try {
               double var1 = (Double)HwidGen.options.getGamma().getValue();
               if (Math.abs(var1 - 10.0) > 1.0E-4) {
                  this.KeyFile(10.0);
               }
            } catch (Exception var3) {
            }
         }
      }
   }

   private void KeyFile(double d) {
      SimpleOption var3 = HwidGen.options.getGamma();
      Field var4 = HwidGen;
      if (var4 == null) {
         var4 = this.HwidGen(var3);
         HwidGen = var4;
      }

      if (var4 != null) {
         try {
            var4.set(var3, d);
            Double var5 = (Double)var3.getValue();
            if (var5 != null && Math.abs(var5 - d) <= 1.0E-4) {
               return;
            }

            HwidGen = null;
         } catch (Exception var7) {
         }
      }

      try {
         var3.setValue(d);
      } catch (Exception var6) {
      }
   }

   private Field HwidGen(SimpleOption simpleOption) {
      Object var2;
      try {
         var2 = simpleOption.getValue();
      } catch (Exception var9) {
         var2 = null;
      }

      Field var3 = null;

      for (Field var7 : SimpleOption.class.getDeclaredFields()) {
         if (!Modifier.isStatic(var7.getModifiers())) {
            if ("value".equals(var7.getName())) {
               var3 = var7;
            }

            var7.setAccessible(true);

            try {
               Object var8 = var7.get(simpleOption);
               if (var2 == null ? var8 == null : var2.equals(var8)) {
                  return var7;
               }
            } catch (Exception var10) {
            }
         }
      }

      if (var3 != null) {
         var3.setAccessible(true);
         return var3;
      } else {
         return null;
      }
   }
}
