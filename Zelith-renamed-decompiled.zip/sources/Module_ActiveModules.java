import com.zelith.gui.ClickGUI;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class Module_ActiveModules extends Module {
   private final Map HwidGen = new HashMap();
   private long HwidGen = System.nanoTime();

   public Module_ActiveModules() {
      super("Active Modules", Category.Module_f);
      HudRenderCallback.EVENT.register((HudRenderCallback)(drawContext, renderTickCounter) -> {
         if (this.HwidGen()) {
            this.render(drawContext);
         }
      });
   }

   private void render(DrawContext drawContext) {
      MinecraftClient var2 = MinecraftClient.getInstance();
      if (var2 != null && var2.player != null) {
         if (!(var2.currentScreen instanceof ClickGUI)) {
            if (!var2.getDebugHud().shouldShowDebugHud()) {
               long var3 = System.nanoTime();
               float var5 = Math.min((float)(var3 - this.HwidGen) / 1.0E9F, 0.05F);
               this.HwidGen = var3;
               TextRenderer var6 = var2.textRenderer;
               int var7 = Module_zelith.Category();
               int var8 = var2.getWindow().getScaledWidth();
               ArrayList var9 = new ArrayList();

               for (Module var11 : SwapHelper.HwidGen.KeyFile()) {
                  if (var11.HwidGen() && var11.HwidGen() != Category.Module_f && var11 != this) {
                     var9.add(var11);
                  }
               }

               for (Module var30 : var9) {
                  ClickBuf var12 = (ClickBuf)this.HwidGen.get(var30);
                  if (var12 == null) {
                     this.HwidGen.put(var30, new ClickBuf(true));
                  } else if (!var12.Category) {
                     var12.Category = true;
                  }
               }

               Iterator var29 = this.HwidGen.entrySet().iterator();

               while (var29.hasNext()) {
                  Entry var31 = (Entry)var29.next();
                  ClickBuf var33 = (ClickBuf)var31.getValue();
                  if (!var9.contains(var31.getKey()) && var33.Category) {
                     var33.Category = false;
                  }

                  var33.HwidGen = var33.HwidGen + (var33.Category ? 1 : -1) * var5 * 5.0F;
                  if (var33.HwidGen <= 0.0F) {
                     var29.remove();
                  } else if (var33.HwidGen > 1.0F) {
                     var33.HwidGen = 1.0F;
                  }
               }

               ArrayList var32 = new ArrayList(this.HwidGen.keySet());
               var32.sort(Comparator.<h>comparingInt(arg -> var6.getWidth(arg.c())).reversed());
               float var34 = Obj_dr.Module_ActiveModules();
               int var13 = Math.round(10.0F * var34);

               for (Module var15 : var32) {
                  ClickBuf var16 = (ClickBuf)this.HwidGen.get(var15);
                  if (var16 != null) {
                     float var17 = 1.0F - (float)Math.pow(1.0F - var16.HwidGen, 3.0);
                     int var18 = Math.round(var17 * 255.0F);
                     String var19 = var15.c();
                     int var20 = Math.round(var6.getWidth(var19) * var34);
                     int var21 = var20 + Math.round(14.0F * var34);
                     int var22 = Math.round(14.0F * var34);
                     int var23 = (int)(var8 - Math.round(2.0F * var34) - var21 * var17);
                     int var24 = var18 << 24 | 1120804;
                     int var25 = var18 << 24 | var7 & 16777215;
                     int var26 = var18 << 24 | 15922939;
                     int var27 = var18 << 24 | 4491519;
                     Obj_dr.HwidGen(drawContext, (float)var23, (float)var13, (float)var21, (float)var22, 6.0F * var34, var24, false);
                     Obj_dr.HwidGen(
                        drawContext,
                        (float)(var23 + var21 - Math.round(3.0F * var34)),
                        (float)(var13 + Math.round(1.0F * var34)),
                        (float)Math.round(3.0F * var34),
                        (float)(var22 - Math.round(2.0F * var34)),
                        1.5F * var34,
                        var25,
                        false
                     );
                     drawContext.getMatrices().pushMatrix();
                     drawContext.getMatrices().translate(var23 + Math.round(7.0F * var34), var13 + Math.round(3.0F * var34));
                     drawContext.getMatrices().scale(var34, var34);
                     drawContext.drawText(var6, var19, 0, 0, var26, false);
                     drawContext.getMatrices().popMatrix();
                     var13 += var22 + Math.round(4.0F * var34);
                  }
               }
            }
         }
      }
   }
}
