import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;

public final class Module_Triggerbot extends Module {
   private final dd Y = new Setting("Only Crit", false);
   private final dd Z = new Setting("Check Shield", false);
   private int ClickBuf = 0;

   public Module_Triggerbot() {
      super("Triggerbot", Category.c);
      this.HwidGen(this.Y);
      this.HwidGen(this.Z);
   }

   @Override
   public void LicenseState() {
      this.ClickBuf = 0;
   }

   @Override
   public void Module_f() {
      this.ClickBuf = 0;
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.world != null) {
         if (HwidGen.currentScreen == null) {
            if (this.ClickBuf > 0) {
               this.ClickBuf--;
            } else if (HwidGen.crosshairTarget != null && HwidGen.crosshairTarget.getType() == Type.ENTITY) {
               if (HwidGen.crosshairTarget instanceof EntityHitResult var1) {
                  Entity var4 = var1.getEntity();
                  if (var4 instanceof LivingEntity) {
                     if (var4 != HwidGen.player) {
                        if (!(var4 instanceof PlayerEntity var3 && Module_Friends.KeyFile() && Module_Friends.HwidGen(var3.getName().getString()))) {
                           if (!HwidGen.options.attackKey.isPressed()) {
                              if (this.HwidGen((LivingEntity)var4)) {
                                 this.HwidGen(var4);
                                 this.ClickBuf = 9;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private boolean HwidGen(LivingEntity livingEntity) {
      return this.Y.HwidGen() && !this.HwidGen(HwidGen.player) ? false : !(Boolean)this.Z.HwidGen() || !this.KeyFile(livingEntity);
   }

   private boolean KeyFile(LivingEntity livingEntity) {
      ItemStack var2 = livingEntity.getMainHandStack();
      ItemStack var3 = livingEntity.getOffHandStack();
      return var2.getItem() == Items.SHIELD || var3.getItem() == Items.SHIELD;
   }

   private boolean HwidGen(PlayerEntity playerEntity) {
      if (playerEntity.fallDistance <= 0.05F) {
         return false;
      } else if (playerEntity.isOnGround()) {
         return false;
      } else {
         return !playerEntity.isTouchingWater() && !playerEntity.isInLava() && !playerEntity.isClimbing() && !playerEntity.hasVehicle()
            ? !playerEntity.isSprinting()
            : false;
      }
   }

   private void HwidGen(Entity entity) {
      HwidGen.interactionManager.attackEntity(HwidGen.player, entity);
      HwidGen.player.swingHand(Hand.MAIN_HAND);
   }
}
