import com.zelith.gui.notification.NotificationManager;
import java.awt.Color;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDeltaUpdateS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

public final class Module_BlockESP extends Module {
   private final cv HwidGen = new SettingBlock("Blocks", Blocks.SPAWNER);
   private final dd Module_TPASpammer = new Setting("Color", new Color(255, 255, 0));
   private final dd Module_WeatherNotifier = new Setting("Notification", true);
   private final dd Module_AmethystESP = new Setting("ESP", true);
   private final dd Module_BedrockHoleESP = new Setting("Tracers", false);
   private final Map Module_Friends = new ConcurrentHashMap();
   private final Map Module_Hud = new ConcurrentHashMap();
   private final Map HudElement = new ConcurrentHashMap();
   private final ArrayDeque HwidGen = new ArrayDeque();
   private final Set Module_SpotifyHUD = new HashSet();
   private final Object KeyFile = new Object();
   private volatile Set Module_Themes = Collections.emptySet();
   private long Module_WaterMark = -1L;
   private int tickCounter = 0;
   private boolean M = true;
   private ChunkPos LicenseResult;
   private int Module_ShieldBreaker = -1;

   public Module_BlockESP() {
      super("Block ESP", Category.KeyFile);
      this.HwidGen(this.HwidGen);
      this.HwidGen(this.Module_TPASpammer);
      this.HwidGen(this.Module_WeatherNotifier);
      this.HwidGen(this.Module_AmethystESP);
      this.HwidGen(this.Module_BedrockHoleESP);
   }

   @Override
   public void LicenseState() {
      this.Module_ShieldBreaker();
      this.Module_WaterMark = -1L;
      this.M = true;
      this.tickCounter = 0;
      this.LicenseResult = null;
      this.Module_ShieldBreaker = -1;
   }

   @Override
   public void Module_f() {
      this.Module_ShieldBreaker();
      this.LicenseResult = null;
      this.Module_ShieldBreaker = -1;
   }

   @Override
   public void Category() {
      if (HwidGen.world != null && HwidGen.player != null) {
         this.Module_HoverTotem();
         if (this.Module_Themes.isEmpty()) {
            this.Module_ShieldBreaker();
         } else {
            this.tickCounter++;
            ChunkPos var1 = HwidGen.player.getChunkPos();
            int var2 = this.D();
            boolean var3 = this.M || this.tickCounter % 40 == 0;
            if (var3 || this.LicenseResult == null || !this.LicenseResult.equals(var1) || this.Module_ShieldBreaker != var2) {
               this.LicenseResult(var3);
               this.M = false;
               this.LicenseResult = var1;
               this.Module_ShieldBreaker = var2;
            }

            for (int var4 = 0; var4 < 6; var4++) {
               Long var5;
               synchronized (this.KeyFile) {
                  var5 = (Long)this.HwidGen.poll();
                  if (var5 != null) {
                     this.Module_SpotifyHUD.remove(var5);
                  }
               }

               if (var5 == null) {
                  break;
               }

               int var10 = ChunkPos.getPackedX(var5);
               int var7 = ChunkPos.getPackedZ(var5);
               WorldChunk var8 = HwidGen.world.getChunkManager().getWorldChunk(var10, var7, false);
               if (var8 != null) {
                  this.HwidGen(var8);
               }
            }
         }
      }
   }

   @Override
   public void HwidGen(Packet packet) {
      if (HwidGen.world != null) {
         if (packet instanceof ChunkDataS2CPacket var4) {
            this.HwidGen(ChunkPos.toLong(var4.getChunkX(), var4.getChunkZ()), true);
         } else if (packet instanceof ChunkDeltaUpdateS2CPacket var3) {
            var3.visitUpdates((blockPos, blockState) -> this.HwidGen(new ChunkPos(blockPos).toLong(), true));
         } else {
            if (packet instanceof BlockUpdateS2CPacket var2) {
               this.HwidGen(new ChunkPos(var2.getPos()).toLong(), true);
            }
         }
      }
   }

   @Override
   public void HwidGen(MatrixStack matrixStack, float f) {
      if (HwidGen.world != null && HwidGen.player != null && !this.Module_Friends.isEmpty()) {
         if ((Boolean)this.Module_AmethystESP.HwidGen() || (Boolean)this.Module_BedrockHoleESP.HwidGen()) {
            Set var3 = this.Module_Themes;
            if (!var3.isEmpty()) {
               Camera var4 = Render_dm.HwidGen();
               if (var4 != null) {
                  Vec3d var5 = Render_dm.HwidGen(var4);
                  Vec3d var6 = Render_dm.KeyFile(var4);
                  Vec3d var7 = Render_dm.c(var4);
                  Vec3d var8 = Render_dm.HwidGen(var6, var7);
                  boolean var9 = Module_Freecam.HwidGen != null && Module_Freecam.HwidGen.HwidGen();
                  Vec3d var10 = var9
                     ? new Vec3d(HwidGen.player.getX() - var5.x, HwidGen.player.getY() - var5.y, HwidGen.player.getZ() - var5.z)
                     : var6.multiply(150.0);
                  double var11 = this.HwidGen();
                  do var13 = Render_dm.HwidGen(matrixStack);
                  boolean var14 = false;
                  GL11.glDisable(2929);

                  try {
                     for (Set var16 : this.Module_Friends.values()) {
                        for (BlockPos var18 : var16) {
                           if (!(var18.getSquaredDistance(HwidGen.player.getX(), HwidGen.player.getY(), HwidGen.player.getZ()) > var11)) {
                              Block var19 = (Block)this.Module_Hud.get(var18);
                              if (var19 == null) {
                                 BlockState var20 = HwidGen.world.getBlockState(var18);
                                 var19 = var20.getBlock();
                              }

                              if (var3.contains(var19)) {
                                 Color var34 = (Color)this.Module_TPASpammer.HwidGen();
                                 Color var21 = new Color(var34.getRed(), var34.getGreen(), var34.getBlue(), 110);
                                 double var22 = var18.getX() - var5.x;
                                 double var24 = var18.getY() - var5.y;
                                 double var26 = var18.getZ() - var5.z;
                                 if ((Boolean)this.Module_AmethystESP.HwidGen()) {
                                    BlockState var28 = HwidGen.world.getBlockState(var18);
                                    VoxelShape var29 = var28.getCollisionShape(HwidGen.world, var18);
                                    if (!var29.isEmpty()) {
                                       Box var30 = var29.getBoundingBox();
                                       var13.KeyFile(
                                          var22 + var30.minX,
                                          var24 + var30.minY,
                                          var26 + var30.minZ,
                                          var22 + var30.maxX,
                                          var24 + var30.maxY,
                                          var26 + var30.maxZ,
                                          var21
                                       );
                                       var13.HwidGen(
                                          var22 + var30.minX,
                                          var24 + var30.minY,
                                          var26 + var30.minZ,
                                          var22 + var30.maxX,
                                          var24 + var30.maxY,
                                          var26 + var30.maxZ,
                                          var21
                                       );
                                    } else {
                                       var13.KeyFile(var22, var24, var26, var22 + 1.0, var24 + 1.0, var26 + 1.0, var21);
                                       var13.HwidGen(var22, var24, var26, var22 + 1.0, var24 + 1.0, var26 + 1.0, var21);
                                    }
                                 }

                                 if ((Boolean)this.Module_BedrockHoleESP.HwidGen()) {
                                    Vec3d var35 = new Vec3d(var22 + 0.5, var24 + 0.5, var26 + 0.5);
                                    Vec3d var36 = Render_dm.HwidGen(var35, var6, var7, var8, 24.0, 2.75);
                                    var13.HwidGen(var21, var10, var36, Module_zelith.KeyFile());
                                 }

                                 var14 = true;
                              }
                           }
                        }
                     }

                     if (var14) {
                        var13.Module_FakePay();
                     }
                  } finally {
                     GL11.glEnable(2929);
                  }
               }
            }
         }
      }
   }

   private void Module_HoverTotem() {
      long var1 = this.HwidGen.c();
      if (var1 != this.Module_WaterMark) {
         this.Module_WaterMark = var1;
         this.Module_Themes = Set.copyOf(this.HwidGen.KeyFile());
         this.Module_ShieldBreaker();
         this.M = true;
      }
   }

   private void LicenseResult(boolean bl) {
      if (HwidGen.world != null && HwidGen.player != null) {
         int var2 = this.D();
         ChunkPos var3 = HwidGen.player.getChunkPos();
         ArrayList var4 = new ArrayList();
         HashSet var5 = new HashSet();

         for (int var6 = -var2; var6 <= var2; var6++) {
            for (int var7 = -var2; var7 <= var2; var7++) {
               WorldChunk var8 = HwidGen.world.getChunkManager().getWorldChunk(var3.x + var6, var3.z + var7, false);
               if (var8 != null) {
                  var4.add(var8);
                  var5.add(var8.getPos().toLong());
               }
            }
         }

         var4.sort(Comparator.comparingInt(worldChunk -> this.HwidGen(var3, worldChunk.getPos())));
         synchronized (this.KeyFile) {
            this.HwidGen.removeIf(long_ -> !var5.contains(long_));
            this.Module_SpotifyHUD.retainAll(var5);

            for (WorldChunk var16 : var4) {
               long var9 = var16.getPos().toLong();
               boolean var11 = bl || !this.Module_Friends.containsKey(var9);
               if (var11 && this.Module_SpotifyHUD.add(var9)) {
                  this.HwidGen.addLast(var9);
               }
            }
         }

         this.c(var3, var2);
      }
   }

   private void HwidGen(long l, boolean bl) {
      synchronized (this.KeyFile) {
         if (bl && this.Module_SpotifyHUD.contains(l)) {
            this.HwidGen.remove(l);
            this.HwidGen.addFirst(l);
         } else if (this.Module_SpotifyHUD.add(l)) {
            if (bl) {
               this.HwidGen.addFirst(l);
            } else {
               this.HwidGen.add(l);
            }
         }
      }
   }

   private void HwidGen(WorldChunk worldChunk) {
      Set var2 = this.Module_Themes;
      if (!var2.isEmpty()) {
         int var3 = HwidGen.world.getBottomY();
         int var4 = HwidGen.world.getBottomY() + HwidGen.world.getHeight();
         int var5 = HwidGen.world.getBottomSectionCoord();
         ChunkPos var6 = worldChunk.getPos();
         long var7 = var6.toLong();
         Set var9 = (Set)this.Module_Friends.get(var7);
         HashSet var10 = new HashSet();
         Block var11 = null;
         BlockPos var12 = null;
         ChunkSection[] var13 = worldChunk.getSectionArray();

         for (int var14 = 0; var14 < var13.length; var14++) {
            ChunkSection var15 = var13[var14];
            if (var15 != null && !var15.isEmpty()) {
               int var16 = (var5 + var14) * 16;
               if (var16 + 16 > var3 && var16 < var4) {
                  for (int var17 = 0; var17 < 16; var17++) {
                     for (int var18 = 0; var18 < 16; var18++) {
                        for (int var19 = 0; var19 < 16; var19++) {
                           BlockState var20 = var15.getBlockState(var17, var19, var18);
                           Block var21 = var20.getBlock();
                           if (var2.contains(var21)) {
                              BlockPos var22 = new BlockPos(var6.getStartX() + var17, var16 + var19, var6.getStartZ() + var18);
                              var10.add(var22);
                              this.Module_Hud.put(var22, var21);
                              if (var11 == null && (var9 == null || !var9.contains(var22))) {
                                 var11 = var21;
                                 var12 = var22;
                              }
                           }
                        }
                     }
                  }
               }
            }
         }

         if (var9 != null) {
            for (BlockPos var24 : var9) {
               if (!var10.contains(var24)) {
                  this.Module_Hud.remove(var24);
               }
            }
         }

         if (var10.isEmpty()) {
            this.LicenseResult(var7);
            this.HudElement.remove(var7);
         } else {
            this.Module_Friends.put(var7, var10);
            if (var11 != null && var12 != null) {
               this.HwidGen(var7, var11, var12, var6);
            }
         }
      }
   }

   private void HwidGen(long l, Block block, BlockPos blockPos, ChunkPos chunkPos) {
      if ((Boolean)this.Module_WeatherNotifier.HwidGen() && HwidGen.player != null) {
         long var6 = System.currentTimeMillis();
         long var8 = this.HudElement.getOrDefault(l, 0L);
         if (var6 - var8 >= 750L) {
            this.HudElement.put(l, var6);
            NotificationManager.INSTANCE
               .push(
                  this.HwidGen(block) + " found",
                  "X " + blockPos.getX() + "  Y " + blockPos.getY() + "  Z " + blockPos.getZ(),
                  this.HwidGen(block),
                  this.HwidGen(block, 255).getRGB()
               );
            HwidGen.world
               .playSound(
                  HwidGen.player,
                  HwidGen.player.getX(),
                  HwidGen.player.getY(),
                  HwidGen.player.getZ(),
                  SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP,
                  SoundCategory.MASTER,
                  0.6F,
                  0.95F
               );
         }
      }
   }

   private ItemStack HwidGen(Block block) {
      ItemStack var2 = new ItemStack(block.asItem());
      return var2.isEmpty() ? ItemStack.EMPTY : var2;
   }

   private int HwidGen(ChunkPos chunkPos, ChunkPos chunkPos2) {
      int var3 = chunkPos2.x - chunkPos.x;
      int var4 = chunkPos2.z - chunkPos.z;
      return var3 * var3 + var4 * var4;
   }

   private int D() {
      return HwidGen.options.getClampedViewDistance();
   }

   private double HwidGen() {
      double var1 = this.D() * 16.0 + 16.0;
      return var1 * var1;
   }

   private void c(ChunkPos chunkPos, int i) {
      ArrayList var3 = new ArrayList();

      for (Long var5 : this.Module_Friends.keySet()) {
         ChunkPos var6 = new ChunkPos(ChunkPos.getPackedX(var5), ChunkPos.getPackedZ(var5));
         if (Math.abs(var6.x - chunkPos.x) > i || Math.abs(var6.z - chunkPos.z) > i) {
            var3.add(var5);
         }
      }

      for (Long var8 : var3) {
         this.LicenseResult(var8);
         this.HudElement.remove(var8);
      }
   }

   private void LicenseResult(long l) {
      Set var3 = (Set)this.Module_Friends.remove(l);
      if (var3 != null) {
         for (BlockPos var5 : var3) {
            this.Module_Hud.remove(var5);
         }
      }
   }

   private Color HwidGen(Block block, int i) {
      Identifier var3 = Registries.BLOCK.getId(block);
      String var4 = var3 == null ? "" : var3.getPath();
      if (block == Blocks.SPAWNER) {
         return new Color(138, 126, 166, i);
      } else if (var4.contains("diamond")) {
         return new Color(0, 255, 255, i);
      } else if (var4.contains("ancient_debris")) {
         return new Color(196, 120, 72, i);
      } else if (var4.contains("emerald")) {
         return new Color(0, 255, 127, i);
      } else if (var4.contains("gold")) {
         return new Color(255, 215, 0, i);
      } else if (var4.contains("iron")) {
         return new Color(213, 213, 213, i);
      } else if (var4.contains("redstone")) {
         return new Color(255, 70, 70, i);
      } else {
         return var4.contains("lapis") ? new Color(70, 110, 255, i) : new Color(255, 255, 0, i);
      }
   }

   private String HwidGen(Block block) {
      try {
         return block.getName().getString();
      } catch (Exception var4) {
         Identifier var3 = Registries.BLOCK.getId(block);
         return var3 == null ? "Block" : var3.toString();
      }
   }

   private void Module_ShieldBreaker() {
      this.Module_Friends.clear();
      this.Module_Hud.clear();
      this.HudElement.clear();
      synchronized (this.KeyFile) {
         this.HwidGen.clear();
         this.Module_SpotifyHUD.clear();
      }
   }
}
