import it.unimi.dsi.fastutil.longs.Long2IntOpenHashMap;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import it.unimi.dsi.fastutil.longs.Long2IntMap.Entry;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.world.LightType;
import net.minecraft.world.chunk.WorldChunk;
import org.lwjgl.opengl.GL11;

public class Module_LightESP extends Module {
   private final cy Module_ActiveModules = new Misc_cy(
      "Color", "Classic", new String[]{"ColorMode", "Color Mode"}, "Grayscale", "Ocean", "Warm", "Cool", "Classic"
   );
   private final dd Module_Freecam = new Setting("Alpha", 160.0F, 0.0F, 255.0F);
   private final dd Module_FullBright = new Module_LightESP$1(this, "MaxY", -50, -63, 16);
   private final dd Module_LightESP = new Module_LightESP$2(this, "ChunkRadius", 8, 1, 12);
   private static final ck[] HwidGen = new Obj_ck[0];
   private final Map Module_SpotifyHUD = new ConcurrentHashMap();
   private volatile ck[] KeyFile = HwidGen;
   private volatile ChunkPos LicenseState = null;
   private volatile ClientWorld HwidGen = null;
   private volatile int Module_SpearSwap = Integer.MIN_VALUE;
   private volatile int Module_Triggerbot = Integer.MIN_VALUE;
   private final ExecutorService KeyFile = Executors.newSingleThreadExecutor(runnable -> {
      Thread var1 = new Thread(runnable, "zelith-light-debug");
      var1.setDaemon(true);
      return var1;
   });
   private final AtomicBoolean KeyFile = new AtomicBoolean(false);
   private final AtomicBoolean c = new AtomicBoolean(false);
   private final AtomicBoolean LicenseResult = new AtomicBoolean(true);
   private final AtomicBoolean LicenseState = new AtomicBoolean(false);
   private final AtomicBoolean Module_f = new AtomicBoolean(false);
   private volatile long Module_AnchorMacro = 0L;
   private volatile long Module_AutoCrystal = Long.MIN_VALUE;
   private volatile String E = "";

   public Module_LightESP() {
      super("Light ESP", Category.KeyFile);
      this.HwidGen(this.Module_ActiveModules);
      this.HwidGen(this.Module_Freecam);
      this.HwidGen(this.Module_FullBright);
      this.HwidGen(this.Module_LightESP);
   }

   @Override
   public void LicenseState() {
      this.Module_AutoRender();
      this.LicenseResult.set(true);
      this.LicenseState.set(true);
      this.Module_f.set(true);
      this.Module_Triggerbot();
   }

   @Override
   public void Module_f() {
      this.Module_AutoRender();
   }

   @Override
   public void Category() {
      if (HwidGen.world != null && HwidGen.player != null) {
         this.Module_AnchorMacro++;
         ChunkPos var1 = HwidGen.player.getChunkPos();
         long var2 = this.Module_AnchorMacro;
         int var4 = this.E();
         int var5 = this.F();
         String var6 = (String)this.Module_ActiveModules.HwidGen();
         boolean var7 = !var1.equals(this.LicenseState);
         boolean var8 = HwidGen.world != this.HwidGen;
         boolean var9 = var4 != this.Module_SpearSwap || var5 != this.Module_Triggerbot;
         boolean var10 = !var6.equalsIgnoreCase(this.E);
         if (var8 || var9) {
            this.LicenseResult.set(true);
         }

         if (var10) {
            this.Module_f.set(true);
         }

         if (var2 - this.Module_AutoCrystal >= 16L) {
            this.LicenseState.set(true);
         }

         if (var7) {
            this.LicenseState = var1;
         }

         if (var7 || this.LicenseResult.get() || this.LicenseState.get() || this.Module_f.get()) {
            this.Module_Triggerbot();
         }

         this.E = var6;
      }
   }

   private void Module_Triggerbot() {
      this.c.set(true);
      if (this.KeyFile.compareAndSet(false, true)) {
         this.KeyFile.submit(this::Module_ActivityFinder);
      }
   }

   private void Module_ActivityFinder() {
      try {
         while (this.c.getAndSet(false)) {
            this.Module_AntiTrap();
         }
      } catch (Exception var5) {
         var5.printStackTrace();
      } finally {
         this.KeyFile.set(false);
         if (this.c.get() && this.KeyFile.compareAndSet(false, true)) {
            this.KeyFile.submit(this::Module_ActivityFinder);
         }
      }
   }

   private void Module_AntiTrap() {
      if (this.HwidGen() && HwidGen.world != null && HwidGen.player != null) {
         ClientWorld var1 = HwidGen.world;
         ChunkPos var2 = HwidGen.player.getChunkPos();
         int var3 = this.E();
         int var4 = this.F();
         boolean var5 = this.LicenseResult.getAndSet(false) || var1 != this.HwidGen || var3 != this.Module_SpearSwap || var4 != this.Module_Triggerbot;
         boolean var6 = var5 || this.LicenseState.getAndSet(false);
         boolean var7 = var5 || var6 || this.Module_f.getAndSet(false);
         long var8 = this.Module_AnchorMacro;
         LongSet var10 = this.HwidGen(var2, var3);
         HashMap var11 = var5 ? new HashMap(var10.size()) : new HashMap(this.Module_SpotifyHUD);
         if (!var5) {
            var11.keySet().removeIf(long_ -> !var10.contains(long_));
         }

         LongIterator var12 = var10.iterator();

         while (var12.hasNext()) {
            long var13 = (Long)var12.next();
            Obj_ck var15 = (Obj_ck)var11.get(var13);
            if (var6 || var15 == null) {
               int var16 = ChunkPos.getPackedX(var13);
               int var17 = ChunkPos.getPackedZ(var13);
               if (!var1.isChunkLoaded(var16, var17)) {
                  var11.remove(var13);
               } else {
                  WorldChunk var18 = var1.getChunkManager().getWorldChunk(var16, var17, false);
                  if (var18 == null) {
                     var11.remove(var13);
                  } else {
                     ck var19 = this.HwidGen(var1, var18, var4);
                     if (var19 == null) {
                        var11.remove(var13);
                     } else {
                        var11.put(var13, var19);
                     }
                  }
               }
            } else if (var7) {
               var11.put(var13, this.HwidGen(var15));
            }
         }

         if (this.HwidGen()) {
            this.Module_SpotifyHUD.clear();
            this.Module_SpotifyHUD.putAll(var11);
            this.KeyFile = var11.values().toArray(new Obj_ck[0]);
            this.HwidGen = var1;
            this.LicenseState = var2;
            this.Module_SpearSwap = var3;
            this.Module_Triggerbot = var4;
            if (var6) {
               this.Module_AutoCrystal = var8;
            }
         }
      }
   }

   private ck HwidGen(ClientWorld clientWorld, WorldChunk worldChunk, int i) {
      ChunkPos var4 = worldChunk.getPos();
      int var5 = var4.getStartX();
      int var6 = var4.getStartZ();
      int var7 = var5 + 15;
      int var8 = var6 + 15;
      int var9 = i - -64 + 1;
      Long2IntOpenHashMap var10 = new Long2IntOpenHashMap(Math.max(512, 324 * var9 / 4));
      var10.defaultReturnValue(0);
      Mutable var11 = new Mutable();

      for (int var12 = var5 - 1; var12 <= var7 + 1; var12++) {
         for (int var13 = var6 - 1; var13 <= var8 + 1; var13++) {
            for (int var14 = -64; var14 <= i; var14++) {
               var11.set(var12, var14, var13);
               int var15 = clientWorld.getLightLevel(LightType.BLOCK, var11);
               if (var15 > 0) {
                  int var16 = clientWorld.getLightLevel(LightType.SKY, var11);
                  if (var15 > var16) {
                     var10.put(BlockPos.asLong(var12, var14, var13), var15);
                  }
               }
            }
         }
      }

      if (var10.isEmpty()) {
         return null;
      } else {
         LongSet var25 = var10.keySet();
         int[] var26 = new int[var10.size() * 5];
         int var27 = 0;
         int var28 = Integer.MAX_VALUE;
         ObjectIterator var29 = var10.long2IntEntrySet().iterator();

         while (var29.hasNext()) {
            Entry var17 = (Entry)var29.next();
            long var18 = var17.getLongKey();
            int var20 = BlockPos.unpackLongX(var18);
            int var21 = BlockPos.unpackLongY(var18);
            int var22 = BlockPos.unpackLongZ(var18);
            if (var20 >= var5 && var20 <= var7 && var22 >= var6 && var22 <= var8) {
               byte var23 = 0;
               if (!var25.contains(BlockPos.asLong(var20, var21 - 1, var22))) {
                  var23 |= 1;
               }

               if (!var25.contains(BlockPos.asLong(var20, var21 + 1, var22))) {
                  var23 |= 2;
               }

               if (!var25.contains(BlockPos.asLong(var20, var21, var22 - 1))) {
                  var23 |= 4;
               }

               if (!var25.contains(BlockPos.asLong(var20, var21, var22 + 1))) {
                  var23 |= 8;
               }

               if (!var25.contains(BlockPos.asLong(var20 - 1, var21, var22))) {
                  var23 |= 16;
               }

               if (!var25.contains(BlockPos.asLong(var20 + 1, var21, var22))) {
                  var23 |= 32;
               }

               if (var23 != 0) {
                  int var24 = var27 * 5;
                  var26[var24] = var20;
                  var26[var24 + 1] = var21;
                  var26[var24 + 2] = var22;
                  var26[var24 + 3] = var23;
                  var26[var24 + 4] = var17.getIntValue();
                  var27++;
                  if (var21 < var28) {
                     var28 = var21;
                  }
               }
            }
         }

         if (var27 == 0) {
            return null;
         } else {
            int[] var30 = Arrays.copyOf(var26, var27 * 5);
            return this.HwidGen(var5, var6, var28, var30, var27);
         }
      }
   }

   private LongSet HwidGen(ChunkPos chunkPos, int i) {
      int var3 = i * 2 + 1;
      LongOpenHashSet var4 = new LongOpenHashSet(var3 * var3);

      for (int var5 = chunkPos.x - i; var5 <= chunkPos.x + i; var5++) {
         for (int var6 = chunkPos.z - i; var6 <= chunkPos.z + i; var6++) {
            var4.add(ChunkPos.toLong(var5, var6));
         }
      }

      return var4;
   }

   private int E() {
      return MathHelper.clamp((Integer)this.Module_LightESP.HwidGen(), 1, 12);
   }

   private int F() {
      return MathHelper.clamp((Integer)this.Module_FullBright.HwidGen(), -64, 16);
   }

   private void Module_AutoRender() {
      this.Module_SpotifyHUD.clear();
      this.KeyFile = HwidGen;
      this.LicenseState = null;
      this.HwidGen = null;
      this.Module_SpearSwap = Integer.MIN_VALUE;
      this.Module_Triggerbot = Integer.MIN_VALUE;
      this.c.set(false);
      this.LicenseResult.set(true);
      this.LicenseState.set(false);
      this.Module_f.set(false);
      this.Module_AnchorMacro = 0L;
      this.Module_AutoCrystal = Long.MIN_VALUE;
      this.E = (String)this.Module_ActiveModules.HwidGen();
   }

   private ck HwidGen(int i, int j, int k, int[] is, int l) {
      int var6 = this.HwidGen(is, l);
      short[] var7 = this.HwidGen(is, l, i, j, k, var6);
      int[] var8 = this.HwidGen(is, l, var6);
      return new Obj_ck(i, j, k, is, l, var7, var8, var6);
   }

   private ck HwidGen(ck arg) {
      int[] var2 = this.HwidGen(arg.HwidGen, arg.Toast_ai, arg.Module_BoneDropper);
      return new Obj_ck(
         arg.Module_ActivityFinder, arg.Module_AntiTrap, arg.Module_AutoRender, arg.HwidGen, arg.Toast_ai, arg.HwidGen, var2, arg.Module_BoneDropper
      );
   }

   private int HwidGen(int[] is, int i) {
      int var3 = 0;
      byte var4 = 0;

      for (int var5 = i * 5; var4 < var5; var4 += 5) {
         var3 += Integer.bitCount(is[var4 + 3]);
      }

      return var3;
   }

   private short[] HwidGen(int[] is, int i, int j, int k, int l, int m) {
      short[] var7 = new short[m * 12];
      int var8 = 0;
      byte var9 = 0;

      for (int var10 = i * 5; var9 < var10; var9 += 5) {
         short var11 = (short)(is[var9] - j);
         short var12 = (short)(is[var9 + 1] - l);
         short var13 = (short)(is[var9 + 2] - k);
         short var14 = (short)(var11 + 1);
         short var15 = (short)(var12 + 1);
         short var16 = (short)(var13 + 1);
         int var17 = is[var9 + 3];
         if ((var17 & 1) != 0) {
            this.HwidGen(var7, var8++, var11, var12, var13, var11, var12, var16, var14, var12, var16, var14, var12, var13);
         }

         if ((var17 & 2) != 0) {
            this.HwidGen(var7, var8++, var11, var15, var13, var14, var15, var13, var14, var15, var16, var11, var15, var16);
         }

         if ((var17 & 4) != 0) {
            this.HwidGen(var7, var8++, var11, var12, var13, var14, var12, var13, var14, var15, var13, var11, var15, var13);
         }

         if ((var17 & 8) != 0) {
            this.HwidGen(var7, var8++, var11, var12, var16, var11, var15, var16, var14, var15, var16, var14, var12, var16);
         }

         if ((var17 & 16) != 0) {
            this.HwidGen(var7, var8++, var11, var12, var13, var11, var15, var13, var11, var15, var16, var11, var12, var16);
         }

         if ((var17 & 32) != 0) {
            this.HwidGen(var7, var8++, var14, var12, var13, var14, var12, var16, var14, var15, var16, var14, var15, var13);
         }
      }

      return var7;
   }

   private int[] HwidGen(int[] is, int i, int j) {
      int[] var4 = new int[j];
      int var5 = 0;
      byte var6 = 0;

      for (int var7 = i * 5; var6 < var7; var6 += 5) {
         int var8 = this.Module_f(is[var6 + 4]);
         int var9 = is[var6 + 3];
         int var10 = Integer.bitCount(var9);
         Arrays.fill(var4, var5, var5 + var10, var8);
         var5 += var10;
      }

      return var4;
   }

   private void HwidGen(short[] ss, int i, short s, short t, short u, short v, short w, short x, short y, short z, short aa, short ab, short ac, short ad) {
      int var15 = i * 12;
      ss[var15] = s;
      ss[var15 + 1] = t;
      ss[var15 + 2] = u;
      ss[var15 + 3] = v;
      ss[var15 + 4] = w;
      ss[var15 + 5] = x;
      ss[var15 + 6] = y;
      ss[var15 + 7] = z;
      ss[var15 + 8] = aa;
      ss[var15 + 9] = ab;
      ss[var15 + 10] = ac;
      ss[var15 + 11] = ad;
   }

   private int Module_f(int i) {
      float var2 = MathHelper.clamp(i / 15.0F, 0.0F, 1.0F);
      String var3 = (String)this.Module_ActiveModules.HwidGen();

      return switch (var3) {
         case "Grayscale" -> this.KeyFile(var2);
         case "Ocean" -> this.HwidGen(663373, 2057176, 4908799, var2);
         case "Warm" -> this.c(var2);
         case "Cool" -> this.LicenseResult(var2);
         case "Classic" -> this.HwidGen(var2);
         default -> this.HwidGen(var2);
      };
   }

   private int HwidGen(float f) {
      int var2 = (int)(f * 255.0F);
      int var3 = (int)(50.0F + f * 205.0F);
      int var4 = (int)(200.0F * (1.0F - f));
      return var2 << 16 | var3 << 8 | var4;
   }

   private int KeyFile(float f) {
      int var2 = MathHelper.clamp(Math.round(f * 255.0F), 0, 255);
      return var2 << 16 | var2 << 8 | var2;
   }

   private int c(float f) {
      return this.HwidGen(11540504, 16742938, 16771418, f);
   }

   private int LicenseResult(float f) {
      return this.HwidGen(1195419, 1497343, 16777215, f);
   }

   private int HwidGen(int i, int j, int k, float f) {
      float var5 = MathHelper.clamp(f, 0.0F, 1.0F);
      return var5 <= 0.5F ? this.HwidGen(i, j, var5 * 2.0F) : this.HwidGen(j, k, (var5 - 0.5F) * 2.0F);
   }

   private int HwidGen(int i, int j, float f) {
      float var4 = MathHelper.clamp(f, 0.0F, 1.0F);
      int var5 = i >> 16 & 0xFF;
      int var6 = i >> 8 & 0xFF;
      int var7 = i & 0xFF;
      int var8 = j >> 16 & 0xFF;
      int var9 = j >> 8 & 0xFF;
      int var10 = j & 0xFF;
      int var11 = Math.round(var5 + (var8 - var5) * var4);
      int var12 = Math.round(var6 + (var9 - var6) * var4);
      int var13 = Math.round(var7 + (var10 - var7) * var4);
      return var11 << 16 | var12 << 8 | var13;
   }

   @Override
   public void HwidGen(MatrixStack matrixStack, float f) {
      if (HwidGen.world != null && HwidGen.player != null) {
         ck[] var3 = this.KeyFile;
         if (var3.length != 0) {
            Camera var4 = Render_dm.HwidGen();
            if (var4 != null) {
               Vec3d var5 = Render_dm.HwidGen(var4);
               int var6 = this.LicenseState((Float)this.Module_Freecam.HwidGen()) << 24;
               if (var6 != 0) {
                  double var7 = var5.x;
                  double var9 = var5.y;
                  double var11 = var5.z;
                  BufferAllocator var13 = new BufferAllocator(2097152);
                  Immediate var14 = VertexConsumerProvider.immediate(var13);
                  VertexConsumer var15 = var14.getBuffer(RenderLayers.debugFilledBox());
                  boolean var16 = false;

                  for (ck var20 : var3) {
                     if (var20 != null) {
                        matrixStack.push();
                        matrixStack.translate(var20.Module_ActivityFinder - var7, var20.Module_AutoRender - var9, var20.Module_AntiTrap - var11);
                        net.minecraft.client.util.math.MatrixStack.Entry var21 = matrixStack.peek();
                        short[] var22 = var20.HwidGen;
                        int[] var23 = var20.KeyFile;
                        int var24 = 0;

                        for (byte var25 = 0; var24 < var20.Module_BoneDropper; var25 += 12) {
                           int var26 = var6 | var23[var24];
                           var15.vertex(var21, var22[var25], var22[var25 + 1], var22[var25 + 2]).color(var26);
                           var15.vertex(var21, var22[var25 + 3], var22[var25 + 4], var22[var25 + 5]).color(var26);
                           var15.vertex(var21, var22[var25 + 6], var22[var25 + 7], var22[var25 + 8]).color(var26);
                           var15.vertex(var21, var22[var25 + 9], var22[var25 + 10], var22[var25 + 11]).color(var26);
                           var16 = true;
                           var24++;
                        }

                        matrixStack.pop();
                     }
                  }

                  if (!var16) {
                     var13.close();
                  } else {
                     boolean var27 = GL11.glIsEnabled(2929);
                     boolean var28 = GL11.glIsEnabled(32823);
                     GL11.glDisable(2929);
                     GL11.glDepthMask(false);
                     GL11.glEnable(32823);
                     GL11.glPolygonOffset(-1.0F, -1.0F);
                     var14.draw();
                     GL11.glPolygonOffset(0.0F, 0.0F);
                     if (!var28) {
                        GL11.glDisable(32823);
                     }

                     GL11.glDepthMask(true);
                     if (var27) {
                        GL11.glEnable(2929);
                     }

                     var13.close();
                  }
               }
            }
         }
      }
   }

   private int LicenseState(float f) {
      return MathHelper.clamp(Math.round(f), 0, 255);
   }
}
