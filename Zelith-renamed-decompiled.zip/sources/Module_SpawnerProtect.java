import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.zelith.ZelithClient;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Util;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public final class Module_SpawnerProtect extends Module {
   private static final Duration HwidGen = Duration.ofSeconds(8L);
   private static final DateTimeFormatter HwidGen = DateTimeFormatter.ofPattern("HH:mm:ss", Locale.ROOT);
   private static final HttpClient KeyFile;
   private final dd aU = new Setting("Whitelist", "0Gsummer, w1zox_, archivePedro, DrDonut, pastagamer08, Dough4");
   private final dd aV = new Module_SpawnerProtect$1(this, "Webhook", "");
   private BlockPos Category;
   private boolean A;
   private boolean B;
   private long ClickBuf;
   private int E;

   public Module_SpawnerProtect() {
      super("Spawner Protect", Category.LicenseState);
      this.HwidGen(this.aU);
      this.HwidGen(this.aV);
   }

   @Override
   public void LicenseState() {
      this.O();
      if (!this.Module_Hud()) {
         this.SwapHelper("Need a Silk Touch pickaxe in hotbar");
      }
   }

   @Override
   public void Module_f() {
      this.N();
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.world != null && HwidGen.interactionManager != null) {
         if (!this.A) {
            if (!this.Module_Hud()) {
               this.SwapHelper("Need a Silk Touch pickaxe in hotbar");
            } else {
               if (!this.B) {
                  if (!this.Module_Friends()) {
                     return;
                  }

                  this.B = true;
               }

               if (System.currentTimeMillis() >= this.ClickBuf) {
                  int var1 = this.HudElement();
                  if (var1 == -1) {
                     this.SwapHelper("Need a Silk Touch pickaxe in hotbar");
                  } else {
                     this.Category(var1);
                     this.M();
                     if (this.Category == null || !this.KeyFile(this.Category) || !HwidGen.player.canInteractWithBlockAt(this.Category, 5.0)) {
                        this.Category = this.KeyFile();
                        if (this.Category == null) {
                           this.HwidGen(this.HwidGen());
                           return;
                        }
                     }

                     Direction var2 = this.HwidGen(this.Category);
                     this.HwidGen(this.Category, var2);
                     HwidGen.interactionManager.updateBlockBreakingProgress(this.Category, var2);
                     HwidGen.world.spawnBlockBreakingParticle(this.Category, var2);
                     HwidGen.player.swingHand(Hand.MAIN_HAND);
                     if (!this.KeyFile(this.Category)) {
                        this.E++;
                        this.Category = null;
                        this.ClickBuf = System.currentTimeMillis() + 250L;
                     }
                  }
               }
            }
         }
      }
   }

   private boolean Module_Friends() {
      for (PlayerEntity var2 : HwidGen.world.getPlayers()) {
         if (var2 != HwidGen.player
            && !var2.isSpectator()
            && !var2.isTeammate(HwidGen.player)
            && (!Module_Friends.LicenseState() || !Module_Friends.HwidGen(var2.getName().getString()))
            && !this.KeyFile(var2)
            && Render_de.c(var2.getId())) {
            return true;
         }
      }

      return false;
   }

   private BlockPos KeyFile() {
      ArrayList var1 = new ArrayList();
      BlockPos var2 = HwidGen.player.getBlockPos();
      short var3 = 1024;

      for (int var4 = -32; var4 <= 32; var4++) {
         for (int var5 = -32; var5 <= 32; var5++) {
            for (int var6 = -32; var6 <= 32; var6++) {
               int var7 = var4 * var4 + var5 * var5 + var6 * var6;
               if (var7 <= var3) {
                  BlockPos var8 = var2.add(var4, var5, var6);
                  if (this.KeyFile(var8) && HwidGen.player.canInteractWithBlockAt(var8, 5.0)) {
                     var1.add(var8.toImmutable());
                  }
               }
            }
         }
      }

      return var1.stream().min(Comparator.comparingDouble(this::HwidGen)).orElse(null);
   }

   private boolean Module_Hud() {
      return this.HudElement() != -1;
   }

   private int HudElement() {
      for (int var1 = 0; var1 < 9; var1++) {
         if (this.KeyFile(HwidGen.player.getInventory().getStack(var1))) {
            return var1;
         }
      }

      return -1;
   }

   private boolean KeyFile(ItemStack itemStack) {
      if (itemStack != null && !itemStack.isEmpty()) {
         String var2 = Registries.ITEM.getId(itemStack.getItem()).getPath();
         if (!var2.endsWith("_pickaxe")) {
            return false;
         } else {
            RegistryEntry var3 = HwidGen.world
               .getRegistryManager()
               .getOrThrow(RegistryKeys.ENCHANTMENT)
               .getEntry((Enchantment)HwidGen.world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT).get(Enchantments.SILK_TOUCH));
            return var3 != null && EnchantmentHelper.getLevel(var3, itemStack) > 0;
         }
      } else {
         return false;
      }
   }

   private boolean KeyFile(BlockPos blockPos) {
      return HwidGen.world != null && HwidGen.world.getBlockState(blockPos).isOf(Blocks.SPAWNER);
   }

   private Direction HwidGen(BlockPos blockPos) {
      Vec3d var2 = HwidGen.player.getEyePos().subtract(Vec3d.ofCenter(blockPos));
      return Direction.getFacing(var2.x, var2.y, var2.z);
   }

   private void HwidGen(BlockPos blockPos, Direction direction) {
      Vec3d var3 = HwidGen.player.getEyePos();
      Vec3d var4 = Vec3d.ofCenter(blockPos);
      double var5 = var4.x - var3.x;
      double var7 = var4.y - var3.y;
      double var9 = var4.z - var3.z;
      double var11 = Math.sqrt(var5 * var5 + var9 * var9);
      float var13 = (float)(Math.toDegrees(Math.atan2(var9, var5)) - 90.0);
      float var14 = (float)(-Math.toDegrees(Math.atan2(var7, var11)));
      HwidGen.player.setYaw(var13);
      HwidGen.player.setPitch(var14);
      HwidGen.crosshairTarget = new BlockHitResult(var4, direction, blockPos, false);
   }

   private void Category(int i) {
      if (i >= 0 && i < 9 && HwidGen.player.getInventory().getSelectedSlot() != i) {
         HwidGen.player.getInventory().setSelectedSlot(i);
      }
   }

   private void M() {
      HwidGen.options.sneakKey.setPressed(true);
      HwidGen.player.setSneaking(true);
   }

   private void N() {
      this.Category = null;
      if (HwidGen.interactionManager != null && HwidGen.interactionManager.isBreakingBlock()) {
         HwidGen.interactionManager.cancelBlockBreaking();
      }

      if (HwidGen.player != null) {
         HwidGen.options.sneakKey.setPressed(false);
         HwidGen.player.setSneaking(false);
      }
   }

   private void HwidGen(bd arg) {
      this.N();
      String var2 = this.LicenseState((String)this.aV.HwidGen());
      if (!this.KeyFile(var2)) {
         this.A = false;
         this.SwapHelper(arg.Module_SpotifyHUD());
      } else {
         this.A = true;
         CompletableFuture.runAsync(() -> this.KeyFile(arg), Util.getIoWorkerExecutor().named("coordsnapper-send"))
            .whenComplete((void_, throwable) -> HwidGen.execute(() -> {
               if (throwable != null) {
                  ZelithClient.LOGGER.error("SpawnerProtect webhook failed", throwable);
               }

               this.A = false;
               this.SwapHelper(arg.Module_SpotifyHUD());
            }));
      }
   }

   private bd HwidGen() {
      String var1 = this.LicenseState((String)this.aV.HwidGen());
      return new Rec_bd(
         var1,
         "[SpawnerProtect]",
         "All your spawners have been collected.",
         5624994,
         HwidGen.player.getName().getString(),
         "",
         "",
         this.Module_SpotifyHUD(),
         true,
         this.Category(),
         HwidGen.format(LocalTime.now()),
         "https://mc-heads.net/body/" + this.Module_f(HwidGen.player.getName().getString()),
         "SpawnerProtect finished"
      );
   }

   private void KeyFile(bd arg) {
      JsonObject var2 = new JsonObject();
      var2.addProperty("username", "SpawnerProtect");
      JsonObject var3 = new JsonObject();
      var3.addProperty("title", arg.SwapHelper());
      var3.addProperty("description", arg.Module_j());
      var3.addProperty("color", arg.Module_Themes());
      JsonArray var4 = new JsonArray();
      var4.add(this.HwidGen("Player", arg.Module_ActiveModules(), false));
      var4.add(this.HwidGen("Time", arg.Module_Hud(), true));
      var4.add(this.HwidGen("Server", arg.Module_Friends(), true));
      var4.add(this.HwidGen("All spawners mined", arg.HudElement() ? "✅ Yes" : "❌ No", false));
      var4.add(this.HwidGen("Spawners in bag", arg.Module_WaterMark() + " spawners", false));
      if (!arg.ClickBuf().isBlank()) {
         var4.add(this.HwidGen("Threat", arg.ClickBuf() + " (" + arg.Module_Configs() + " blocks)", false));
      }

      var3.add("fields", var4);
      JsonObject var5 = new JsonObject();
      var5.addProperty("url", arg.HudElement());
      var3.add("thumbnail", var5);
      JsonArray var6 = new JsonArray();
      var6.add(var3);
      var2.add("embeds", var6);
      HttpRequest var7 = HttpRequest.newBuilder(this.HwidGen(arg.Module()))
         .timeout(HwidGen)
         .header("Content-Type", "application/json")
         .header("Accept", "application/json")
         .header("User-Agent", "zelith-CoordSnapper")
         .POST(BodyPublishers.ofString(var2.toString()))
         .build();

      HttpResponse var8;
      try {
         var8 = KeyFile.send(var7, BodyHandlers.ofString());
      } catch (Exception var11) {
         ZelithClient.LOGGER.error("SpawnerProtect webhook request failed", (Throwable)var11);
         throw new IllegalStateException("Webhook request failed", var11);
      }

      int var9 = var8.statusCode();
      if (var9 >= 200 && var9 < 300) {
         ZelithClient.LOGGER.info("SpawnerProtect webhook sent");
      } else {
         String var10 = (String)var8.body();
         if (var10 != null && !var10.isBlank()) {
            ZelithClient.LOGGER.warn("SpawnerProtect webhook rejected with status {} and body {}", var9, this.KeyFile(var10, 240));
            throw new IllegalStateException("HTTP " + var9 + ": " + this.KeyFile(var10, 120));
         } else {
            ZelithClient.LOGGER.warn("SpawnerProtect webhook rejected with status {}", var9);
            throw new IllegalStateException("HTTP " + var9);
         }
      }
   }

   private JsonObject HwidGen(String string, String string2, boolean bl) {
      JsonObject var4 = new JsonObject();
      var4.addProperty("name", string);
      var4.addProperty("value", string2 != null && !string2.isBlank() ? string2 : "-");
      var4.addProperty("inline", bl);
      return var4;
   }

   private String Category() {
      ServerInfo var1 = HwidGen.getCurrentServerEntry();
      if (var1 != null && var1.address != null && !var1.address.isBlank()) {
         String var2 = this.LicenseResult(var1.address);
         return var2.isEmpty() ? "Singleplayer" : var2;
      } else {
         return "Singleplayer";
      }
   }

   private String LicenseResult(String string) {
      String var2 = string == null ? "" : string.trim().toLowerCase(Locale.ROOT);
      int var3 = var2.indexOf(47);
      if (var3 >= 0) {
         var2 = var2.substring(0, var3);
      }

      int var4 = var2.indexOf(58);
      if (var4 >= 0) {
         var2 = var2.substring(0, var4);
      }

      return var2;
   }

   private String LicenseState(String string) {
      return string == null ? "" : string.trim();
   }

   private String Module_f(String string) {
      return string != null && !string.isBlank() ? string.trim() : "Steve";
   }

   private URI HwidGen(String string) {
      URI var2 = URI.create(string);
      String var3 = var2.getQuery();
      if (var3 == null || var3.isBlank()) {
         return URI.create(string + "?wait=true");
      } else {
         return var3.contains("wait=") ? var2 : URI.create(string + "&wait=true");
      }
   }

   private boolean KeyFile(String string) {
      if (string.isEmpty()) {
         return false;
      } else {
         try {
            URI var2 = URI.create(string);
            String var3 = var2.getScheme();
            String var4 = var2.getHost();
            String var5 = var2.getPath();
            return ("https".equalsIgnoreCase(var3) || "http".equalsIgnoreCase(var3))
               && var4 != null
               && !var4.isBlank()
               && var5 != null
               && var5.contains("/api/webhooks/");
         } catch (Exception var6) {
            return false;
         }
      }
   }

   private String KeyFile(String string, int i) {
      if (string == null) {
         return "";
      } else {
         String var3 = string.replace('\n', ' ').replace('\r', ' ').trim();
         return var3.length() <= i ? var3 : var3.substring(0, Math.max(0, i - 3)) + "...";
      }
   }

   private int Module_SpotifyHUD() {
      int var1 = 0;

      for (int var2 = 0; var2 < HwidGen.player.getInventory().size(); var2++) {
         ItemStack var3 = HwidGen.player.getInventory().getStack(var2);
         if (!var3.isEmpty() && var3.isOf(Blocks.SPAWNER.asItem())) {
            var1 += var3.getCount();
         }
      }

      return var1;
   }

   private void SwapHelper(String string) {
      if (HwidGen.getNetworkHandler() != null && HwidGen.getNetworkHandler().getConnection() != null) {
         HwidGen.getNetworkHandler().getConnection().disconnect(Text.literal(string));
      }

      this.HwidGen(false);
   }

   private double HwidGen(BlockPos blockPos) {
      return HwidGen.player.squaredDistanceTo(Vec3d.ofCenter(blockPos));
   }

   private void O() {
      this.Category = null;
      this.A = false;
      this.B = false;
      this.ClickBuf = 0L;
      this.E = 0;
   }

   private boolean KeyFile(PlayerEntity playerEntity) {
      String var2 = (String)this.aU.HwidGen();
      if (var2 != null && !var2.isBlank()) {
         String var3 = playerEntity.getName().getString();
         return Arrays.stream(var2.split("[,; ]+")).map(String::trim).filter(string -> !string.isEmpty()).anyMatch(string2 -> string2.equalsIgnoreCase(var3));
      } else {
         return false;
      }
   }

   static {
      KeyFile = HttpClient.newBuilder().connectTimeout(HwidGen).followRedirects(Redirect.NORMAL).build();
   }
}
