import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

public final class Module_StashFinder extends Module {
   private static final Set Category = Set.of(
      Blocks.CHEST,
      Blocks.TRAPPED_CHEST,
      Blocks.BARREL,
      Blocks.SHULKER_BOX,
      Blocks.WHITE_SHULKER_BOX,
      Blocks.ORANGE_SHULKER_BOX,
      Blocks.MAGENTA_SHULKER_BOX,
      Blocks.LIGHT_BLUE_SHULKER_BOX,
      Blocks.YELLOW_SHULKER_BOX,
      Blocks.LIME_SHULKER_BOX,
      Blocks.PINK_SHULKER_BOX,
      Blocks.GRAY_SHULKER_BOX,
      Blocks.LIGHT_GRAY_SHULKER_BOX,
      Blocks.CYAN_SHULKER_BOX,
      Blocks.PURPLE_SHULKER_BOX,
      Blocks.BLUE_SHULKER_BOX,
      Blocks.BROWN_SHULKER_BOX,
      Blocks.GREEN_SHULKER_BOX,
      Blocks.RED_SHULKER_BOX,
      Blocks.BLACK_SHULKER_BOX
   );
   private final dd aW = new Setting("Threshold", 10, 1, 100);
   private final Set Module = ConcurrentHashMap.newKeySet();
   private final Set SwapHelper = ConcurrentHashMap.newKeySet();
   private int Module_Themes;

   public Module_StashFinder() {
      super("Stash Finder", Category.LicenseState);
      this.HwidGen(this.aW);
   }

   @Override
   public void LicenseState() {
      this.F();
   }

   @Override
   public void Module_f() {
      this.F();
   }

   @Override
   public void Category() {
      if (HwidGen.world != null && HwidGen.player != null) {
         int var1 = HwidGen.options.getClampedViewDistance();
         ChunkPos var2 = HwidGen.player.getChunkPos();
         int var3 = var1 * 2 + 1;
         int var4 = var3 * var3;
         int var5 = (Integer)this.aW.HwidGen();

         for (int var6 = 0; var6 < 8; var6++) {
            int var7 = this.Module_Themes % var4;
            this.Module_Themes = (this.Module_Themes + 1) % var4;
            int var8 = var7 % var3 - var1;
            int var9 = var7 / var3 - var1;
            int var10 = var2.x + var8;
            int var11 = var2.z + var9;
            WorldChunk var12 = HwidGen.world.getChunkManager().getWorldChunk(var10, var11, false);
            if (var12 != null && !var12.isEmpty()) {
               ChunkPos var13 = new ChunkPos(var10, var11);
               int var14 = this.HwidGen(var12);
               if (var14 >= var5) {
                  this.Module.add(var13);
                  if (this.SwapHelper.add(var13)) {
                     this.KeyFile(var13, var14);
                     this.P();
                  }
               } else {
                  this.Module.remove(var13);
               }
            }
         }

         this.Module.removeIf(chunkPos2 -> this.HwidGen(chunkPos2, var2, var1));
      }
   }

   private int HwidGen(WorldChunk worldChunk) {
      int var2 = 0;

      for (ChunkSection var6 : worldChunk.getSectionArray()) {
         if (var6 != null && !var6.isEmpty() && var6.hasAny(blockState -> Category.contains(blockState.getBlock()))) {
            for (int var7 = 0; var7 < 16; var7++) {
               for (int var8 = 0; var8 < 16; var8++) {
                  for (int var9 = 0; var9 < 16; var9++) {
                     BlockState var10 = var6.getBlockState(var7, var8, var9);
                     if (Category.contains(var10.getBlock())) {
                        var2++;
                     }
                  }
               }
            }
         }
      }

      return var2;
   }

   private boolean HwidGen(ChunkPos chunkPos, ChunkPos chunkPos2, int i) {
      return Math.abs(chunkPos.x - chunkPos2.x) > i || Math.abs(chunkPos.z - chunkPos2.z) > i;
   }

   private void KeyFile(ChunkPos chunkPos, int i) {
      if (HwidGen.getToastManager() != null) {
         HwidGen.getToastManager()
            .add(
               new Toast_bf(
                  Text.literal("StashFinder"),
                  Text.literal(i + " chests at X:" + chunkPos.getCenterX() + " Z:" + chunkPos.getCenterZ()),
                  new ItemStack(Items.CHEST)
               )
            );
      }
   }

   private void P() {
      if (HwidGen.player != null) {
         HwidGen.player.playSound((SoundEvent)SoundEvents.BLOCK_NOTE_BLOCK_CHIME.value(), 1.0F, 1.0F);
      }
   }

   private void F() {
      this.Module.clear();
      this.SwapHelper.clear();
      this.Module_Themes = 0;
   }
}
