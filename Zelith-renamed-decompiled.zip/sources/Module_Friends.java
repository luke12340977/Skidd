import java.awt.Color;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

public final class Module_Friends extends Module {
   private static n HwidGen;
   private final dd HwidGen = new Setting("Names", "");
   private final dd KeyFile = new Setting("Anti Triggerbot", true);
   private final dd c = new Setting("ESP Color", true);
   private final dd LicenseResult = new Setting("Auto Log", true);
   private final dd LicenseState = new Setting("Spawner Protect", true);
   private final dd Module_f = new Setting("Friend Color", new Color(0, 200, 255));

   public Module_Friends() {
      super("Friends", Category.Module_f);
      this.HwidGen(this.HwidGen);
      this.HwidGen(this.KeyFile);
      this.HwidGen(this.c);
      this.HwidGen(this.LicenseResult);
      this.HwidGen(this.LicenseState);
      this.HwidGen(this.Module_f);
      HwidGen = this;
   }

   public static boolean HwidGen(String string) {
      if (HwidGen != null && HwidGen.HwidGen() && string != null && !string.isEmpty()) {
         String var1 = string.trim().toLowerCase(Locale.ROOT);

         for (String var3 : HwidGen((String)HwidGen.HwidGen.HwidGen())) {
            if (var3.equalsIgnoreCase(var1)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static boolean KeyFile() {
      return HwidGen != null && (Boolean)HwidGen.KeyFile.HwidGen();
   }

   public static boolean c() {
      return HwidGen != null && (Boolean)HwidGen.c.HwidGen();
   }

   public static boolean LicenseResult() {
      return HwidGen != null && (Boolean)HwidGen.LicenseResult.HwidGen();
   }

   public static boolean LicenseState() {
      return HwidGen != null && (Boolean)HwidGen.LicenseState.HwidGen();
   }

   public static Color HwidGen() {
      if (HwidGen == null) {
         return new Color(0, 200, 255);
      } else {
         Color var0 = (Color)HwidGen.Module_f.HwidGen();
         if (var0 == null) {
            return new Color(0, 200, 255);
         } else {
            return var0.getAlpha() == 0 ? new Color(var0.getRed(), var0.getGreen(), var0.getBlue(), 255) : var0;
         }
      }
   }

   private static List HwidGen(String string) {
      if (string != null && !string.isBlank()) {
         String var1 = string.replace('\n', ',').replace('\r', ',');
         LinkedHashSet var2 = new LinkedHashSet();

         for (String var6 : var1.split(",")) {
            String var7 = var6 == null ? "" : var6.trim();
            if (!var7.isEmpty()) {
               var2.add(var7.toLowerCase(Locale.ROOT));
            }
         }

         return new ArrayList(var2);
      } else {
         return List.of();
      }
   }
}
