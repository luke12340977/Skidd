import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;

public final class Module_SpearSwap extends Module {
   public static ad HwidGen;
   private final dd S = new Setting("Lunge", true);
   private final dd T = new Setting("Sharpness", false);
   private final dd U = new Setting("Only Sword", false);
   private final dd V = new Setting("Only Axe", false);
   private final dd W = new Setting("Switch Back", true);
   private final dd X = new Setting("Switch Delay", 1.0F, 1.0F, 20.0F);
   private int Module_j = -1;
   private int Module_Hud = 0;
   private boolean Module_Themes = false;

   public Module_SpearSwap() {
      super("Spear Swap", Category.c);
      this.HwidGen(this.S);
      this.HwidGen(this.T);
      this.HwidGen(this.U);
      this.HwidGen(this.V);
      this.HwidGen(this.W);
      this.HwidGen(this.X);
      HwidGen = this;
   }

   public void Module_AutoDoubleHand() {
      if (HwidGen.player != null) {
         boolean var1 = this.Module_Themes;
         this.Module_Themes = true;
         if (!var1) {
            if (this.Module_Hud <= 0) {
               PlayerInventory var2 = HwidGen.player.getInventory();
               int var3 = this.ClickBuf();
               if (var3 >= 0) {
                  if (var2.getSelectedSlot() != var3) {
                     this.Module_j = var2.getSelectedSlot();
                     var2.setSelectedSlot(var3);
                     this.Module_Hud = Math.max(1, ((Float)this.X.HwidGen()).intValue());
                  }
               }
            }
         }
      }
   }

   public void Module_AutoInvTotem() {
      this.Module_Themes = false;
   }

   @Override
   public void LicenseState() {
      this.Module_j = -1;
      this.Module_Hud = 0;
   }

   @Override
   public void Module_f() {
      this.Module_j = -1;
      this.Module_Hud = 0;
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.options != null) {
         PlayerInventory var1 = HwidGen.player.getInventory();
         if (this.Module_Hud > 0) {
            this.Module_Hud--;
            if (this.Module_Hud == 0) {
               if ((Boolean)this.W.HwidGen() && this.Module_j >= 0 && this.Module_j < 9 && var1.getSelectedSlot() != this.Module_j) {
                  var1.setSelectedSlot(this.Module_j);
               }

               this.Module_j = -1;
            }
         }

         if (HwidGen.options.attackKey.isPressed()) {
            this.Module_AutoDoubleHand();
         } else {
            this.Module_AutoInvTotem();
         }
      }
   }

   private int ClickBuf() {
      PlayerInventory var1 = HwidGen.player.getInventory();
      boolean var2 = (Boolean)this.U.HwidGen();
      boolean var3 = (Boolean)this.V.HwidGen();
      boolean var4 = (Boolean)this.S.HwidGen();
      boolean var5 = (Boolean)this.T.HwidGen();
      int var6 = -1;
      int var7 = Integer.MIN_VALUE;

      for (int var8 = 0; var8 < 9; var8++) {
         ItemStack var9 = var1.getStack(var8);
         if (!var9.isEmpty()) {
            String var10 = Registries.ITEM.getId(var9.getItem()).getPath();
            String var11 = "";

            try {
               var11 = var9.getName().getString().toLowerCase();
            } catch (Throwable var18) {
            }

            boolean var12 = var10.endsWith("_sword");
            boolean var13 = var9.getItem() instanceof AxeItem;
            boolean var14 = var9.getItem() == Items.TRIDENT || var9.getItem() == Items.MACE || var10.contains("spear") || var11.contains("spear");
            boolean var15 = this.HwidGen(var9);
            boolean var16 = var4 && var15;
            if ((!var2 || var12) && (!var3 || var13) && (var2 || var3 || var12 || var13 || var14 || var16)) {
               int var17 = 0;
               if (var16) {
                  var17 += 500;
               }

               if (var14) {
                  var17 += 300;
               } else if (var12) {
                  var17 += 200;
               } else if (var13) {
                  var17 += 100;
               }

               if (var5) {
                  var17 += this.KeyFile(var9) * 60;
               }

               if (var17 > var7) {
                  var7 = var17;
                  var6 = var8;
               }
            }
         }
      }

      return var6;
   }

   private boolean HwidGen(ItemStack itemStack) {
      try {
         ItemEnchantmentsComponent var2 = (ItemEnchantmentsComponent)itemStack.get(DataComponentTypes.ENCHANTMENTS);
         if (var2 == null) {
            return false;
         }

         for (RegistryEntry var4 : var2.getEnchantments()) {
            RegistryKey var5 = (RegistryKey)var4.getKey().orElse(null);
            if (var5 != null) {
               if (var5.equals(Enchantments.WIND_BURST) || var5.equals(Enchantments.DENSITY) || var5.equals(Enchantments.RIPTIDE)) {
                  return true;
               }

               String var6 = var5.getValue().toString().toLowerCase();
               if (var6.contains("lunge")) {
                  return true;
               }
            }
         }
      } catch (Throwable var7) {
      }

      return false;
   }

   private int KeyFile(ItemStack itemStack) {
      try {
         ItemEnchantmentsComponent var2 = (ItemEnchantmentsComponent)itemStack.get(DataComponentTypes.ENCHANTMENTS);
         if (var2 == null) {
            return 0;
         }

         for (RegistryEntry var4 : var2.getEnchantments()) {
            RegistryKey var5 = (RegistryKey)var4.getKey().orElse(null);
            if (var5 != null && var5.equals(Enchantments.SHARPNESS)) {
               return var2.getLevel(var4);
            }
         }
      } catch (Throwable var6) {
      }

      return 0;
   }
}
