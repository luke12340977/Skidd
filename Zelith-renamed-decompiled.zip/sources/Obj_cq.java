import java.awt.Color;

final class Obj_cq {
   final double SwapHelper;
   final double Module_j;
   final double Module_ActiveModules;
   final double ClickBuf;
   final double Module_Configs;
   final double Module_Friends;
   final Color Module;
   final Color SwapHelper;
   final boolean Q;

   Obj_cq(double d, double e, double f, double g, double h, double i, Color color, Color color2, boolean bl) {
      this.SwapHelper = d;
      this.Module_j = e;
      this.Module_ActiveModules = f;
      this.ClickBuf = g;
      this.Module_Configs = h;
      this.Module_Friends = i;
      this.Module = color;
      this.SwapHelper = color2;
      this.Q = bl;
   }
}
