import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.scoreboard.ScoreAccess;
import net.minecraft.scoreboard.ScoreHolder;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardCriterion;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.ScoreboardCriterion.RenderType;
import net.minecraft.scoreboard.number.BlankNumberFormat;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;

public final class Module_FakeScoreboard extends Module {
   private ScoreboardObjective HwidGen;
   private ScoreboardObjective KeyFile;
   private final List c = new ArrayList();
   private static as HwidGen;
   private long Module_j = 0L;
   private int Module_AnchorMacro = 0;
   private int Module_AutoCrystal = 1;
   private long Module_ActiveModules = 0L;
   private Object HwidGen;
   private final dd Rec_au = new Setting("Title", "Zelith");
   private final dd Obj_av = new Setting("Money", "2B");
   private final dd Rec_aw = new Setting("Shards", "780");
   private final dd Obj_ax = new Setting("Kills", "230");
   private final dd Rec_ay = new Setting("Deaths", "160");
   private final dd Module_PaperRig = new Setting("Playtime", "21d 5h");

   public Module_FakeScoreboard() {
      super("Fake Scoreboard", Category.LicenseState);
      HwidGen = this;
      this.HwidGen(this.Rec_au);
      this.HwidGen(this.Obj_av);
      this.HwidGen(this.Rec_aw);
      this.HwidGen(this.Obj_ax);
      this.HwidGen(this.Rec_ay);
      this.HwidGen(this.Module_PaperRig);
   }

   public static as HwidGen() {
      return HwidGen;
   }

   public void HwidGen(long l) {
      try {
         String var3 = (String)this.Obj_av.HwidGen();
         long var4 = this.c(var3);
         long var6 = var4 - l;
         if (var6 < 0L) {
            var6 = 0L;
         }

         String var8 = this.LicenseResult(var6);
         this.Obj_av.HwidGen(var8);
         this.H();
      } catch (Exception var9) {
         var9.printStackTrace();
      }
   }

   public void KeyFile(long l) {
      try {
         String var3 = (String)this.Obj_av.HwidGen();
         long var4 = this.c(var3);
         long var6 = var4 + l;
         String var8 = this.LicenseResult(var6);
         this.Obj_av.HwidGen(var8);
         this.H();
      } catch (Exception var9) {
         var9.printStackTrace();
      }
   }

   private long c(String string) {
      string = string.toLowerCase().trim();

      try {
         if (string.endsWith("Module_ActiveModules")) {
            return (long)(Double.parseDouble(string.substring(0, string.length() - 1)) * 1000.0);
         } else if (string.endsWith("Module_Configs")) {
            return (long)(Double.parseDouble(string.substring(0, string.length() - 1)) * 1000000.0);
         } else if (string.endsWith("KeyFile")) {
            return (long)(Double.parseDouble(string.substring(0, string.length() - 1)) * 1.0E9);
         } else {
            return string.endsWith("Module_zelith") ? (long)(Double.parseDouble(string.substring(0, string.length() - 1)) * 1.0E12) : Long.parseLong(string);
         }
      } catch (NumberFormatException var3) {
         return 0L;
      }
   }

   private String LicenseResult(long l) {
      if (l >= 1000000000000L) {
         double var7 = l / 1.0E12;
         return this.HwidGen(var7, "T");
      } else if (l >= 1000000000L) {
         double var6 = l / 1.0E9;
         return this.HwidGen(var6, "B");
      } else if (l >= 1000000L) {
         double var5 = l / 1000000.0;
         return this.HwidGen(var5, "M");
      } else if (l >= 1000L) {
         double var3 = l / 1000.0;
         return this.HwidGen(var3, "K");
      } else {
         return String.valueOf(l);
      }
   }

   private String HwidGen(double d, String string) {
      String var4 = String.format(Locale.US, "%.2f", d).replaceAll("0+$", "").replaceAll("\\.$", "");
      if (var4.endsWith(".0")) {
         var4 = var4.substring(0, var4.length() - 2);
      }

      return var4 + string;
   }

   private void H() {
      try {
         if (this.HwidGen() && HwidGen.world != null && HwidGen.player != null) {
            this.I();
         }
      } catch (Exception var2) {
         var2.printStackTrace();
      }
   }

   @Override
   public void LicenseState() {
      if (HwidGen.world != null && HwidGen.player != null) {
         this.HwidGen = HwidGen.world;
         Scoreboard var1 = HwidGen.world.getScoreboard();
         this.KeyFile = var1.getObjectiveForSlot(ScoreboardDisplaySlot.SIDEBAR);
         this.Module_j = System.currentTimeMillis();
         this.Module_AnchorMacro = 50 + (int)(Math.random() * 50.0);
         this.Module_AutoCrystal = Math.random() < 0.5 ? 1 : -1;
         this.I();
      }
   }

   @Override
   public void Module_f() {
      if (HwidGen.world != null) {
         try {
            Scoreboard var1 = HwidGen.world.getScoreboard();
            this.HwidGen(var1);
            if (this.HwidGen != null) {
               try {
                  var1.removeObjective(this.HwidGen);
               } catch (Exception var4) {
               }

               this.HwidGen = null;
            }

            if (this.KeyFile != null) {
               try {
                  var1.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, this.KeyFile);
               } catch (Exception var3) {
                  var1.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, null);
               }
            } else {
               var1.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, null);
            }

            this.KeyFile = null;
         } catch (Exception var5) {
         }

         this.HwidGen = null;
      }
   }

   @Override
   public void HwidGen(Packet packet) {
      if (packet instanceof GameMessageS2CPacket var2) {
         String var3 = var2.content().getString().replaceAll("§[0-9a-fklmnor]", "");
         Pattern var4 = Pattern.compile("(\\$?[0-9,.'\\.]+(k|m|b|t)?)", 2);
         Matcher var5 = var4.matcher(var3);
         String var6 = var3.toLowerCase();
         boolean var7 = var6.contains("sent you")
            || var6.contains("you received")
            || var6.contains("has been added")
            || var6.contains("payment received")
            || var6.contains("paid you")
            || var6.contains("received a payment");
         if (var7 && var5.find()) {
            String var8 = var5.group(1).replaceAll("[$,]", "").trim();

            try {
               long var9 = this.c(var8);
               if (var9 > 0L) {
                  this.KeyFile(var9);
               }
            } catch (Exception var11) {
            }
         }
      }
   }

   @Override
   public void Category() {
      try {
         if (!this.HwidGen() || HwidGen.world == null || HwidGen.player == null) {
            return;
         }

         if (HwidGen.world != this.HwidGen) {
            this.HwidGen = HwidGen.world;
            this.LicenseState();
            return;
         }

         long var1 = System.currentTimeMillis();
         if (var1 - this.Module_ActiveModules >= 1000L) {
            this.I();
            this.Module_ActiveModules = var1;
         }
      } catch (Exception var3) {
         var3.printStackTrace();
      }
   }

   private void HwidGen(Scoreboard scoreboard) {
      for (String var3 : this.c) {
         try {
            Team var4 = scoreboard.getTeam(var3);
            if (var4 != null) {
               scoreboard.removeTeam(var4);
            }
         } catch (Exception var5) {
         }
      }

      this.c.clear();
   }

   private void I() {
      try {
         if (HwidGen.world == null || HwidGen.player == null) {
            return;
         }

         Scoreboard var1 = HwidGen.world.getScoreboard();
         if (this.HwidGen == null) {
            this.HwidGen = var1.addObjective(
               "zelith_custom", ScoreboardCriterion.DUMMY, this.HwidGen((String)this.Rec_au.HwidGen()), RenderType.INTEGER, false, BlankNumberFormat.INSTANCE
            );
         } else {
            this.HwidGen.setDisplayName(this.HwidGen((String)this.Rec_au.HwidGen()));
         }

         var1.setObjectiveSlot(ScoreboardDisplaySlot.SIDEBAR, this.HwidGen);
         List var2 = this.LicenseResult();

         for (int var3 = 0; var3 < var2.size(); var3++) {
            String var4 = "zelith_team_" + var3;
            if (!this.c.contains(var4)) {
               this.c.add(var4);
            }

            Team var5 = var1.getTeam(var4);
            if (var5 == null) {
               var5 = var1.addTeam(var4);
            }

            var5.setPrefix((Text)var2.get(var3));
            String var6 = "§" + Integer.toHexString(var3);
            ScoreHolder var7 = ScoreHolder.fromName(var6);
            ScoreAccess var8 = var1.getOrCreateScore(var7, this.HwidGen);
            var8.setScore(var2.size() - var3);
            var1.addScoreHolderToTeam(var6, var5);
         }
      } catch (Exception var9) {
         var9.printStackTrace();
      }
   }

   private List LicenseResult() {
      return List.of(
         this.HwidGen("$ ", 65280).append(this.HwidGen((String)this.Obj_av.HwidGen(), 16777215)),
         this.HwidGen("★ ", 10814460).append(this.HwidGen((String)this.Rec_aw.HwidGen(), 16777215)),
         this.HwidGen("\ud83d\udde1 ", 16711680).append(this.HwidGen((String)this.Obj_ax.HwidGen(), 16777215)),
         this.HwidGen("☠ ", 16545539).append(this.HwidGen((String)this.Rec_ay.HwidGen(), 16777215)),
         this.HwidGen("⌚ ", 16770560).append(this.HwidGen((String)this.Module_PaperRig.HwidGen(), 16777215))
      );
   }

   private MutableText HwidGen(String string, int i) {
      return Text.literal(string).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(i)));
   }

   private MutableText HwidGen(String string) {
      if (string == null || string.isBlank()) {
         string = "Zelith";
      }

      return Text.literal(string).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(16777215)));
   }
}
