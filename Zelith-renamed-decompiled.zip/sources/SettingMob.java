import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

public final class SettingMob extends Setting {
   private final List Module_j = Registries.ENTITY_TYPE
      .stream()
      .filter(SettingMob::KeyFile)
      .sorted(Comparator.comparing(this::HwidGen, String.CASE_INSENSITIVE_ORDER))
      .toList();
   private long Module_AutoDoubleHand;

   public SettingMob(String string, EntityType... entityTypes) {
      super(string, HwidGen(entityTypes));
   }

   private static boolean KeyFile(EntityType entityType) {
      SpawnGroup var1 = entityType.getSpawnGroup();
      return var1 == SpawnGroup.MONSTER
         || var1 == SpawnGroup.CREATURE
         || var1 == SpawnGroup.AMBIENT
         || var1 == SpawnGroup.AXOLOTLS
         || var1 == SpawnGroup.UNDERGROUND_WATER_CREATURE
         || var1 == SpawnGroup.WATER_CREATURE
         || var1 == SpawnGroup.WATER_AMBIENT;
   }

   public void LicenseResult(Set set) {
      LinkedHashSet var2 = new LinkedHashSet();
      if (set != null) {
         for (EntityType var4 : set) {
            if (var4 != null) {
               var2.add(var4);
            }
         }
      }

      super.HwidGen(var2);
      this.Module_AutoDoubleHand++;
   }

   public boolean c(EntityType entityType) {
      return entityType != null && ((Set)this.HwidGen()).contains(entityType);
   }

   public void HwidGen(EntityType entityType) {
      if (entityType != null) {
         LinkedHashSet var2 = new LinkedHashSet((Collection)this.HwidGen());
         if (!var2.add(entityType)) {
            var2.remove(entityType);
         }

         this.LicenseResult(var2);
      }
   }

   public Set c() {
      return Collections.unmodifiableSet((Set)this.HwidGen());
   }

   public List KeyFile(String string) {
      String var2 = string == null ? "" : string.trim().toLowerCase(Locale.ROOT);
      if (var2.isEmpty()) {
         return this.Module_j;
      } else {
         ArrayList var3 = new ArrayList();

         for (EntityType var5 : this.Module_j) {
            String var6 = this.HwidGen(var5).toLowerCase(Locale.ROOT);
            Identifier var7 = Registries.ENTITY_TYPE.getId(var5);
            String var8 = var7 == null ? "" : var7.toString().toLowerCase(Locale.ROOT);
            if (var6.contains(var2) || var8.contains(var2)) {
               var3.add(var5);
            }
         }

         return var3;
      }
   }

   public String HwidGen(EntityType entityType) {
      try {
         return entityType.getName().getString();
      } catch (Exception var4) {
         Identifier var3 = Registries.ENTITY_TYPE.getId(entityType);
         return var3 == null ? "Mob" : var3.getPath();
      }
   }

   public String Module_AutoCrystal() {
      if (((Set)this.HwidGen()).isEmpty()) {
         return "None";
      } else {
         EntityType var1 = (EntityType)((Set)this.HwidGen()).iterator().next();
         String var2 = this.HwidGen(var1);
         int var3 = ((Set)this.HwidGen()).size() - 1;
         return var3 > 0 ? var2 + " +" + var3 : var2;
      }
   }

   private static Set HwidGen(EntityType... entityTypes) {
      LinkedHashSet var1 = new LinkedHashSet();
      if (entityTypes != null) {
         Collections.addAll(var1, entityTypes);
         var1.remove(null);
      }

      return var1;
   }
}
