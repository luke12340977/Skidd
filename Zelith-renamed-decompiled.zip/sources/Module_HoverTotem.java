import com.zelith.mixin.HandledScreenAccessor;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

public final class Module_HoverTotem extends Module {
   private int Module_Friends = -1;

   public Module_HoverTotem() {
      super("Hover Totem", Category.c);
   }

   @Override
   public void Module_f() {
      this.Module_Friends = -1;
      super.Module_f();
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.interactionManager != null) {
         if (HwidGen.currentScreen instanceof HandledScreen var1) {
            Slot var4 = ((HandledScreenAccessor)var1).zelith$getFocusedSlot();
            if (var4 != null && !var4.getStack().isEmpty()) {
               if (!var4.getStack().isOf(Items.TOTEM_OF_UNDYING)) {
                  this.Module_Friends = -1;
               } else if (!HwidGen.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                  if (var4.id != this.Module_Friends) {
                     int var3 = HwidGen.player.currentScreenHandler.syncId;
                     HwidGen.interactionManager.clickSlot(var3, var4.id, 40, SlotActionType.SWAP, HwidGen.player);
                     this.Module_Friends = var4.id;
                  }
               }
            } else {
               this.Module_Friends = -1;
            }
         } else {
            this.Module_Friends = -1;
         }
      }
   }
}
