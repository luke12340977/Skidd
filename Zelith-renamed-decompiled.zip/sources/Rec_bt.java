import java.util.List;
import net.minecraft.text.Text;

record Rec_bt() {
   private final long Module_SpotifyHUD;
   private final Text Category;
   private final int R;
   private final bu HwidGen;
   private final List Category;
   private final int S;

   Rec_bt(long l, Text text, int i, bu arg, List list, int j) {
      this.Module_SpotifyHUD = l;
      this.Category = text;
      this.R = i;
      this.HwidGen = arg;
      this.Category = list;
      this.S = j;
   }

   boolean C() {
      return this.Category == null && this.HwidGen == null && this.Category.isEmpty();
   }

   public long KeyFile() {
      return this.Module_SpotifyHUD;
   }

   public Text HwidGen() {
      return this.Category;
   }

   public int Module_AutoInvTotem() {
      return this.R;
   }

   public List LicenseState() {
      return this.Category;
   }

   public int Module_AutoTotem() {
      return this.S;
   }
}
