import com.mojang.blaze3d.systems.RenderPass;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.util.Window;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix4f;

public class Obj_dr {
   private static final List Module_Hud = new ArrayList();
   private static boolean Y = false;
   private static int Enum_ak;
   private static int Enum_al;
   private static int Module_ChunkFinder;
   private static int Toast_an;

   public static Matrix4f HwidGen(DrawContext drawContext) {
      Window var1 = MinecraftClient.getInstance().getWindow();
      Matrix3x2fStack var2 = drawContext.getMatrices();
      return new Matrix4f()
         .ortho(0.0F, var1.getScaledWidth(), var1.getScaledHeight(), 0.0F, -1000.0F, 1000.0F)
         .mul(new Matrix4f(var2.m00, var2.m01, 0.0F, 0.0F, var2.m10, var2.m11, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, var2.m20, var2.m21, 0.0F, 1.0F));
   }

   public static Matrix4f HwidGen(float f, float g) {
      return new Matrix4f().ortho(0.0F, f, g, 0.0F, -1000.0F, 1000.0F);
   }

   public static int G() {
      Window var0 = MinecraftClient.getInstance().getWindow();
      return Math.round(var0.getWidth() / 2.0F);
   }

   public static int H() {
      Window var0 = MinecraftClient.getInstance().getWindow();
      return Math.round(var0.getHeight() / 2.0F);
   }

   public static float Module_ActiveModules() {
      Window var0 = MinecraftClient.getInstance().getWindow();
      return 2.0F / var0.getScaleFactor();
   }

   public static int Category(int i) {
      Window var1 = MinecraftClient.getInstance().getWindow();
      float var2 = (float)var1.getScaledWidth() / G();
      return Math.round(i * var2);
   }

   public static int Module(int i) {
      Window var1 = MinecraftClient.getInstance().getWindow();
      float var2 = (float)var1.getScaledHeight() / H();
      return Math.round(i * var2);
   }

   public static int SwapHelper(int i) {
      Window var1 = MinecraftClient.getInstance().getWindow();
      float var2 = (float)G() / var1.getScaledWidth();
      return Math.round(i * var2);
   }

   public static int Module_j(int i) {
      Window var1 = MinecraftClient.getInstance().getWindow();
      float var2 = (float)H() / var1.getScaledHeight();
      return Math.round(i * var2);
   }

   public static void HwidGen(DrawContext drawContext, float f, float g, float h, float i, float j, int k, boolean bl) {
      HwidGen(HwidGen(drawContext), f, g, h, i, j, k, bl);
   }

   public static void HwidGen(DrawContext drawContext, float f, float g, float h, float i, float j, float k, float l, float m, boolean bl, int... is) {
      HwidGen(HwidGen(drawContext), f, g, h, i, j, k, l, m, bl, is);
   }

   public static void HwidGen(Matrix4f matrix4f, float f, float g, float h, float i, float j, int k, boolean bl) {
      HwidGen(matrix4f, f, g, h, i, j, j, j, j, bl, k);
   }

   public static void HwidGen(Matrix4f matrix4f, float f, float g, float h, float i, float j, float k, float l, float m, boolean bl, int... is) {
      if (bl) {
         Module_Hud.add(() -> Shader_dt.HwidGen(matrix4f, f, g, h, i, j, k, l, m, 0.0F, is));
      } else {
         Shader_dt.HwidGen(matrix4f, f, g, h, i, j, k, l, m, 0.0F, is);
      }
   }

   public static void HwidGen(DrawContext drawContext, float f, float g, float h, float i, float j, float k, int l, boolean bl) {
      HwidGen(HwidGen(drawContext), f, g, h, i, j, j, j, j, k, l, bl);
   }

   public static void HwidGen(Matrix4f matrix4f, float f, float g, float h, float i, float j, float k, int l, boolean bl) {
      HwidGen(matrix4f, f, g, h, i, j, j, j, j, k, l, bl);
   }

   public static void HwidGen(Matrix4f matrix4f, float f, float g, float h, float i, float j, float k, float l, float m, float n, int o, boolean bl) {
      if (bl) {
         Module_Hud.add(() -> Shader_ds.HwidGen(matrix4f, f, g, h, i, j, k, l, m, n, 0.0F, o));
      } else {
         Shader_ds.HwidGen(matrix4f, f, g, h, i, j, k, l, m, n, 0.0F, o);
      }
   }

   public static void HwidGen(DrawContext drawContext, float f, float g, float h, Identifier identifier, int i, float j, boolean bl) {
      HwidGen(HwidGen(drawContext), f, g, h, identifier, i, j, bl);
   }

   public static void HwidGen(Matrix4f matrix4f, float f, float g, float h, Identifier identifier, int i, float j, boolean bl) {
      MinecraftClient var8 = MinecraftClient.getInstance();
      AbstractTexture var9 = var8.getTextureManager().getTexture(identifier);
      if (var9 != null) {
         if (bl) {
            Module_Hud.add(() -> Shader_du.HwidGen(matrix4f, f, g, h, var9.getGlTextureView(), i, j, 0.0F));
            return;
         }

         Shader_du.HwidGen(matrix4f, f, g, h, var9.getGlTextureView(), i, j, 0.0F);
      }
   }

   public static void HwidGen(RenderPass renderPass) {
      if (Y) {
         renderPass.enableScissor(Enum_ak, Enum_al, Enum_ak + Module_ChunkFinder, Enum_al + Toast_an);
      }
   }
}
