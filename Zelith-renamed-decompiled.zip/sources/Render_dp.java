import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class Render_dp {
   public static final Matrix4f KeyFile = new Matrix4f();
   public static final Matrix4f c = new Matrix4f();
   public static final Matrix4f LicenseResult = new Matrix4f();
   static MinecraftClient HwidGen = MinecraftClient.getInstance();

   public static boolean HwidGen(Matrix4f matrix4f, Matrix4f matrix4f2, double d, double e, double f, dq arg) {
      if (HwidGen.gameRenderer != null && HwidGen.getCameraEntity() != null && arg != null) {
         Vec3d var9 = HwidGen.gameRenderer.getCamera().getCameraPos();
         double var10 = d - var9.x;
         double var12 = e - var9.y;
         double var14 = f - var9.z;
         double var16 = matrix4f.m00() * var10 + matrix4f.m10() * var12 + matrix4f.m20() * var14 + matrix4f.m30();
         double var18 = matrix4f.m01() * var10 + matrix4f.m11() * var12 + matrix4f.m21() * var14 + matrix4f.m31();
         double var20 = matrix4f.m02() * var10 + matrix4f.m12() * var12 + matrix4f.m22() * var14 + matrix4f.m32();
         double var22 = matrix4f.m03() * var10 + matrix4f.m13() * var12 + matrix4f.m23() * var14 + matrix4f.m33();
         double var24 = matrix4f2.m00() * var16 + matrix4f2.m10() * var18 + matrix4f2.m20() * var20 + matrix4f2.m30() * var22;
         double var26 = matrix4f2.m01() * var16 + matrix4f2.m11() * var18 + matrix4f2.m21() * var20 + matrix4f2.m31() * var22;
         double var28 = matrix4f2.m02() * var16 + matrix4f2.m12() * var18 + matrix4f2.m22() * var20 + matrix4f2.m32() * var22;
         double var30 = matrix4f2.m03() * var16 + matrix4f2.m13() * var18 + matrix4f2.m23() * var20 + matrix4f2.m33() * var22;
         boolean var32 = var30 > 0.0;
         double var33 = var30 != 0.0 ? 1.0 / var30 : 0.0;
         double var35 = var24 * var33;
         double var37 = var26 * var33;
         double var39 = var28 * var33;
         double var41 = (var35 * 0.5 + 0.5) * HwidGen.getWindow().getScaledWidth();
         double var43 = (0.5 - var37 * 0.5) * HwidGen.getWindow().getScaledHeight();
         arg.HwidGen(var41, var43, var39, var30, var32);
         return true;
      } else {
         return false;
      }
   }
}
