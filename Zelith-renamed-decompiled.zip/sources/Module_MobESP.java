import java.awt.Color;
import java.util.ArrayList;
import java.util.Set;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Module_MobESP extends Module {
   private final cx HwidGen = new SettingMob("Mobs");
   private final dd Obj_ck = new Setting("Alpha", 100.0, 0.0, 255.0);
   private final dd Module_MobESP = new Setting("Range", 128.0, 16.0, 512.0);
   private final dd Obj_cm = new Setting("Tracers", false);
   private final dd Module_NoRender = new Setting("Color", new Color(255, 80, 80));

   public Module_MobESP() {
      super("Mob ESP", Category.KeyFile);
      this.HwidGen(this.HwidGen);
      this.HwidGen(this.Obj_ck);
      this.HwidGen(this.Module_MobESP);
      this.HwidGen(this.Obj_cm);
      this.HwidGen(this.Module_NoRender);
   }

   @Override
   public void HwidGen(MatrixStack matrixStack, float f) {
      if (HwidGen.world != null && HwidGen.player != null) {
         Set var3 = this.HwidGen.c();
         if (!var3.isEmpty()) {
            Camera var4 = Render_dm.HwidGen();
            if (var4 != null) {
               Vec3d var5 = Render_dm.HwidGen(var4);
               double var6 = var5.x;
               double var8 = var5.y;
               double var10 = var5.z;
               double var12 = (Double)this.Module_MobESP.HwidGen() * (Double)this.Module_MobESP.HwidGen();
               int var14 = this.HwidGen((Double)this.Obj_ck.HwidGen());
               boolean var15 = (Boolean)this.Obj_cm.HwidGen();
               Color var16 = this.KeyFile((Color)this.Module_NoRender.HwidGen(), var14);
               Color var17 = var15 ? this.KeyFile((Color)this.Module_NoRender.HwidGen(), 255) : null;
               Vec3d var18 = var15 ? Render_dm.KeyFile(var4) : null;
               Vec3d var19 = var15 ? Render_dm.c(var4) : null;
               Vec3d var20 = var15 ? Render_dm.HwidGen(var18, var19) : null;
               boolean var21 = var15 && Module_Freecam.HwidGen != null && Module_Freecam.HwidGen.HwidGen();
               Vec3d var22 = var15
                  ? (var21 ? new Vec3d(HwidGen.player.getX() - var6, HwidGen.player.getY() - var8, HwidGen.player.getZ() - var10) : var18.multiply(150.0))
                  : null;
               ArrayList var23 = new ArrayList();

               for (Entity var25 : HwidGen.world.getEntities()) {
                  if (var25 != HwidGen.player
                     && !(var25 instanceof PlayerEntity)
                     && var25 instanceof LivingEntity
                     && var25.isAlive()
                     && var3.contains(var25.getType())) {
                     Vec3d var26 = this.HwidGen(var25, f);
                     double var27 = var26.x - var6;
                     double var29 = var26.y - var8;
                     double var31 = var26.z - var10;
                     double var33 = var27 * var27 + var29 * var29 + var31 * var31;
                     if (!(var33 > var12)) {
                        double var35 = var25.getWidth() / 2.0;
                        double var37 = var25.getHeight();
                        double var39 = var29 + var37 * 0.5;
                        var23.add(new Obj_cm(var27, var29, var31, var39, var35, var37));
                     }
                  }
               }

               if (!var23.isEmpty()) {
                  matrixStack.push();
                  do var41 = Render_dm.HwidGen(matrixStack);

                  for (Obj_cm var44 : var23) {
                     var41.KeyFile(
                        var44.c - var44.Category,
                        var44.LicenseResult,
                        var44.LicenseState - var44.Category,
                        var44.c + var44.Category,
                        var44.LicenseResult + var44.Module,
                        var44.LicenseState + var44.Category,
                        var16
                     );
                     var41.HwidGen(
                        var44.c - var44.Category,
                        var44.LicenseResult,
                        var44.LicenseState - var44.Category,
                        var44.c + var44.Category,
                        var44.LicenseResult + var44.Module,
                        var44.LicenseState + var44.Category,
                        var16
                     );
                  }

                  var41.Module_FakePay();
                  if (var15) {
                     do var43 = Render_dm.HwidGen(matrixStack);

                     for (Obj_cm var46 : var23) {
                        Vec3d var28 = Render_dm.HwidGen(var46.c, var46.Module_f, var46.LicenseState, var18, var19, var20, 24.0, 2.75);
                        var43.HwidGen(var17, var22, var28, Module_zelith.KeyFile());
                     }

                     var43.Module_FakePay();
                  }

                  matrixStack.pop();
               }
            }
         }
      }
   }

   private int HwidGen(double d) {
      int var3 = (int)Math.round(d);
      return Math.max(0, Math.min(255, var3));
   }

   private Color KeyFile(Color color, int i) {
      int var3 = Math.max(0, Math.min(255, Math.round(color.getAlpha() / 255.0F * i)));
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), var3);
   }

   private Vec3d HwidGen(Entity entity, float f) {
      try {
         return entity.getLerpedPos(f);
      } catch (Throwable var10) {
         double var4 = MathHelper.lerp(f, entity.lastRenderX, entity.getX());
         double var6 = MathHelper.lerp(f, entity.lastRenderY, entity.getY());
         double var8 = MathHelper.lerp(f, entity.lastRenderZ, entity.getZ());
         return new Vec3d(var4, var6, var8);
      }
   }
}
