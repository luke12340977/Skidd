import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map.Entry;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlastFurnaceBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.EnchantingTableBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.FurnaceBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.PistonBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.SmokerBlockEntity;
import net.minecraft.block.entity.TrappedChestBlockEntity;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.chunk.WorldChunk;

public final class Module_StorageESP extends Module {
   private final dd SettingMob = new Setting("Alpha", 125.0, 0.0, 255.0);
   private final dd Misc_cy = new Setting("Tracers", true);
   private final dd Rec_cz = new Setting("Chests", true);
   private final dd cA = new Setting("Ender chests", true);
   private final dd cB = new Setting("Spawners", true);
   private final dd cC = new Setting("Shulker boxes", true);
   private final dd cD = new Setting("Furnaces", true);
   private final dd cE = new Setting("Barrels", true);
   private final dd cF = new Setting("Enchanting tables", true);
   private final dd cG = new Setting("Pistons", true);
   private final dd cH = new Setting("Hoppers", false);
   private final dd cI = new Setting("Chest color", new Color(156, 91, 0));
   private final dd cJ = new Setting("Trapped chest", new Color(200, 91, 0));
   private final dd cK = new Setting("Ender chest", new Color(117, 0, 255));
   private final dd cL = new Setting("Spawner", new Color(138, 126, 166));
   private final dd cM = new Setting("Shulker", new Color(134, 0, 158));
   private final dd cN = new Setting("Furnace", new Color(125, 125, 125));
   private final dd cO = new Setting("Barrel", new Color(255, 140, 140));
   private final dd cP = new Setting("Enchant", new Color(80, 80, 255));
   private final dd cQ = new Setting("Piston", new Color(35, 226, 0));
   private final dd cR = new Setting("Hopper", new Color(100, 200, 255));

   public Module_StorageESP() {
      super("Storage ESP", Category.KeyFile);
      this.HwidGen(this.SettingMob);
      this.HwidGen(this.Misc_cy);
      this.HwidGen(this.Rec_cz);
      this.HwidGen(this.cA);
      this.HwidGen(this.cB);
      this.HwidGen(this.cC);
      this.HwidGen(this.cD);
      this.HwidGen(this.cE);
      this.HwidGen(this.cF);
      this.HwidGen(this.cG);
      this.HwidGen(this.cH);
      this.HwidGen(this.cI);
      this.HwidGen(this.cJ);
      this.HwidGen(this.cK);
      this.HwidGen(this.cL);
      this.HwidGen(this.cM);
      this.HwidGen(this.cN);
      this.HwidGen(this.cO);
      this.HwidGen(this.cP);
      this.HwidGen(this.cQ);
      this.HwidGen(this.cR);
   }

   @Override
   public void HwidGen(MatrixStack matrixStack, float f) {
      if (HwidGen.world != null && HwidGen.player != null) {
         Camera var3 = Render_dm.HwidGen();
         if (var3 != null) {
            Vec3d var4 = Render_dm.HwidGen(var3);
            Vec3d var5 = Render_dm.KeyFile(var3);
            Vec3d var6 = Render_dm.c(var3);
            Vec3d var7 = Render_dm.HwidGen(var5, var6);
            boolean var8 = Module_Freecam.HwidGen != null && Module_Freecam.HwidGen.HwidGen();
            Vec3d var9;
            if (var8) {
               var9 = new Vec3d(HwidGen.player.getX() - var4.x, HwidGen.player.getY() - var4.y, HwidGen.player.getZ() - var4.z);
            } else {
               var9 = var5.multiply(150.0);
            }

            matrixStack.push();
            int var10 = HwidGen.options.getClampedViewDistance();
            ChunkPos var11 = HwidGen.player.getChunkPos();
            HashMap var12 = new HashMap();

            for (int var13 = -var10; var13 <= var10; var13++) {
               for (int var14 = -var10; var14 <= var10; var14++) {
                  WorldChunk var15 = HwidGen.world.getChunkManager().getWorldChunk(var11.x + var13, var11.z + var14, false);
                  if (var15 != null) {
                     for (BlockEntity var17 : var15.getBlockEntities().values()) {
                        Color var18 = this.HwidGen(var17, this.HwidGen((Double)this.SettingMob.HwidGen()));
                        if (var18.getAlpha() != 0) {
                           BlockPos var19 = var17.getPos();
                           BlockState var20 = HwidGen.world.getBlockState(var19);
                           VoxelShape var21 = var20.getCollisionShape(HwidGen.world, var19);
                           Box var22;
                           if (var21.isEmpty()) {
                              var22 = new Box(0.0, 0.0, 0.0, 1.0, 1.0, 1.0);
                           } else {
                              var22 = var21.getBoundingBox();
                           }

                           var12.put(var19, new Rec_cs(var22, var18));
                        }
                     }
                  }
               }
            }

            if (var12.isEmpty()) {
               matrixStack.pop();
            } else {
               ArrayList var45 = new ArrayList();
               HashSet var46 = new HashSet();

               for (Entry var50 : var12.entrySet()) {
                  BlockPos var53 = (BlockPos)var50.getKey();
                  if (!var46.contains(var53)) {
                     Box var56 = ((Rec_cs)var50.getValue()).HwidGen;
                     Color var58 = ((Rec_cs)var50.getValue()).Module_j;
                     BlockState var59 = HwidGen.world.getBlockState(var53);
                     if (var59.contains(ChestBlock.CHEST_TYPE)) {
                        ChestType var60 = (ChestType)var59.get(ChestBlock.CHEST_TYPE);
                        if (var60 != ChestType.SINGLE) {
                           Direction var62 = (Direction)var59.get(ChestBlock.FACING);
                           Direction var23 = var60 == ChestType.LEFT ? var62.rotateYClockwise() : var62.rotateYCounterclockwise();
                           BlockPos var24 = var53.offset(var23);
                           Rec_cs var25 = (Rec_cs)var12.get(var24);
                           if (var25 != null) {
                              var46.add(var24);
                              double var26 = Math.min(var53.getX() + var56.minX, var24.getX() + var25.HwidGen.minX);
                              double var28 = Math.min(var53.getY() + var56.minY, var24.getY() + var25.HwidGen.minY);
                              double var30 = Math.min(var53.getZ() + var56.minZ, var24.getZ() + var25.HwidGen.minZ);
                              double var32 = Math.max(var53.getX() + var56.maxX, var24.getX() + var25.HwidGen.maxX);
                              double var34 = Math.max(var53.getY() + var56.maxY, var24.getY() + var25.HwidGen.maxY);
                              double var36 = Math.max(var53.getZ() + var56.maxZ, var24.getZ() + var25.HwidGen.maxZ);
                              double var38 = var26 - var4.x;
                              double var40 = var28 - var4.y;
                              double var42 = var30 - var4.z;
                              Box var44 = new Box(0.0, 0.0, 0.0, var32 - var26, var34 - var28, var36 - var30);
                              var45.add(new Obj_ct(var38, var40, var42, var44, var58));
                              continue;
                           }
                        }
                     }

                     double var61 = var53.getX() - var4.x;
                     double var63 = var53.getY() - var4.y;
                     double var64 = var53.getZ() - var4.z;
                     var45.add(new Obj_ct(var61, var63, var64, var56, var58));
                  }
               }

               if (var45.isEmpty()) {
                  matrixStack.pop();
               } else {
                  for (Obj_ct var51 : var45) {
                     Color var54 = var51.Module;
                     Render_dm.KeyFile(
                        matrixStack,
                        var51.c + var51.HwidGen.minX,
                        var51.LicenseResult + var51.HwidGen.minY,
                        var51.LicenseState + var51.HwidGen.minZ,
                        var51.c + var51.HwidGen.maxX,
                        var51.LicenseResult + var51.HwidGen.maxY,
                        var51.LicenseState + var51.HwidGen.maxZ,
                        var54
                     );
                     Render_dm.HwidGen(
                        matrixStack,
                        var51.c + var51.HwidGen.minX,
                        var51.LicenseResult + var51.HwidGen.minY,
                        var51.LicenseState + var51.HwidGen.minZ,
                        var51.c + var51.HwidGen.maxX,
                        var51.LicenseResult + var51.HwidGen.maxY,
                        var51.LicenseState + var51.HwidGen.maxZ,
                        var51.Module
                     );
                  }

                  if ((Boolean)this.Misc_cy.HwidGen()) {
                     for (Obj_ct var52 : var45) {
                        Vec3d var55 = new Vec3d(
                           var52.c + var52.HwidGen.maxX / 2.0, var52.LicenseResult + var52.HwidGen.maxY / 2.0, var52.LicenseState + var52.HwidGen.maxZ / 2.0
                        );
                        Vec3d var57 = Render_dm.HwidGen(var55, var5, var6, var7, 24.0, 2.75);
                        Render_dm.HwidGen(matrixStack, var52.Module, var9, var57, Module_zelith.KeyFile());
                     }
                  }

                  matrixStack.pop();
               }
            }
         }
      }
   }

   private Color HwidGen(BlockEntity blockEntity, int i) {
      Color var3 = null;
      if (blockEntity instanceof TrappedChestBlockEntity && (Boolean)this.Rec_cz.HwidGen()) {
         var3 = (Color)this.cJ.HwidGen();
      } else if (blockEntity instanceof ChestBlockEntity && (Boolean)this.Rec_cz.HwidGen()) {
         var3 = (Color)this.cI.HwidGen();
      } else if (blockEntity instanceof EnderChestBlockEntity && (Boolean)this.cA.HwidGen()) {
         var3 = (Color)this.cK.HwidGen();
      } else if (blockEntity instanceof MobSpawnerBlockEntity && (Boolean)this.cB.HwidGen()) {
         var3 = (Color)this.cL.HwidGen();
      } else if (blockEntity instanceof ShulkerBoxBlockEntity && (Boolean)this.cC.HwidGen()) {
         var3 = (Color)this.cM.HwidGen();
      } else if ((blockEntity instanceof FurnaceBlockEntity || blockEntity instanceof BlastFurnaceBlockEntity || blockEntity instanceof SmokerBlockEntity)
         && (Boolean)this.cD.HwidGen()) {
         var3 = (Color)this.cN.HwidGen();
      } else if (blockEntity instanceof BarrelBlockEntity && (Boolean)this.cE.HwidGen()) {
         var3 = (Color)this.cO.HwidGen();
      } else if (blockEntity instanceof EnchantingTableBlockEntity && (Boolean)this.cF.HwidGen()) {
         var3 = (Color)this.cP.HwidGen();
      } else if (blockEntity instanceof PistonBlockEntity && (Boolean)this.cG.HwidGen()) {
         var3 = (Color)this.cQ.HwidGen();
      } else if (blockEntity instanceof HopperBlockEntity && (Boolean)this.cH.HwidGen()) {
         var3 = (Color)this.cR.HwidGen();
      }

      return var3 != null ? this.KeyFile(var3, i) : new Color(255, 255, 255, 0);
   }

   private int HwidGen(double d) {
      int var3 = (int)Math.round(d);
      if (var3 < 0) {
         return 0;
      } else {
         return var3 > 255 ? 255 : var3;
      }
   }

   private Color KeyFile(Color color, int i) {
      int var3 = Math.max(0, Math.min(255, Math.round(color.getAlpha() / 255.0F * i)));
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), var3);
   }
}
