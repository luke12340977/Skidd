import net.minecraft.text.Style;

record Rec_dj() {
   private final String N;
   private final Style HwidGen;

   Rec_dj(String string, Style style) {
      style = style == null ? Style.EMPTY : style;
      this.N = string;
      this.HwidGen = style;
   }

   public String E() {
      return this.N;
   }
}
