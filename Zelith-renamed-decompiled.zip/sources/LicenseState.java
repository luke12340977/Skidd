public enum LicenseState {
   KeyFile,
   c,
   LicenseResult;

   public static e[] values() {
      return (e[])HwidGen.clone();
   }

   public static e valueOf(String string) {
      return Enum.valueOf(LicenseState.class, string);
   }
}
