import com.mojang.authlib.GameProfile;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ProfileComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Module_PlayerESP extends Module {
   private final dd Module_StorageESP = new Setting("Alpha", 100.0, 0.0, 255.0);
   private final dd Rec_cs = new Setting("Range", 256.0, 16.0, 512.0);
   private final dd Obj_ct = new Setting("Tracers", false);
   private final dd Setting_cu = new Setting("Color", new Color(255, 0, 0));
   private final dd SettingBlock = new Setting("Notification", true);
   private final dd SettingItem = new Setting("Notification Sound", true);
   private final Set Module_WaterMark = ConcurrentHashMap.newKeySet();

   public Module_PlayerESP() {
      super("Player ESP", Category.KeyFile);
      this.HwidGen(this.Module_StorageESP);
      this.HwidGen(this.Rec_cs);
      this.HwidGen(this.Obj_ct);
      this.HwidGen(this.Setting_cu);
      this.HwidGen(this.SettingBlock);
      this.HwidGen(this.SettingItem);
   }

   @Override
   public void Module_f() {
      this.Module_WaterMark.clear();
      super.Module_f();
   }

   @Override
   public void Category() {
      if (HwidGen.world != null && HwidGen.player != null && (Boolean)this.SettingBlock.HwidGen()) {
         double var1 = (Double)this.Rec_cs.HwidGen() * (Double)this.Rec_cs.HwidGen();

         for (PlayerEntity var4 : HwidGen.world.getPlayers()) {
            if (var4 != HwidGen.player && var4.isAlive() && !var4.isSpectator() && !var4.isInvisibleTo(HwidGen.player)) {
               double var5 = var4.squaredDistanceTo(HwidGen.player);
               if (!(var5 > var1)) {
                  UUID var7 = var4.getUuid();
                  if (this.Module_WaterMark.add(var7)) {
                     this.HwidGen(var4);
                     if ((Boolean)this.SettingItem.HwidGen()) {
                        this.P();
                     }
                  }
               }
            }
         }
      }
   }

   @Override
   public void HwidGen(MatrixStack matrixStack, float f) {
      if (HwidGen.world != null && HwidGen.player != null) {
         Camera var3 = Render_dm.HwidGen();
         if (var3 != null) {
            Vec3d var4 = Render_dm.HwidGen(var3);
            double var5 = var4.x;
            double var7 = var4.y;
            double var9 = var4.z;
            double var11 = (Double)this.Rec_cs.HwidGen() * (Double)this.Rec_cs.HwidGen();
            int var13 = this.HwidGen((Double)this.Module_StorageESP.HwidGen());
            boolean var14 = (Boolean)this.Obj_ct.HwidGen();
            Color var15 = this.KeyFile((Color)this.Setting_cu.HwidGen(), var13);
            Color var16 = var14 ? this.KeyFile((Color)this.Setting_cu.HwidGen(), 255) : null;
            Vec3d var17 = var14 ? Render_dm.KeyFile(var3) : null;
            Vec3d var18 = var14 ? Render_dm.c(var3) : null;
            Vec3d var19 = var14 ? Render_dm.HwidGen(var17, var18) : null;
            boolean var20 = var14 && Module_Freecam.HwidGen != null && Module_Freecam.HwidGen.HwidGen();
            Vec3d var21 = var14
               ? (var20 ? new Vec3d(HwidGen.player.getX() - var5, HwidGen.player.getY() - var7, HwidGen.player.getZ() - var9) : var17.multiply(150.0))
               : null;
            ArrayList var22 = new ArrayList();

            for (PlayerEntity var24 : HwidGen.world.getPlayers()) {
               if (var24 != HwidGen.player && var24.isAlive() && !var24.isSpectator() && !var24.isInvisibleTo(HwidGen.player)) {
                  boolean var25 = Module_Friends.c() && Module_Friends.HwidGen(this.HwidGen(var24));
                  Vec3d var26 = this.HwidGen(var24, f);
                  double var27 = var26.x;
                  double var29 = var26.y;
                  double var31 = var26.z;
                  double var33 = var27 - var5;
                  double var35 = var29 - var7;
                  double var37 = var31 - var9;
                  double var39 = var33 * var33 + var35 * var35 + var37 * var37;
                  if (!(var39 > var11)) {
                     Color var41;
                     Color var42;
                     if (var25) {
                        Color var43 = Module_Friends.HwidGen();
                        var41 = this.KeyFile(var43, var13);
                        var42 = var14 ? this.KeyFile(var43, 255) : null;
                     } else {
                        var41 = var15;
                        var42 = var16;
                     }

                     double var57 = var24.getWidth() / 2.0;
                     double var45 = var24.getHeight();
                     boolean var47 = true;
                     double var48 = var35 + var24.getHeight() * 0.5;
                     var22.add(new Obj_cq(var33, var35, var37, var48, var57, var45, var41, var42, var47));
                  }
               }
            }

            if (!var22.isEmpty()) {
               matrixStack.push();
               do var50 = Render_dm.HwidGen(matrixStack);

               for (Obj_cq var53 : var22) {
                  if (var53.Q) {
                     var50.KeyFile(
                        var53.SwapHelper - var53.Module_Configs,
                        var53.Module_j,
                        var53.Module_ActiveModules - var53.Module_Configs,
                        var53.SwapHelper + var53.Module_Configs,
                        var53.Module_j + var53.Module_Friends,
                        var53.Module_ActiveModules + var53.Module_Configs,
                        var53.Module
                     );
                     var50.HwidGen(
                        var53.SwapHelper - var53.Module_Configs,
                        var53.Module_j,
                        var53.Module_ActiveModules - var53.Module_Configs,
                        var53.SwapHelper + var53.Module_Configs,
                        var53.Module_j + var53.Module_Friends,
                        var53.Module_ActiveModules + var53.Module_Configs,
                        var53.Module
                     );
                  }
               }

               var50.Module_FakePay();
               if (var14) {
                  do var52 = Render_dm.HwidGen(matrixStack);

                  for (Obj_cq var55 : var22) {
                     if (var55.SwapHelper != null) {
                        Vec3d var56 = Render_dm.HwidGen(var55.SwapHelper, var55.ClickBuf, var55.Module_ActiveModules, var17, var18, var19, 24.0, 2.75);
                        var52.HwidGen(var55.SwapHelper, var21, var56, Module_zelith.KeyFile());
                     }
                  }

                  var52.Module_FakePay();
               }

               matrixStack.pop();
            }
         }
      }
   }

   private int HwidGen(double d) {
      int var3 = (int)Math.round(d);
      if (var3 < 0) {
         return 0;
      } else {
         return var3 > 255 ? 255 : var3;
      }
   }

   private Color KeyFile(Color color, int i) {
      int var3 = Math.max(0, Math.min(255, Math.round(color.getAlpha() / 255.0F * i)));
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), var3);
   }

   private Vec3d HwidGen(PlayerEntity playerEntity, float f) {
      try {
         return playerEntity.getLerpedPos(f);
      } catch (Throwable var10) {
         double var4 = MathHelper.lerp(f, playerEntity.lastRenderX, playerEntity.getX());
         double var6 = MathHelper.lerp(f, playerEntity.lastRenderY, playerEntity.getY());
         double var8 = MathHelper.lerp(f, playerEntity.lastRenderZ, playerEntity.getZ());
         return new Vec3d(var4, var6, var8);
      }
   }

   private String HwidGen(PlayerEntity playerEntity) {
      if (playerEntity == null) {
         return "";
      } else {
         try {
            GameProfile var2 = playerEntity.getGameProfile();
            if (var2 != null) {
               try {
                  if (var2.getClass().getMethod("getName").invoke(var2) instanceof String var4 && !var4.isBlank()) {
                     return var4;
                  }
               } catch (Throwable var6) {
               }

               try {
                  if (var2.getClass().getMethod("name").invoke(var2) instanceof String var9 && !var9.isBlank()) {
                     return var9;
                  }
               } catch (Throwable var5) {
               }
            }
         } catch (Throwable var7) {
         }

         return playerEntity.getName().getString();
      }
   }

   private void HwidGen(PlayerEntity playerEntity) {
      if (HwidGen.getToastManager() != null) {
         ItemStack var2 = new ItemStack(Items.PLAYER_HEAD);

         try {
            GameProfile var3 = playerEntity.getGameProfile();
            if (var3 != null) {
               var2.set(DataComponentTypes.PROFILE, ProfileComponent.ofStatic(var3));
            }
         } catch (Exception var4) {
         }

         HwidGen.getToastManager().add(new Toast_cp(Text.literal("Player ESP"), Text.literal(playerEntity.getName().getString()), var2));
      }
   }

   private void P() {
      if (HwidGen.player != null) {
         HwidGen.player.playSound((SoundEvent)SoundEvents.BLOCK_NOTE_BLOCK_CHIME.value(), 1.0F, 1.0F);
      }
   }
}
