import java.awt.Color;
import java.lang.reflect.Method;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.FrustumIntersection;
import org.joml.Matrix4f;

public class Render_dm {
   private static final Matrix4f HwidGen = new Matrix4f();
   private static final FrustumIntersection HwidGen = new FrustumIntersection();
   private static boolean U;
   private static double Module_Hud;
   private static double HudElement;
   private static double Module_SpotifyHUD;
   private static final ThreadLocal KeyFile = ThreadLocal.withInitial(Render_dn::new);
   private static Method HwidGen;

   public static do HwidGen(MatrixStack matrixStack) {
      return new Misc_do(matrixStack);
   }

   public static void HwidGen(Matrix4f matrix4f, Matrix4f matrix4f2, Vec3d vec3d) {
      if (matrix4f != null && matrix4f2 != null && vec3d != null) {
         matrix4f2.mul(matrix4f, HwidGen);
         HwidGen.set(HwidGen);
         Module_Hud = vec3d.x;
         HudElement = vec3d.y;
         Module_SpotifyHUD = vec3d.z;
         U = true;
      } else {
         U = false;
      }
   }

   public static boolean HwidGen(double d, double e, double f, double g, double h, double i) {
      if (!U) {
         return true;
      } else {
         float var12 = (float)(d - Module_Hud);
         float var13 = (float)(e - HudElement);
         float var14 = (float)(f - Module_SpotifyHUD);
         float var15 = (float)(g - Module_Hud);
         float var16 = (float)(h - HudElement);
         float var17 = (float)(i - Module_SpotifyHUD);
         int var18 = HwidGen.intersectAab(var12, var13, var14, var15, var16, var17);
         return var18 == -1 || var18 == -2;
      }
   }

   public static Camera HwidGen() {
      return MinecraftClient.getInstance().gameRenderer.getCamera();
   }

   public static Vec3d HwidGen(Camera camera) {
      if (HwidGen == null) {
         for (Method var4 : Camera.class.getMethods()) {
            if (var4.getReturnType() == Vec3d.class && var4.getParameterCount() == 0) {
               HwidGen = var4;
               break;
            }
         }
      }

      try {
         return (Vec3d)HwidGen.invoke(camera);
      } catch (Exception var5) {
         return MinecraftClient.getInstance().player.getCameraPosVec(1.0F);
      }
   }

   public static void HwidGen(MatrixStack matrixStack, double d, double e, double f, double g, double h, double i, Color color) {
      Render_dn var14 = (Render_dn)KeyFile.get();
      var14.HwidGen(matrixStack);
      var14.HwidGen(d, e, f, g, h, i, color);
      var14.Module_FakePay();
   }

   public static void KeyFile(MatrixStack matrixStack, double d, double e, double f, double g, double h, double i, Color color) {
      Render_dn var14 = (Render_dn)KeyFile.get();
      var14.HwidGen(matrixStack);
      var14.KeyFile(d, e, f, g, h, i, color);
      var14.Module_FakePay();
   }

   public static void HwidGen(MatrixStack matrixStack, Color color, Vec3d vec3d, Vec3d vec3d2, float f) {
      Render_dn var5 = (Render_dn)KeyFile.get();
      var5.HwidGen(matrixStack);
      var5.HwidGen(color, vec3d, vec3d2, f);
      var5.Module_FakePay();
   }

   public static Vec3d KeyFile(Camera camera) {
      return new Vec3d(0.0, 0.0, 1.0).rotateX(-((float)Math.toRadians(camera.getPitch()))).rotateY(-((float)Math.toRadians(camera.getYaw()))).normalize();
   }

   public static Vec3d c(Camera camera) {
      return new Vec3d(1.0, 0.0, 0.0).rotateY(-((float)Math.toRadians(camera.getYaw()))).normalize();
   }

   public static Vec3d HwidGen(Vec3d vec3d, Vec3d vec3d2) {
      return vec3d.crossProduct(vec3d2).normalize();
   }

   public static Vec3d HwidGen(double d, double e, double f, Vec3d vec3d, Vec3d vec3d2, Vec3d vec3d3, double g, double h) {
      double var13 = d * vec3d2.x + e * vec3d2.y + f * vec3d2.z;
      double var15 = d * vec3d3.x + e * vec3d3.y + f * vec3d3.z;
      double var17 = d * vec3d.x + e * vec3d.y + f * vec3d.z;
      double var19 = Math.max(Math.abs(var17), 0.25);
      double var21 = var13 / var19;
      double var23 = var15 / var19;
      if (var17 <= 0.0) {
         double var25 = Math.hypot(var21, var23);
         if (var25 < h) {
            if (var25 < 1.0E-4) {
               var21 = h;
               var23 = 0.0;
            } else {
               double var27 = h / var25;
               var21 *= var27;
               var23 *= var27;
            }
         }
      }

      return vec3d.add(vec3d2.multiply(var21)).add(vec3d3.multiply(var23)).normalize().multiply(g);
   }

   public static Vec3d HwidGen(Vec3d vec3d, Vec3d vec3d2, Vec3d vec3d3, Vec3d vec3d4, double d, double e) {
      return HwidGen(vec3d.x, vec3d.y, vec3d.z, vec3d2, vec3d3, vec3d4, d, e);
   }
}
