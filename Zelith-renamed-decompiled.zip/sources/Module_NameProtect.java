public class Module_NameProtect extends Module {
   public final dd bB = new Setting("FakeName", "Player");
   public static br HwidGen;

   public Module_NameProtect() {
      super("Name Protect", Category.HwidGen);
      HwidGen = this;
      this.HwidGen(this.bB);
   }

   public String Module_zelith() {
      return (String)this.bB.HwidGen();
   }
}
