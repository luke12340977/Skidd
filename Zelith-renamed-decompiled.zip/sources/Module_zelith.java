import java.awt.Color;

public final class Module_zelith extends Module {
   private static t HwidGen;
   private final dd Module_SpotifyHUD = new Setting("Animations", true);
   private final dd Module_Themes = new Setting("Shadows", false);
   private final dd Module_WaterMark = new Setting("Toggle Notifications", true);
   private final dd Module_zelith = new Setting("Tracer Width", 1.0, 1.0, 6.0);
   private final cy KeyFile = new Misc_cy("Menu Size", "6", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10");

   public Module_zelith() {
      super("zelith +", Category.Module_f);
      this.HwidGen(this.Module_SpotifyHUD);
      this.HwidGen(this.Module_Themes);
      this.HwidGen(this.Module_WaterMark);
      this.HwidGen(this.Module_zelith);
      this.HwidGen(this.KeyFile);
      HwidGen = this;
   }

   public static int Category() {
      Color var0 = c();
      return var0.getAlpha() << 24 | var0.getRed() << 16 | var0.getGreen() << 8 | var0.getBlue();
   }

   public static Color c() {
      Color var0 = Module_Themes.KeyFile();
      return var0 != null ? var0 : new Color(107, 211, 165, 255);
   }

   public static boolean Category() {
      return HwidGen == null ? true : (Boolean)HwidGen.Module_SpotifyHUD.HwidGen();
   }

   public static boolean Module() {
      return HwidGen == null ? true : (Boolean)HwidGen.Module_Themes.HwidGen();
   }

   public static boolean SwapHelper() {
      return HwidGen == null ? true : (Boolean)HwidGen.Module_WaterMark.HwidGen();
   }

   public static int Module() {
      if (HwidGen == null) {
         return 5;
      } else {
         try {
            return Integer.parseInt((String)HwidGen.KeyFile.HwidGen());
         } catch (Exception var1) {
            return 5;
         }
      }
   }

   public static float KeyFile() {
      if (HwidGen == null) {
         return 1.0F;
      } else {
         double var0 = 1.0;

         try {
            var0 = (Double)HwidGen.Module_zelith.HwidGen();
         } catch (Exception var3) {
         }

         if (Double.isNaN(var0) || Double.isInfinite(var0)) {
            var0 = 1.0;
         }

         if (var0 < 1.0) {
            var0 = 1.0;
         }

         if (var0 > 6.0) {
            var0 = 6.0;
         }

         return (float)var0;
      }
   }
}
