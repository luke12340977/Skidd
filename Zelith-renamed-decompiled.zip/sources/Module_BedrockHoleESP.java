import java.awt.Color;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.opengl.GL11;

public final class Module_BedrockHoleESP extends Module {
   private final dd bZ = new Setting("Color", new Color(225, 25, 25));
   private final dd Module_SwingSpeed = new Setting("Min Hole Size", 2, 1, 12);
   private final dd Module_TabDetector = new Setting("Range", 48, 16, 128);
   private final Set Module_Friends = new HashSet();
   private final Set Module_Hud = new HashSet();
   private final Set HudElement = new HashSet();
   private int Y;
   private boolean L;
   private int Module_Themes;
   private int Z;
   private int Module_Hitbox;
   private int Module_HoverTotem;
   private BlockPos Module;

   public Module_BedrockHoleESP() {
      super("Bedrock Hole ESP", Category.KeyFile);
      this.HwidGen(this.bZ);
      this.HwidGen(this.Module_SwingSpeed);
      this.HwidGen(this.Module_TabDetector);
   }

   @Override
   public void Module_f() {
      this.Module_Friends.clear();
      this.L = false;
   }

   @Override
   public void Category() {
      if (HwidGen.world != null && HwidGen.player != null) {
         this.Y++;
         if (!this.L && this.Y >= 20) {
            this.Y = 0;
            int var1 = (Integer)this.Module_TabDetector.HwidGen();
            this.Module_Hitbox = var1;
            this.Module_HoverTotem = Math.max(var1 / 2, 8);
            this.Module = HwidGen.player.getBlockPos();
            int var2 = this.Module_Hitbox * 2 + 1;
            int var3 = this.Module_HoverTotem * 2 + 1;
            int var4 = this.Module_Hitbox * 2 + 1;
            this.Z = var2 * var3 * var4;
            this.Module_Themes = 0;
            this.Module_Hud.clear();
            this.HudElement.clear();
            this.L = true;
         }

         if (this.L) {
            int var16 = 0;
            int var17 = this.Module_Hitbox;
            int var18 = this.Module_HoverTotem;
            int var19 = this.Module.getX();
            int var5 = this.Module.getY();
            int var6 = this.Module.getZ();
            int var7 = var17 * 2 + 1;
            int var8 = var18 * 2 + 1;

            for (int var9 = (Integer)this.Module_SwingSpeed.HwidGen(); this.Module_Themes < this.Z && var16 < 32768; var16++) {
               int var10 = this.Module_Themes++;
               int var11 = var10 / var7 % var8;
               int var12 = var10 % var7;
               int var13 = var10 / (var7 * var8);
               BlockPos var14 = new BlockPos(var19 + var12 - var17, var5 + var11 - var18, var6 + var13 - var17);
               if (this.LicenseState(var14) && !this.HudElement.contains(var14) && this.LicenseResult(var14)) {
                  Set var15 = this.HwidGen(var14, this.HudElement);
                  if (var15.size() >= var9 && this.HwidGen(var15)) {
                     this.Module_Hud.addAll(var15);
                  }
               }
            }

            if (this.Module_Themes >= this.Z) {
               this.Module_Friends.clear();
               this.Module_Friends.addAll(this.Module_Hud);
               this.L = false;
            }
         }
      }
   }

   @Override
   public void HwidGen(MatrixStack matrixStack, float f) {
      if (HwidGen.world != null && HwidGen.player != null && !this.Module_Friends.isEmpty()) {
         Camera var3 = Render_dm.HwidGen();
         if (var3 != null) {
            Vec3d var4 = Render_dm.HwidGen(var3);
            Color var5 = (Color)this.bZ.HwidGen();
            Color var6 = new Color(var5.getRed(), var5.getGreen(), var5.getBlue(), 80);
            GL11.glDisable(2929);
            GL11.glDepthMask(false);
            matrixStack.push();
            do var7 = Render_dm.HwidGen(matrixStack);

            for (BlockPos var9 : this.Module_Friends) {
               if (Render_dm.HwidGen(var9.getX(), var9.getY(), var9.getZ(), var9.getX() + 1, var9.getY() + 1, var9.getZ() + 1)) {
                  double var10 = var9.getX() - var4.x;
                  double var12 = var9.getY() - var4.y;
                  double var14 = var9.getZ() - var4.z;
                  double var16 = var10 + 1.0;
                  double var18 = var12 + 1.0;
                  double var20 = var14 + 1.0;
                  var7.KeyFile(var10, var12, var14, var16, var18, var20, var5);
                  var7.HwidGen(var10, var12, var14, var16, var18, var20, var6);
               }
            }

            var7.Module_FakePay();
            matrixStack.pop();
            GL11.glDepthMask(true);
            GL11.glEnable(2929);
         }
      }
   }

   private Set HwidGen(BlockPos blockPos, Set set) {
      HashSet var3 = new HashSet();
      ArrayDeque var4 = new ArrayDeque();
      var4.add(blockPos);
      set.add(blockPos);

      while (!var4.isEmpty()) {
         BlockPos var5 = (BlockPos)var4.poll();
         if (this.LicenseState(var5) && this.LicenseResult(var5)) {
            var3.add(var5);
            if (var3.size() > 20) {
               return Set.of();
            }

            for (Direction var9 : Direction.values()) {
               BlockPos var10 = var5.offset(var9);
               if (!set.contains(var10) && this.LicenseState(var10) && this.LicenseResult(var10)) {
                  set.add(var10);
                  var4.add(var10);
               }
            }
         }
      }

      return var3;
   }

   private boolean HwidGen(Set set) {
      for (BlockPos var3 : set) {
         for (Direction var7 : Direction.values()) {
            BlockPos var8 = var3.offset(var7);
            if (!set.contains(var8)) {
               if (!this.LicenseState(var8)) {
                  return false;
               }

               if (!HwidGen.world.getBlockState(var8).isOf(Blocks.BEDROCK)) {
                  return false;
               }
            }
         }
      }

      return true;
   }

   private boolean LicenseResult(BlockPos blockPos) {
      return HwidGen.world.getBlockState(blockPos).isOf(Blocks.DEEPSLATE);
   }

   private boolean LicenseState(BlockPos blockPos) {
      return HwidGen.world.getChunkManager().isChunkLoaded(blockPos.getX() >> 4, blockPos.getZ() >> 4);
   }
}
