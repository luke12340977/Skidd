import java.util.List;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.client.toast.Toast.Visibility;
import net.minecraft.item.ItemStack;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

final class Toast_cp implements Toast {
   private static final Identifier Module_j = Identifier.ofVanilla("toast/advancement");
   private final Text Module;
   private final Text SwapHelper;
   private final ItemStack LicenseState;
   private Visibility HwidGen = Visibility.HIDE;

   Toast_cp(Text text, Text text2, ItemStack itemStack) {
      this.Module = text;
      this.SwapHelper = text2;
      this.LicenseState = itemStack;
   }

   public Visibility getVisibility() {
      return this.HwidGen;
   }

   public void update(ToastManager manager, long time) {
      this.HwidGen = time >= 5000.0 * manager.getNotificationDisplayTimeMultiplier() ? Visibility.HIDE : Visibility.SHOW;
   }

   public void draw(DrawContext context, TextRenderer textRenderer, long startTime) {
      context.drawGuiTexture(RenderPipelines.GUI_TEXTURED, Module_j, 0, 0, this.getWidth(), this.getHeight());
      context.drawText(textRenderer, this.Module, 30, 7, -256, false);
      List var5 = textRenderer.wrapLines(this.SwapHelper, 125);
      if (!var5.isEmpty()) {
         context.drawText(textRenderer, (OrderedText)var5.getFirst(), 30, 18, -1, false);
      }

      context.drawItemWithoutEntity(this.LicenseState, 8, 8);
   }
}
