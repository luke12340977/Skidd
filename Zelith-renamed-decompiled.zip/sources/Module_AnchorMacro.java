import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.ShieldItem;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.HealthUpdateS2CPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;

public final class Module_AnchorMacro extends Module_f {
   private final dd Module_AnchorMacro = new Setting("Switch Delay", 0.0F, 0.0F, 20.0F);
   private final dd Module_AutoCrystal = new Setting("Glowstone Delay", 0.0F, 0.0F, 20.0F);
   private final dd Module_AutoDoubleHand = new Setting("Explode Delay", 0.0F, 0.0F, 20.0F);
   private final dd Module_AutoInvTotem = new Setting("Totem Slot", 1.0F, 1.0F, 9.0F);
   private final dd Module_AutoTotem = new Setting("Switch Back", false);
   private int c;
   private int LicenseResult;
   private int LicenseState;
   private boolean Module_ActiveModules = false;

   public Module_AnchorMacro() {
      super("Anchor Macro", Category.c);
      this.HwidGen(this.Module_AnchorMacro);
      this.HwidGen(this.Module_AutoCrystal);
      this.HwidGen(this.Module_AutoDoubleHand);
      this.HwidGen(this.Module_AutoInvTotem);
      this.HwidGen(this.Module_AutoTotem);
   }

   @Override
   public void LicenseState() {
      this.Module_zelith();
      this.Module_ActiveModules = false;
      super.LicenseState();
   }

   @Override
   public void Module_f() {
      this.Module_zelith();
      this.Module_ActiveModules = false;
      super.Module_f();
   }

   @Override
   public void HwidGen(Packet packet) {
      if ((Boolean)this.Module_AutoTotem.HwidGen() && this.Module_ActiveModules && packet instanceof HealthUpdateS2CPacket) {
         this.Module_ActiveModules = false;
         if (HwidGen.player != null) {
            int var2 = this.HwidGen(Items.RESPAWN_ANCHOR);
            if (var2 != -1) {
               HwidGen.player.getInventory().setSelectedSlot(var2);
            }
         }
      }
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.world != null && HwidGen.interactionManager != null) {
         if (HwidGen.currentScreen == null) {
            if (!this.Module_j()) {
               if (!this.Module_ActiveModules()) {
                  this.Module_zelith();
               } else {
                  this.Module_WaterMark();
               }
            }
         }
      }
   }

   private boolean Module_j() {
      boolean var1 = HwidGen.player.getMainHandStack().getItem().getComponents().contains(DataComponentTypes.FOOD)
         || HwidGen.player.getOffHandStack().getItem().getComponents().contains(DataComponentTypes.FOOD);
      boolean var2 = HwidGen.player.getMainHandStack().getItem() instanceof ShieldItem || HwidGen.player.getOffHandStack().getItem() instanceof ShieldItem;
      boolean var3 = this.Module_ActiveModules();
      return (var1 || var2) && var3;
   }

   private boolean Module_ActiveModules() {
      return HwidGen.getWindow() != null && GLFW.glfwGetMouseButton(HwidGen.getWindow().getHandle(), 1) == 1;
   }

   private void Module_WaterMark() {
      if (HwidGen.crosshairTarget instanceof BlockHitResult var1) {
         if (var1.getType() == Type.BLOCK) {
            BlockPos var5 = var1.getBlockPos();
            BlockState var3 = HwidGen.world.getBlockState(var5);
            if (var3.isOf(Blocks.RESPAWN_ANCHOR)) {
               HwidGen.options.useKey.setPressed(false);
               int var4 = (Integer)var3.get(RespawnAnchorBlock.CHARGES);
               if (var4 == 0) {
                  this.HwidGen(var1);
               } else {
                  this.KeyFile(var1);
               }
            }
         }
      }
   }

   private void HwidGen(BlockHitResult blockHitResult) {
      if (!HwidGen.player.getMainHandStack().isOf(Items.GLOWSTONE)) {
         if (this.c < ((Float)this.Module_AnchorMacro.HwidGen()).intValue()) {
            this.c++;
            return;
         }

         this.c = 0;
         if (!this.HwidGen(Items.GLOWSTONE)) {
            return;
         }
      }

      if (HwidGen.player.getMainHandStack().isOf(Items.GLOWSTONE)) {
         if (this.LicenseResult < ((Float)this.Module_AutoCrystal.HwidGen()).intValue()) {
            this.LicenseResult++;
            return;
         }

         this.LicenseResult = 0;
         this.c(blockHitResult);
      }
   }

   private void KeyFile(BlockHitResult blockHitResult) {
      int var2 = Math.max(0, Math.min(8, ((Float)this.Module_AutoInvTotem.HwidGen()).intValue() - 1));
      if (HwidGen.player.getInventory().getSelectedSlot() != var2) {
         if (this.c < ((Float)this.Module_AnchorMacro.HwidGen()).intValue()) {
            this.c++;
            return;
         }

         this.c = 0;
         HwidGen.player.getInventory().setSelectedSlot(var2);
      }

      if (HwidGen.player.getInventory().getSelectedSlot() == var2) {
         if (this.LicenseState < ((Float)this.Module_AutoDoubleHand.HwidGen()).intValue()) {
            this.LicenseState++;
            return;
         }

         this.LicenseState = 0;
         this.c(blockHitResult);
         if ((Boolean)this.Module_AutoTotem.HwidGen()) {
            this.Module_ActiveModules = true;
         }
      }
   }

   private int HwidGen(Item item) {
      for (int var2 = 0; var2 < 9; var2++) {
         if (HwidGen.player.getInventory().getStack(var2).isOf(item)) {
            return var2;
         }
      }

      return -1;
   }

   private boolean HwidGen(Item item) {
      int var2 = this.HwidGen(item);
      if (var2 != -1) {
         HwidGen.player.getInventory().setSelectedSlot(var2);
         return true;
      } else {
         return false;
      }
   }

   private void c(BlockHitResult blockHitResult) {
      HwidGen.interactionManager.interactBlock(HwidGen.player, Hand.MAIN_HAND, blockHitResult);
      HwidGen.player.swingHand(Hand.MAIN_HAND);
   }

   private void Module_zelith() {
      this.c = 0;
      this.LicenseResult = 0;
      this.LicenseState = 0;
   }
}
