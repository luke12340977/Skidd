import net.minecraft.util.math.BlockPos;

record Rec_ay() {
   final BlockPos LicenseResult;
   final double HwidGen;

   Rec_ay(BlockPos blockPos, double d) {
      this.LicenseResult = blockPos;
      this.HwidGen = d;
   }
}
