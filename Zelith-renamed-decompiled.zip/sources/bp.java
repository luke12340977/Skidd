import net.minecraft.client.option.Perspective;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

public final class bp extends Module_f {
   public static bp HwidGen;
   private final cy Category = new Misc_cy("Mode", "Hold", new String[]{"Activation Mode"}, "Hold", "Toggle");
   private final dd Rec_bw = new Setting("Distance", 4.0F, 1.0F, 15.0F);
   private final dd Rec_bx = new Setting("Wall Clip", true);
   private final dd Rec_by = new Setting("Sensitivity", 1.0F, 0.1F, 3.0F);
   private final dd Module_Sprint = new Setting("Invert Y", false);
   private boolean F;
   private Perspective HwidGen;
   private boolean G;
   private float Module_f;
   private float Category;

   public bp() {
      super("Free Look", Category.HwidGen);
      HwidGen = this;
      this.HwidGen(this.Category);
      this.HwidGen(this.Rec_bw);
      this.HwidGen(this.Rec_bx);
      this.HwidGen(this.Rec_by);
      this.HwidGen(this.Module_Sprint);
   }

   @Override
   public void LicenseState() {
      this.F = false;
      this.HwidGen = null;
   }

   @Override
   public void Module_f() {
      this.W();
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.options != null && HwidGen.getWindow() != null) {
         if (this.A()) {
            int var1 = this.HwidGen();
            boolean var2 = var1 != 0 && GLFW.glfwGetKey(HwidGen.getWindow().getHandle(), var1) == 1;
            if (var2) {
               this.U();
            } else {
               this.W();
            }
         } else if (this.F) {
            this.V();
         }
      } else {
         this.W();
      }
   }

   @Override
   public void KeyFile() {
      if (this.HwidGen() && !this.A()) {
         if (this.F) {
            this.W();
         } else {
            this.U();
         }
      }
   }

   public boolean Module_AutoTotem() {
      return this.HwidGen() && this.F && HwidGen.player != null;
   }

   public void HwidGen(double d, double e) {
      if (this.Module_AutoTotem()) {
         double var5 = this.Module_Sprint.HwidGen() ? -1.0 : 1.0;
         double var7 = 0.15 * this.Category();
         this.Module_f = MathHelper.wrapDegrees(this.Module_f + (float)(d * var7));
         this.Category = MathHelper.clamp(this.Category + (float)(e * var7 * var5), -90.0F, 90.0F);
      }
   }

   public float LicenseResult() {
      return this.Module_f;
   }

   public float LicenseState() {
      return this.Category;
   }

   public float Module_f() {
      return MathHelper.clamp((Float)this.Rec_bw.HwidGen(), 1.0F, 15.0F);
   }

   public boolean Module_DoubleAnchor() {
      return (Boolean)this.Rec_bx.HwidGen();
   }

   public float Category() {
      return MathHelper.clamp((Float)this.Rec_by.HwidGen(), 0.1F, 3.0F);
   }

   private boolean A() {
      return this.Category.Module_f("Hold");
   }

   private void U() {
      if (!this.F && HwidGen.player != null && HwidGen.options != null) {
         this.HwidGen = HwidGen.options.getPerspective();
         this.G = HwidGen.chunkCullingEnabled;
         HwidGen.options.setPerspective(Perspective.THIRD_PERSON_BACK);
         HwidGen.chunkCullingEnabled = false;
         this.Module_f = HwidGen.player.getYaw();
         this.Category = HwidGen.player.getPitch();
         this.F = true;
      } else {
         this.V();
      }
   }

   private void V() {
      if (this.F && HwidGen.options != null) {
         if (HwidGen.options.getPerspective().isFrontView() || HwidGen.options.getPerspective().isFirstPerson()) {
            HwidGen.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            HwidGen.chunkCullingEnabled = false;
         }
      }
   }

   private void W() {
      if (this.F) {
         this.F = false;
         if (HwidGen.options != null) {
            HwidGen.options.setPerspective(this.HwidGen == null ? Perspective.FIRST_PERSON : this.HwidGen);
         }

         HwidGen.chunkCullingEnabled = this.G;
      }
   }
}
