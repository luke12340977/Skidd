import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.UniformType;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;

public class Shader_dt {
   private static RenderPipeline HwidGen;
   private static GpuBuffer HwidGen;

   public static void Module() {
      if (HwidGen == null) {
         try {
            HwidGen = RenderPipeline.builder(new Snippet[0])
               .withLocation(Identifier.of("zelith", "rectangle"))
               .withVertexShader(Identifier.of("zelith", "rectangle_vertex"))
               .withFragmentShader(Identifier.of("zelith", "rectangle_fragment"))
               .withVertexFormat(VertexFormat.builder().build(), DrawMode.TRIANGLES)
               .withUniform("Uniforms", UniformType.UNIFORM_BUFFER)
               .withBlend(BlendFunction.TRANSLUCENT)
               .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
               .withCull(false)
               .build();
            HwidGen = RenderSystem.getDevice().createBuffer(() -> "Rect2D Uniforms", 136, 256L);
         } catch (Exception var1) {
            System.err.println("[Rect2D] Failed to init: " + var1.getMessage());
            var1.printStackTrace();
         }
      }
   }

   public static void HwidGen(Matrix4f matrix4f, float f, float g, float h, float i, float j, float k, float l, float m, float n, int... is) {
      if (HwidGen == null) {
         Module();
      }

      if (HwidGen != null && HwidGen != null) {
         int[] var11 = HwidGen(is);
         ByteBuffer var12 = MemoryUtil.memAlloc(256);
         var12.putFloat(matrix4f.m00()).putFloat(matrix4f.m01()).putFloat(matrix4f.m02()).putFloat(matrix4f.m03());
         var12.putFloat(matrix4f.m10()).putFloat(matrix4f.m11()).putFloat(matrix4f.m12()).putFloat(matrix4f.m13());
         var12.putFloat(matrix4f.m20()).putFloat(matrix4f.m21()).putFloat(matrix4f.m22()).putFloat(matrix4f.m23());
         var12.putFloat(matrix4f.m30()).putFloat(matrix4f.m31()).putFloat(matrix4f.m32()).putFloat(matrix4f.m33());
         var12.position(64);
         var12.putFloat(f).putFloat(g).putFloat(h).putFloat(i);
         var12.putFloat(k).putFloat(l).putFloat(j).putFloat(m);
         var12.position(96);
         var12.putFloat(n).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
         var12.position(112);

         for (int var13 = 0; var13 < 9; var13++) {
            int var14 = var11[var13];
            var12.putFloat((var14 >> 16 & 0xFF) / 255.0F);
            var12.putFloat((var14 >> 8 & 0xFF) / 255.0F);
            var12.putFloat((var14 & 0xFF) / 255.0F);
            var12.putFloat((var14 >> 24 & 0xFF) / 255.0F);
         }

         var12.flip();
         CommandEncoder var20 = RenderSystem.getDevice().createCommandEncoder();
         var20.writeToBuffer(HwidGen.slice(), var12);
         MemoryUtil.memFree(var12);
         Framebuffer var21 = MinecraftClient.getInstance().getFramebuffer();
         RenderPass var15 = var20.createRenderPass(
            () -> "Rect2D", var21.getColorAttachmentView(), OptionalInt.empty(), var21.getDepthAttachmentView(), OptionalDouble.of(1.0)
         );

         try {
            Obj_dr.HwidGen(var15);
            var15.setPipeline(HwidGen);
            var15.setUniform("Uniforms", HwidGen);
            var15.draw(0, 6);
         } catch (Throwable var19) {
            if (var15 != null) {
               try {
                  var15.close();
               } catch (Throwable var18) {
                  var19.addSuppressed(var18);
               }
            }

            throw var19;
         }

         if (var15 != null) {
            var15.close();
         }
      }
   }

   private static int[] HwidGen(int[] is) {
      if (is.length == 1) {
         int var3 = is[0];
         return new int[]{var3, var3, var3, var3, var3, var3, var3, var3, var3};
      } else if (is.length >= 9) {
         return is;
      } else {
         int[] var1 = new int[9];

         for (int var2 = 0; var2 < 9; var2++) {
            var1[var2] = var2 < is.length ? is[var2] : is[is.length - 1];
         }

         return var1;
      }
   }
}
