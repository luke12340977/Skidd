import java.util.List;
import net.minecraft.util.math.BlockPos;

class Obj_ax {
   final int B;
   final List Module_f;

   Obj_ax(List list) {
      this.Module_f = list;
      this.B = list.size();
   }

   BlockPos HwidGen() {
      long var1 = 0L;
      long var3 = 0L;
      long var5 = 0L;

      for (BlockPos var8 : this.Module_f) {
         var1 += var8.getX();
         var3 += var8.getY();
         var5 += var8.getZ();
      }

      return new BlockPos((int)(var1 / this.Module_f.size()), (int)(var3 / this.Module_f.size()), (int)(var5 / this.Module_f.size()));
   }
}
