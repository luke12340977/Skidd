import java.util.Random;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public final class Module_AutoInvTotem extends Module {
   private final dd F = new Setting("Delay", 2.0F, 0.0F, 20.0F);
   private final dd G = new Setting("Hotbar", false);
   private final dd H = new Setting("Totem Slot", 1.0F, 1.0F, 9.0F);
   private final dd I = new Setting("Force Totem", false);
   private final dd J = new Setting("Auto Open", false);
   private final dd K = new Setting("Close Delay", 3.0F, 0.0F, 20.0F);
   private int Module_ActiveModules = 0;
   private int tickCounter = 0;
   private boolean Module_Configs = true;
   private final Random HwidGen = new Random();

   public Module_AutoInvTotem() {
      super("Auto Inv Totem", Category.c);
      this.HwidGen(this.F);
      this.HwidGen(this.G);
      this.HwidGen(this.H);
      this.HwidGen(this.I);
      this.HwidGen(this.J);
      this.HwidGen(this.K);
   }

   @Override
   public void LicenseState() {
      this.Module_ActiveModules = 0;
      this.tickCounter = 0;
      this.Module_Configs = true;
      super.LicenseState();
   }

   @Override
   public void Module_f() {
      this.Module_ActiveModules = 0;
      this.tickCounter = 0;
      super.Module_f();
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.interactionManager != null) {
         PlayerInventory var1 = HwidGen.player.getInventory();
         boolean var2 = HwidGen.player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING;
         if ((Boolean)this.J.HwidGen()) {
            this.HwidGen(var1, var2);
            this.Module_Configs = var2;
         } else {
            this.Module_Configs = var2;
            if (!(HwidGen.currentScreen instanceof InventoryScreen)) {
               this.tickCounter = 0;
            } else if (this.tickCounter < ((Float)this.F.HwidGen()).intValue() + this.Module_j()) {
               this.tickCounter++;
            } else if (!var2 && this.HwidGen(var1)) {
               this.tickCounter = 0;
            } else {
               if ((Boolean)this.G.HwidGen()) {
                  this.KeyFile(var1);
               }

               this.tickCounter = 0;
            }
         }
      }
   }

   private void HwidGen(PlayerInventory playerInventory, boolean bl) {
      switch (this.Module_ActiveModules) {
         case 0:
            if (this.Module_Configs && !bl && this.HwidGen(playerInventory) != -1) {
               this.Module_ActiveModules = 1;
               this.tickCounter = ((Float)this.F.HwidGen()).intValue() <= 0 ? 1 + this.HwidGen.nextInt(2) : 1 + this.HwidGen.nextInt(3);
            }

            if (!bl && this.Module_ActiveModules == 0 && !(HwidGen.currentScreen instanceof InventoryScreen) && this.HwidGen(playerInventory) != -1) {
               this.Module_ActiveModules = 1;
               this.tickCounter = ((Float)this.F.HwidGen()).intValue() <= 0 ? 1 + this.HwidGen.nextInt(2) : 1 + this.HwidGen.nextInt(3);
            }
            break;
         case 1:
            if (this.tickCounter > 0) {
               this.tickCounter--;
               return;
            }

            if (!(HwidGen.currentScreen instanceof InventoryScreen)) {
               HwidGen.setScreen(new InventoryScreen(HwidGen.player));
            }

            this.Module_ActiveModules = 2;
            this.tickCounter = ((Float)this.F.HwidGen()).intValue() + this.Module_j();
            break;
         case 2:
            if (!(HwidGen.currentScreen instanceof InventoryScreen)) {
               this.Module_ActiveModules = 0;
               return;
            }

            if (this.tickCounter > 0) {
               this.tickCounter--;
               return;
            }

            boolean var3 = false;
            if (!bl) {
               var3 = this.HwidGen(playerInventory);
            }

            boolean var4 = false;
            if ((Boolean)this.G.HwidGen()) {
               var4 = this.KeyFile(playerInventory);
            }

            if (!var3 && !var4 && !bl) {
               this.Module_ActiveModules = 3;
               this.tickCounter = 1;
            } else {
               this.Module_ActiveModules = 3;
               this.tickCounter = ((Float)this.K.HwidGen()).intValue() + this.Module_j();
            }
            break;
         case 3:
            if (this.tickCounter > 0) {
               this.tickCounter--;
               return;
            }

            if (HwidGen.currentScreen instanceof InventoryScreen) {
               HwidGen.player.closeHandledScreen();
               HwidGen.setScreen(null);
            }

            this.Module_ActiveModules = 0;
      }
   }

   private boolean HwidGen(PlayerInventory playerInventory) {
      int var2 = this.HwidGen(playerInventory);
      if (var2 == -1) {
         return false;
      } else {
         int var3 = LicenseResult(var2);
         HwidGen.interactionManager.clickSlot(HwidGen.player.currentScreenHandler.syncId, var3, 40, SlotActionType.SWAP, HwidGen.player);
         return true;
      }
   }

   private boolean KeyFile(PlayerInventory playerInventory) {
      int var2 = ((Float)this.H.HwidGen()).intValue() - 1;
      if (playerInventory.getStack(var2).getItem() == Items.TOTEM_OF_UNDYING) {
         return false;
      } else if (!playerInventory.getStack(var2).isEmpty() && !(Boolean)this.I.HwidGen()) {
         return false;
      } else {
         int var3 = this.KeyFile(playerInventory);
         if (var3 == -1) {
            return false;
         } else {
            int var4 = LicenseResult(var3);
            HwidGen.interactionManager.clickSlot(HwidGen.player.currentScreenHandler.syncId, var4, var2, SlotActionType.SWAP, HwidGen.player);
            return true;
         }
      }
   }

   private int HwidGen(PlayerInventory playerInventory) {
      for (int var2 = 9; var2 < 36; var2++) {
         if (playerInventory.getStack(var2).getItem() == Items.TOTEM_OF_UNDYING) {
            return var2;
         }
      }

      for (int var3 = 0; var3 < 9; var3++) {
         if (playerInventory.getStack(var3).getItem() == Items.TOTEM_OF_UNDYING) {
            return var3;
         }
      }

      return -1;
   }

   private int KeyFile(PlayerInventory playerInventory) {
      for (int var2 = 9; var2 < 36; var2++) {
         if (playerInventory.getStack(var2).getItem() == Items.TOTEM_OF_UNDYING) {
            return var2;
         }
      }

      return -1;
   }

   private static int LicenseResult(int i) {
      return i < 9 ? 36 + i : i;
   }

   private int Module_j() {
      return ((Float)this.F.HwidGen()).intValue() <= 0 ? 0 : this.HwidGen.nextInt(2);
   }
}
