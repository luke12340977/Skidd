import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;

public final class Module_AutoDoubleHand extends Module {
   private final dd B = new Setting("On Totem Pop", true);
   private final dd C = new Setting("On Health", true);
   private final dd D = new Setting("Health Threshold", 6.0F, 1.0F, 20.0F);
   private final dd E = new Setting("Cooldown", 5.0F, 0.0F, 40.0F);
   private boolean ClickBuf = false;
   private int SwapHelper = 0;
   private int Module_j = -1;

   public Module_AutoDoubleHand() {
      super("Auto Double Hand", Category.c);
      this.HwidGen(this.B);
      this.HwidGen(this.C);
      this.HwidGen(this.D);
      this.HwidGen(this.E);
   }

   @Override
   public void LicenseState() {
      this.ClickBuf = false;
      this.SwapHelper = 0;
      this.Module_j = -1;
   }

   @Override
   public void Module_f() {
      this.ClickBuf = false;
      this.SwapHelper = 0;
      this.Module_j = -1;
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.interactionManager != null) {
         if (this.SwapHelper > 0) {
            this.SwapHelper--;
         }

         PlayerInventory var1 = HwidGen.player.getInventory();
         boolean var2 = HwidGen.player.getMainHandStack().getItem() == Items.TOTEM_OF_UNDYING;
         boolean var3 = HwidGen.player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING;
         boolean var4 = var2 || var3;
         boolean var5 = this.ClickBuf && !var4;
         this.ClickBuf = var4;
         if (this.SwapHelper <= 0) {
            boolean var6 = false;
            if ((Boolean)this.B.HwidGen() && var5) {
               var6 = true;
            }

            if ((Boolean)this.C.HwidGen() && HwidGen.player.getHealth() <= (Float)this.D.HwidGen()) {
               var6 = true;
            }

            if (var6) {
               if (!var2) {
                  int var7 = this.SwapHelper();
                  if (var7 >= 0) {
                     if (var1.getSelectedSlot() != var7) {
                        this.Module_j = var1.getSelectedSlot();
                        var1.setSelectedSlot(var7);
                        this.SwapHelper = ((Float)this.E.HwidGen()).intValue();
                     }
                  }
               }
            }
         }
      }
   }

   private int SwapHelper() {
      PlayerInventory var1 = HwidGen.player.getInventory();

      for (int var2 = 0; var2 < 9; var2++) {
         if (var1.getStack(var2).isOf(Items.TOTEM_OF_UNDYING)) {
            return var2;
         }
      }

      return -1;
   }
}
