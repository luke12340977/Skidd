record Rec_bu() {
   private final int T;
   private final int U;
   private final boolean I;
   private final int V;
   private final int W;
   private final boolean J;
   private final int X;

   Rec_bu(int i, int j, boolean bl, int k, int l, boolean bl2, int m) {
      this.T = i;
      this.U = j;
      this.I = bl;
      this.V = k;
      this.W = l;
      this.J = bl2;
      this.X = m;
   }

   public int Module_DoubleAnchor() {
      return this.T;
   }

   public int A() {
      return this.U;
   }

   public boolean D() {
      return this.I;
   }

   public int B() {
      return this.W;
   }

   public boolean E() {
      return this.J;
   }

   public int C() {
      return this.X;
   }
}
