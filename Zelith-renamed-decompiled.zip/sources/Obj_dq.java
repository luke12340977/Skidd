public final class Obj_dq {
   public double Module_Themes;
   public double Module_WaterMark;
   public double Module_zelith;
   public double Module_AnchorMacro;
   public boolean X;

   public void HwidGen(double d, double e, double f, double g, boolean bl) {
      this.Module_Themes = d;
      this.Module_WaterMark = e;
      this.Module_zelith = f;
      this.Module_AnchorMacro = g;
      this.X = bl;
   }
}
