import java.util.List;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.client.toast.Toast.Visibility;
import net.minecraft.item.ItemStack;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

final class Toast_an implements Toast {
   private static final Identifier c = Identifier.ofVanilla("toast/advancement");
   private final Text c;
   private final Text LicenseResult;
   private final ItemStack KeyFile;
   private Visibility HwidGen = Visibility.HIDE;

   Toast_an(Text text, Text text2, ItemStack itemStack) {
      this.c = text;
      this.LicenseResult = text2;
      this.KeyFile = itemStack;
   }

   public Visibility getVisibility() {
      return this.HwidGen;
   }

   public void update(ToastManager manager, long time) {
      this.HwidGen = time >= 5000.0 * manager.getNotificationDisplayTimeMultiplier() ? Visibility.HIDE : Visibility.SHOW;
   }

   public void draw(DrawContext context, TextRenderer textRenderer, long startTime) {
      context.drawGuiTexture(RenderPipelines.GUI_TEXTURED, c, 0, 0, this.getWidth(), this.getHeight());
      context.drawText(textRenderer, this.c, 30, 7, -256, false);
      List var5 = textRenderer.wrapLines(this.LicenseResult, 125);
      if (!var5.isEmpty()) {
         context.drawText(textRenderer, (OrderedText)var5.getFirst(), 30, 18, -1, false);
      }

      context.drawItemWithoutEntity(this.KeyFile, 8, 8);
   }
}
