import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import org.lwjgl.glfw.GLFW;

public final class Module_PaperRig extends Module {
   private final dd aF = new Setting("Rigging Enabled", true);
   private final cw HwidGen = new SettingItem("Dispenser 1 Item", Items.DIAMOND);
   private final cw KeyFile = new SettingItem("Dispenser 2 Item", Items.EMERALD);
   private final dd aG = new Setting("Winning Item", 1, 1, 2);
   private final dd aH = new Setting("Switch Winner Key", "H");
   private final dd aI = new Setting("Toggle Rigging Key", "G");
   private boolean Module_AutoTotem = false;
   private boolean Module_DoubleAnchor = false;
   private BlockPos LicenseState = null;
   private BlockPos Module_f = null;
   private int Module_ActiveModules = 0;
   private int C = 0;
   private int D = 0;
   private Integer HwidGen = null;
   private Item HwidGen = null;
   private String statusMessage = "Searching for dispensers...";
   private static az HwidGen;

   public Module_PaperRig() {
      super("Paper Rig", Category.LicenseState);
      HwidGen = this;
      this.HwidGen(this.aF);
      this.HwidGen(this.HwidGen);
      this.HwidGen(this.KeyFile);
      this.HwidGen(this.aG);
      this.HwidGen(this.aH);
      this.HwidGen(this.aI);
   }

   public static az HwidGen() {
      return HwidGen;
   }

   public String HwidGen(ItemStack itemStack, String string) {
      if (itemStack == null) {
         return null;
      } else {
         return this.HwidGen != null && this.HwidGen != null && itemStack.getItem() == this.HwidGen ? this.HwidGen(string, this.HwidGen) : null;
      }
   }

   private String HwidGen(String string, int i) {
      if (string != null && !string.isEmpty()) {
         StringBuilder var3 = new StringBuilder();
         int var4 = 0;
         boolean var5 = false;

         while (var4 < string.length()) {
            if (!var5 && Character.isDigit(string.charAt(var4))) {
               while (var4 < string.length() && Character.isDigit(string.charAt(var4))) {
                  var4++;
               }

               var3.append(i);
               var5 = true;
            } else {
               var3.append(string.charAt(var4));
               var4++;
            }
         }

         return var3.toString();
      } else {
         return String.valueOf(i);
      }
   }

   @Override
   public void LicenseState() {
      this.LicenseState = null;
      this.Module_f = null;
      this.Module_ActiveModules = 0;
      this.HwidGen = null;
      this.HwidGen = null;
      this.C = 0;
      this.D = 0;
      this.statusMessage = "Searching for dispensers...";
   }

   @Override
   public void Module_f() {
      this.LicenseState = null;
      this.Module_f = null;
      this.HwidGen = null;
      this.HwidGen = null;
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.world != null) {
         int var1 = this.HwidGen((String)this.aI.HwidGen());
         if (var1 != -1) {
            boolean var2 = GLFW.glfwGetKey(HwidGen.getWindow().getHandle(), var1) == 1;
            if (var2 && !this.Module_AutoTotem) {
               this.aF.HwidGen(!(Boolean)this.aF.HwidGen());
            }

            this.Module_AutoTotem = var2;
         }

         int var14 = this.HwidGen((String)this.aH.HwidGen());
         if (var14 != -1) {
            boolean var3 = GLFW.glfwGetKey(HwidGen.getWindow().getHandle(), var14) == 1;
            if (var3 && !this.Module_DoubleAnchor) {
               this.aG.HwidGen(this.aG.HwidGen() == 1 ? 2 : 1);
            }

            this.Module_DoubleAnchor = var3;
         }

         if (this.LicenseState != null && this.Module_f != null) {
            int var15 = this.LicenseState(this.HwidGen.HwidGen());
            int var4 = this.LicenseState(this.KeyFile.HwidGen());
            if (this.Module_ActiveModules == 1) {
               int var16 = this.HwidGen == this.HwidGen.HwidGen() ? var15 : var4;
               int var17 = this.HwidGen == this.HwidGen.HwidGen() ? this.C : this.D;
               if (var16 <= var17) {
                  this.HwidGen = null;
                  this.HwidGen = null;
                  this.Module_ActiveModules = 2;
                  this.statusMessage = "Waiting for items to clear...";
               }
            } else if (this.Module_ActiveModules == 2) {
               if (var15 <= this.C && var4 <= this.D) {
                  this.C = var15;
                  this.D = var4;
                  this.Module_ActiveModules = 0;
                  this.statusMessage = "Ready - pull the lever!";
               }
            } else {
               boolean var5 = var15 > this.C;
               boolean var6 = var4 > this.D;
               if (var5 && var6) {
                  Item var7 = this.HwidGen.HwidGen();
                  Item var8 = this.KeyFile.HwidGen();
                  ItemStack var9 = this.HwidGen(var7);
                  ItemStack var10 = this.HwidGen(var8);
                  int var11 = this.c(var9);
                  int var12 = this.c(var10);
                  if ((Boolean)this.aF.HwidGen()) {
                     if ((Integer)this.aG.HwidGen() == 1) {
                        int var13 = var11 >= var12 ? var11 : this.KeyFile(var12, 9);
                        this.HwidGen = var7;
                        this.HwidGen = var13;
                        this.statusMessage = "D1: " + var13 + " vs D2: " + var12;
                     } else {
                        int var18 = var12 >= var11 ? var12 : this.KeyFile(var11, 9);
                        this.HwidGen = var8;
                        this.HwidGen = var18;
                        this.statusMessage = "D1: " + var11 + " vs D2: " + var18;
                     }
                  } else {
                     this.HwidGen = null;
                     this.HwidGen = null;
                     int var19 = var11 > var12 ? 1 : (var12 > var11 ? 2 : 0);
                     this.statusMessage = "D" + var19 + " wins (" + var11 + " vs " + var12 + ")";
                  }

                  this.Module_ActiveModules = 1;
               }
            }
         } else {
            this.L();
            if (this.LicenseState != null && this.Module_f != null) {
               this.C = this.LicenseState(this.HwidGen.HwidGen());
               this.D = this.LicenseState(this.KeyFile.HwidGen());
               this.Module_ActiveModules = 0;
               this.statusMessage = "Ready - pull the lever!";
            }
         }
      }
   }

   private int LicenseState(Item item) {
      if (item != null && item != Items.AIR) {
         int var2 = 0;

         for (int var3 = 0; var3 < HwidGen.player.getInventory().size(); var3++) {
            ItemStack var4 = HwidGen.player.getInventory().getStack(var3);
            if (var4.getItem() == item) {
               var2 += var4.getCount();
            }
         }

         return var2;
      } else {
         return 0;
      }
   }

   private ItemStack HwidGen(Item item) {
      if (item != null && item != Items.AIR) {
         ItemStack var2 = null;

         for (int var3 = 0; var3 < HwidGen.player.getInventory().size(); var3++) {
            ItemStack var4 = HwidGen.player.getInventory().getStack(var3);
            if (var4.getItem() == item) {
               var2 = var4;
            }
         }

         return var2;
      } else {
         return null;
      }
   }

   private void L() {
      ArrayList var1 = new ArrayList();
      BlockPos var2 = HwidGen.player.getBlockPos();
      byte var3 = 15;

      for (int var4 = -var3; var4 <= var3; var4++) {
         for (int var5 = -var3; var5 <= var3; var5++) {
            for (int var6 = -var3; var6 <= var3; var6++) {
               BlockPos var7 = var2.add(var4, var5, var6);
               if (HwidGen.world.getBlockState(var7).getBlock() == Blocks.DISPENSER) {
                  var1.add(var7);
               }
            }
         }
      }

      if (var1.size() >= 2) {
         this.LicenseState = (BlockPos)var1.get(0);
         this.Module_f = (BlockPos)var1.get(1);
      } else {
         this.LicenseState = null;
         this.Module_f = null;
         this.statusMessage = "Need 2 dispensers nearby";
      }
   }

   private int c(ItemStack itemStack) {
      if (itemStack == null) {
         return 1;
      } else {
         try {
            String var2 = itemStack.getName().getString();

            for (int var3 = 0; var3 < var2.length(); var3++) {
               if (Character.isDigit(var2.charAt(var3))) {
                  int var4 = 0;

                  while (var3 < var2.length() && Character.isDigit(var2.charAt(var3))) {
                     var4 = var4 * 10 + (var2.charAt(var3++) - '0');
                  }

                  return var4;
               }
            }
         } catch (Exception var5) {
         }

         return 1;
      }
   }

   private int KeyFile(int i, int j) {
      return i >= j ? i : i + ThreadLocalRandom.current().nextInt(j - i + 1);
   }

   private int HwidGen(String string) {
      if (string != null && !string.isEmpty()) {
         String var2 = string.toUpperCase();
         switch (var2) {
            case "A":
               return 65;
            case "B":
               return 66;
            case "C":
               return 67;
            case "D":
               return 68;
            case "E":
               return 69;
            case "F":
               return 70;
            case "G":
               return 71;
            case "H":
               return 72;
            case "I":
               return 73;
            case "J":
               return 74;
            case "K":
               return 75;
            case "L":
               return 76;
            case "M":
               return 77;
            case "N":
               return 78;
            case "O":
               return 79;
            case "P":
               return 80;
            case "Q":
               return 81;
            case "R":
               return 82;
            case "S":
               return 83;
            case "T":
               return 84;
            case "U":
               return 85;
            case "V":
               return 86;
            case "W":
               return 87;
            case "X":
               return 88;
            case "Y":
               return 89;
            case "Z":
               return 90;
            case "0":
               return 48;
            case "1":
               return 49;
            case "2":
               return 50;
            case "3":
               return 51;
            case "4":
               return 52;
            case "5":
               return 53;
            case "6":
               return 54;
            case "7":
               return 55;
            case "8":
               return 56;
            case "9":
               return 57;
            case "SPACE":
               return 32;
            case "ENTER":
               return 257;
            case "ESC":
               return 256;
            case "TAB":
               return 258;
            case "SHIFT":
               return 340;
            case "CTRL":
               return 341;
            case "ALT":
               return 342;
            default:
               return -1;
         }
      } else {
         return -1;
      }
   }
}
