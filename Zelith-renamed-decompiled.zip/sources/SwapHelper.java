import java.awt.Color;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.network.packet.Packet;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

public class SwapHelper {
   public static final i HwidGen = new SwapHelper();
   private final List KeyFile = new ArrayList();
   private boolean LicenseState = false;
   private boolean Module_f = false;

   public void Module() {
      if (!this.LicenseState) {
         this.KeyFile.add(new Module_zelith());
         this.KeyFile.add(new Module_Themes());
         this.KeyFile.add(new Module_Hud());
         this.KeyFile.add(new Module_SpotifyHUD());
         this.KeyFile.add(new Module_Friends());
         this.KeyFile.add(new Module_Configs());
         this.KeyFile.add(new Module_WaterMark());
         this.KeyFile.add(new Module_PlayerESP());
         this.KeyFile.add(new Module_BlockESP());
         this.KeyFile.add(new Module_AmethystESP());
         this.KeyFile.add(new Module_MobESP());
         this.KeyFile.add(new Module_StorageESP());
         this.KeyFile.add(new Module_Freecam());
         this.KeyFile.add(new Module_LightESP());
         this.KeyFile.add(new Module_FullBright());
         this.KeyFile.add(new Module_NoRender());
         this.KeyFile.add(new Module_BedrockHoleESP());
         this.KeyFile.add(new Module_ActiveModules());
         this.KeyFile.add(new Module_j("Elytra Swap", Category.c));
         this.KeyFile.add(new Module_j("Mace Swap", Category.c));
         this.KeyFile.add(new Module_AutoTotem());
         this.KeyFile.add(new Module_HoverTotem());
         this.KeyFile.add(new Module_AutoInvTotem());
         this.KeyFile.add(new Module_Hitbox());
         this.KeyFile.add(new Module_AnchorMacro());
         this.KeyFile.add(new Module_AutoCrystal());
         this.KeyFile.add(new Module_DoubleAnchor());
         this.KeyFile.add(new Module_Triggerbot());
         this.KeyFile.add(new Module_ShieldBreaker());
         this.KeyFile.add(new Module_AutoDoubleHand());
         this.KeyFile.add(new Module_SpearSwap());
         this.KeyFile.add(new Module_NameProtect());
         this.KeyFile.add(new Module_NameTags());
         this.KeyFile.add(new Module_CoordSnapper());
         this.KeyFile.add(new Module_HomeSetter());
         this.KeyFile.add(new Module_SwingSpeed());
         this.KeyFile.add(new bp());
         this.KeyFile.add(new Module_FastPlace());
         this.KeyFile.add(new Module_AutoTool());
         this.KeyFile.add(new Module_AutoLog());
         this.KeyFile.add(new Module_SkinChanger());
         this.KeyFile.add(new Module_Sprint());
         this.KeyFile.add(new Module_TabDetector());
         this.KeyFile.add(new Module_WeatherNotifier());
         this.KeyFile.add(new Module_FakePlayer());
         this.KeyFile.add(new Module_AntiAFK());
         this.KeyFile.add(new Module_AutoEat());
         this.KeyFile.add(new Module_TPASpammer());
         this.KeyFile.add(new Module_ActivityFinder());
         this.KeyFile.add(new Module_FakeRoles());
         this.KeyFile.add(new Module_ChunkFinder());
         this.KeyFile.add(new Module_GrowthFinder());
         this.KeyFile.add(new Module_AntiTrap());
         this.KeyFile.add(new Module_BoneDropper());
         this.KeyFile.add(new Module_SpawnerProtect());
         this.KeyFile.add(new Module_FakeScoreboard());
         this.KeyFile.add(new Module_FakePay());
         this.KeyFile.add(new Module_FakePayments());
         this.KeyFile.add(new Module_PaperRig());
         this.KeyFile.add(new Module_StashFinder());
         this.KeyFile.add(new Module_EntityScanner());
         this.KeyFile.add(new Module_AutoRender());
         this.KeyFile.add(new Module_SusChunkFinder());
         this.KeyFile.add(new Module_SpawnerFinder());
         this.KeyFile.add(new Module_RegionMap());
         this.LicenseState = true;
         this.Module_ActiveModules();
      }
   }

   public void SwapHelper() {
      if (this.LicenseState && !this.Module_f) {
         this.Module_j();
      }
   }

   public void Module_j() {
      if (this.LicenseState && !this.Module_f) {
         Path var1 = this.HwidGen();

         try {
            Files.createDirectories(var1.getParent());

            try (BufferedWriter var2 = Files.newBufferedWriter(var1, StandardCharsets.UTF_8)) {
               var2.write("ZELITH_CONFIG_V2");
               var2.newLine();

               for (Module var4 : this.KeyFile) {
                  var2.write("MODULE");
                  var2.write(9);
                  var2.write(this.KeyFile(var4.c()));
                  var2.write(9);
                  var2.write(Integer.toString(var4.KeyFile()));
                  var2.write(9);
                  int var5 = var4 instanceof Module_f var6 ? var6.HwidGen() : 0;
                  var2.write(Integer.toString(var5));
                  var2.write(9);
                  var2.write(Boolean.toString(var4.HwidGen()));
                  var2.newLine();

                  for (Setting var7 : var4.HwidGen()) {
                     String var8 = this.HwidGen(var7);
                     if (var8 != null) {
                        var2.write("SETTING");
                        var2.write(9);
                        var2.write(this.KeyFile(var4.c()));
                        var2.write(9);
                        var2.write(this.KeyFile(var7.c()));
                        var2.write(9);
                        var2.write(this.KeyFile(var8));
                        var2.newLine();
                     }
                  }
               }

               for (p var16 : HudElement.values()) {
                  int[] var17 = Module_Hud.HwidGen(var16);
                  var2.write("HUDPOS");
                  var2.write(9);
                  var2.write(var16.name());
                  var2.write(9);
                  var2.write(Integer.toString(var17[0]));
                  var2.write(9);
                  var2.write(Integer.toString(var17[1]));
                  var2.newLine();
               }
            }
         } catch (IOException var11) {
         }
      }
   }

   public void Module_ActiveModules() {
      Path var1 = this.HwidGen();
      if (Files.exists(var1)) {
         this.Module_f = true;

         try {
            for (String var4 : Files.readAllLines(var1, StandardCharsets.UTF_8)) {
               if (var4 != null && !var4.isBlank() && !"ZELITH_CONFIG_V2".equals(var4)) {
                  if (var4.startsWith("MODULE\t")) {
                     this.c(var4);
                  } else if (var4.startsWith("SETTING\t")) {
                     this.LicenseResult(var4);
                  } else if (var4.startsWith("HUDPOS\t")) {
                     this.KeyFile(var4);
                  } else {
                     this.LicenseState(var4);
                  }
               }
            }
         } catch (IOException var8) {
         } finally {
            this.Module_f = false;
         }
      }
   }

   private void KeyFile(String string) {
      try {
         String[] var2 = string.split("\t");
         if (var2.length < 4) {
            return;
         }

         p var3 = HudElement.valueOf(var2[1]);
         int var4 = Integer.parseInt(var2[2]);
         int var5 = Integer.parseInt(var2[3]);
         Module_Hud.HwidGen(var3, var4, var5);
      } catch (Exception var6) {
      }
   }

   public List KeyFile() {
      return this.KeyFile;
   }

   public List HwidGen(g arg) {
      ArrayList var2 = new ArrayList();

      for (Module var4 : this.KeyFile) {
         if (var4.HwidGen() == arg) {
            var2.add(var4);
         }
      }

      return var2;
   }

   public h HwidGen(String string) {
      for (Module var3 : this.KeyFile) {
         if (var3.c().equalsIgnoreCase(string)) {
            return var3;
         }
      }

      return null;
   }

   public void Category() {
      for (Module var2 : this.KeyFile) {
         if (var2.HwidGen()) {
            var2.Category();
         }
      }
   }

   public void HwidGen(MatrixStack matrixStack, float f) {
      for (Module var4 : this.KeyFile) {
         if (var4.HwidGen()) {
            var4.HwidGen(matrixStack, f);
         }
      }
   }

   public void HwidGen(Packet packet) {
      for (Module var3 : this.KeyFile) {
         if (var3.HwidGen()) {
            var3.HwidGen(packet);
         }
      }
   }

   public boolean HwidGen(Packet packet) {
      boolean var2 = false;

      for (Module var4 : this.KeyFile) {
         if (var4.HwidGen()) {
            try {
               var2 |= var4.HwidGen(packet);
            } catch (Exception var6) {
            }
         }
      }

      return var2;
   }

   private Path HwidGen() {
      return MinecraftClient.getInstance().runDirectory.toPath().resolve("zelith_config.txt");
   }

   private void c(String string) {
      String[] var2 = string.split("\t", 5);
      if (var2.length >= 5) {
         h var3 = this.HwidGen(this.c(var2[1]));
         if (var3 != null) {
            try {
               var3.LicenseResult(Integer.parseInt(var2[2]));
               if (var3 instanceof Module_f var4) {
                  var4.KeyFile(Integer.parseInt(var2[3]));
               }

               var3.KeyFile(Boolean.parseBoolean(var2[4]));
            } catch (Exception var5) {
            }
         }
      }
   }

   private void LicenseResult(String string) {
      String[] var2 = string.split("\t", 4);
      if (var2.length >= 4) {
         h var3 = this.HwidGen(this.c(var2[1]));
         if (var3 != null) {
            dd var4 = this.HwidGen(var3, this.c(var2[2]));
            if (var4 != null) {
               this.HwidGen(var4, this.c(var2[3]));
            }
         }
      }
   }

   private void LicenseState(String string) {
      String[] var2 = string.split(":", 4);
      if (var2.length >= 2) {
         h var3 = this.HwidGen(var2[0]);
         if (var3 != null) {
            try {
               if (var2.length >= 2) {
                  var3.LicenseResult(Integer.parseInt(var2[1]));
               }

               if (var2.length >= 3 && var3 instanceof Module_f var4) {
                  var4.KeyFile(Integer.parseInt(var2[2]));
               }

               if (var2.length >= 4) {
                  var3.KeyFile(Boolean.parseBoolean(var2[3]));
               }
            } catch (Exception var5) {
            }
         }
      }
   }

   private dd HwidGen(h arg, String string) {
      for (Setting var4 : arg.HwidGen()) {
         if (var4.LicenseResult(string)) {
            return var4;
         }
      }

      return null;
   }

   private String HwidGen(dd arg) {
      Object var2 = arg.HwidGen();
      if (arg instanceof SettingBlock var9) {
         return this.HwidGen(var9);
      } else if (var2 instanceof Boolean var8) {
         return Boolean.toString(var8);
      } else if (var2 instanceof Float var7) {
         return Float.toString(var7);
      } else if (var2 instanceof Integer var6) {
         return Integer.toString(var6);
      } else if (var2 instanceof Double var5) {
         return Double.toString(var5);
      } else if (var2 instanceof String var4) {
         return var4;
      } else {
         return var2 instanceof Color var3 ? var3.getRed() + "," + var3.getGreen() + "," + var3.getBlue() + "," + var3.getAlpha() : null;
      }
   }

   private void HwidGen(dd arg, String string) {
      Object var3 = arg.HwidGen();

      try {
         if (arg instanceof SettingBlock var8) {
            var8.LicenseResult(this.HwidGen(string));
            return;
         }

         if (var3 instanceof Boolean) {
            arg.HwidGen(Boolean.parseBoolean(string));
            return;
         }

         if (var3 instanceof Float) {
            arg.HwidGen(Float.parseFloat(string));
            return;
         }

         if (var3 instanceof Integer) {
            int var7 = Math.round(Float.parseFloat(string));
            arg.HwidGen(var7);
            return;
         }

         if (var3 instanceof Double) {
            arg.HwidGen(Double.parseDouble(string));
            return;
         }

         if (var3 instanceof String) {
            arg.HwidGen(string);
            return;
         }

         if (var3 instanceof Color) {
            String[] var4 = string.split(",", 4);
            if (var4.length == 4) {
               Color var5 = new Color(Integer.parseInt(var4[0]), Integer.parseInt(var4[1]), Integer.parseInt(var4[2]), Integer.parseInt(var4[3]));
               arg.HwidGen(var5);
            }
         }
      } catch (Exception var6) {
      }
   }

   private String HwidGen(cv arg) {
      StringBuilder var2 = new StringBuilder();

      for (Block var4 : arg.KeyFile()) {
         Identifier var5 = Registries.BLOCK.getId(var4);
         if (var5 != null) {
            if (!var2.isEmpty()) {
               var2.append(',');
            }

            var2.append(var5);
         }
      }

      return var2.toString();
   }

   private Set HwidGen(String string) {
      LinkedHashSet var2 = new LinkedHashSet();
      if (string != null && !string.isBlank()) {
         for (String var6 : string.split(",")) {
            String var7 = var6.trim();
            if (!var7.isEmpty()) {
               Identifier var8 = Identifier.tryParse(var7);
               if (var8 != null) {
                  Block var9 = (Block)Registries.BLOCK.get(var8);
                  if (var9 != null) {
                     var2.add(var9);
                  }
               }
            }
         }

         return var2;
      } else {
         return var2;
      }
   }

   private String KeyFile(String string) {
      return Base64.getEncoder().encodeToString(string.getBytes(StandardCharsets.UTF_8));
   }

   private String c(String string) {
      if (string != null && !string.isEmpty()) {
         try {
            return new String(Base64.getDecoder().decode(string), StandardCharsets.UTF_8);
         } catch (IllegalArgumentException var3) {
            return string;
         }
      } else {
         return "";
      }
   }
}
