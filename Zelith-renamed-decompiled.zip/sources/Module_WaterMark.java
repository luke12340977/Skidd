import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

public final class Module_WaterMark extends Module {
   public Module_WaterMark() {
      super("Water Mark", Category.Module_f);
      HudRenderCallback.EVENT.register((HudRenderCallback)(drawContext, renderTickCounter) -> {
         if (this.HwidGen()) {
            this.render(drawContext);
         }
      });
   }

   private void render(DrawContext drawContext) {
      MinecraftClient var2 = MinecraftClient.getInstance();
      if (var2 != null && var2.player != null) {
         if (!var2.getDebugHud().shouldShowDebugHud()) {
            TextRenderer var3 = var2.textRenderer;
            int var4 = Module_zelith.Category();
            int var5 = var3.getWidth("zelith");
            int var6 = var5 + var3.getWidth(" +") + 16;
            byte var7 = 16;
            Obj_dr.HwidGen(drawContext, 4.0F, 4.0F, (float)var6, (float)var7, 6.0F, -652993496, false);
            Obj_dr.HwidGen(drawContext, 4.0F, 4.0F, (float)var6, (float)var7, 6.0F, 1.0F, -869253035, false);
            drawContext.drawText(var3, "zelith", 12, 8, -985864, true);
            drawContext.drawText(var3, " +", 12 + var5, 8, var4, true);
         }
      }
   }
}
