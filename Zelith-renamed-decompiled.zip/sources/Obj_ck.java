final class Obj_ck {
   final int Module_ActivityFinder;
   final int Module_AntiTrap;
   final int Module_AutoRender;
   final int[] HwidGen;
   final int Toast_ai;
   final short[] HwidGen;
   final int[] KeyFile;
   final int Module_BoneDropper;

   Obj_ck(int i, int j, int k, int[] is, int l, short[] ss, int[] js, int m) {
      this.Module_ActivityFinder = i;
      this.Module_AntiTrap = j;
      this.Module_AutoRender = k;
      this.HwidGen = is;
      this.Toast_ai = l;
      this.HwidGen = ss;
      this.KeyFile = js;
      this.Module_BoneDropper = m;
   }
}
