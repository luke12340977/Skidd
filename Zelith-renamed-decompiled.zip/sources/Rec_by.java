import net.minecraft.entity.player.PlayerSkinType;

record Rec_by() {
   private final String D;
   private final PlayerSkinType KeyFile;

   Rec_by(String string, PlayerSkinType playerSkinType) {
      this.D = string;
      this.KeyFile = playerSkinType;
   }

   public String Module_AnchorMacro() {
      return this.D;
   }

   public PlayerSkinType HwidGen() {
      return this.KeyFile;
   }
}
