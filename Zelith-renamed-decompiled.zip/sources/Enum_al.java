enum Enum_al {
   HwidGen,
   KeyFile,
   c,
   LicenseResult;

   public static al[] values() {
      return (al[])HwidGen.clone();
   }

   public static al valueOf(String string) {
      return Enum.valueOf(Enum_al.class, string);
   }
}
