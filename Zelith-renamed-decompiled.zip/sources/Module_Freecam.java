import net.minecraft.client.option.Perspective;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3d;

public class Module_Freecam extends Module {
   public final Vector3d HwidGen = new Vector3d();
   public final Vector3d KeyFile = new Vector3d();
   private final Vector3d c = new Vector3d();
   public float Module;
   public float SwapHelper;
   public float Module_j;
   public float Module_ActiveModules;
   public final dd Module_BlockESP = new Setting("Speed", 1.0F, 0.1F, 10.0F);
   private boolean N = true;
   private float ClickBuf = 0.5F;
   private float Module_Configs;
   private Perspective HwidGen;
   private boolean G;
   private long Module_zelith;
   private float Module_Friends;
   private float Module_Hud;
   public static ch HwidGen;
   public boolean O;

   public Module_Freecam() {
      super("Freecam", Category.KeyFile);
      HwidGen = this;
      this.HwidGen(this.Module_BlockESP);
   }

   @Override
   public void LicenseState() {
      if (HwidGen.player != null && HwidGen.world != null) {
         this.HwidGen = HwidGen.options.getPerspective();
         this.G = HwidGen.chunkCullingEnabled;
         HwidGen.chunkCullingEnabled = false;
         this.Module_Friends = HwidGen.player.getYaw();
         this.Module_Hud = HwidGen.player.getPitch();
         this.Module = HwidGen.player.getYaw();
         this.SwapHelper = HwidGen.player.getPitch();
         Vec3d var1 = HwidGen.player.getCameraPosVec(1.0F);
         this.HwidGen.set(var1.x, var1.y, var1.z);
         this.KeyFile.set(var1.x, var1.y, var1.z);
         this.Module_j = this.Module;
         this.Module_ActiveModules = this.SwapHelper;
         this.Module_zelith = System.currentTimeMillis();
         this.c.set(0.0, 0.0, 0.0);
         this.Module_Configs = this.Module_j();
         HwidGen.player.setVelocity(0.0, HwidGen.player.getVelocity().y, 0.0);
         this.O = HwidGen.options.forwardKey.isPressed();
      } else {
         this.c();
      }
   }

   @Override
   public void Module_f() {
      if (HwidGen.player != null) {
         HwidGen.player.setYaw(this.Module_Friends);
         HwidGen.player.setPitch(this.Module_Hud);
         HwidGen.player.setHeadYaw(this.Module_Friends);
         HwidGen.player.setBodyYaw(this.Module_Friends);
      }

      if (this.HwidGen != null) {
         HwidGen.options.setPerspective(this.HwidGen);
      } else {
         HwidGen.options.setPerspective(Perspective.FIRST_PERSON);
      }

      HwidGen.chunkCullingEnabled = this.G;
      this.c.set(0.0, 0.0, 0.0);
      this.Module_Configs = this.Module_j();
      this.O = false;
   }

   @Override
   public void Category() {
      if (HwidGen.player != null) {
         HwidGen.player.setYaw(this.Module_Friends);
         HwidGen.player.setPitch(this.Module_Hud);
         HwidGen.player.setHeadYaw(this.Module_Friends);
         HwidGen.player.setBodyYaw(this.Module_Friends);
      }
   }

   public void Module_SpearSwap() {
      if (HwidGen.player != null) {
         this.KeyFile.set(this.HwidGen);
         this.Module_j = this.Module;
         this.Module_ActiveModules = this.SwapHelper;
         long var1 = System.currentTimeMillis();
         float var3 = (float)(var1 - this.Module_zelith) / 1000.0F;
         this.Module_zelith = var1;
         var3 = Math.min(var3, 0.1F);
         if (var3 < 0.001F) {
            var3 = 0.016F;
         }

         float var4 = (float)Math.toRadians(this.Module);
         double var5 = -Math.sin(var4);
         double var7 = Math.cos(var4);
         double var9 = -Math.cos(var4);
         double var11 = -Math.sin(var4);
         double var13 = 0.0;
         double var15 = 0.0;
         double var17 = 0.0;
         double var19 = this.Module_Configs * 2.0;
         if (HwidGen.options != null && HwidGen.options.sprintKey.isPressed()) {
            var19 *= 2.0;
         }

         if (HwidGen.options.forwardKey.isPressed()) {
            var13 += var5 * var19;
            var17 += var7 * var19;
         }

         if (HwidGen.options.backKey.isPressed()) {
            var13 -= var5 * var19;
            var17 -= var7 * var19;
         }

         if (HwidGen.options.rightKey.isPressed()) {
            var13 += var9 * var19;
            var17 += var11 * var19;
         }

         if (HwidGen.options.leftKey.isPressed()) {
            var13 -= var9 * var19;
            var17 -= var11 * var19;
         }

         if (HwidGen.options.jumpKey.isPressed()) {
            var15 += var19;
         }

         if (HwidGen.options.sneakKey.isPressed()) {
            var15 -= var19;
         }

         double var21 = 5.0;
         if (this.N) {
            double var23 = 1.0 - Math.pow(0.001, var3);
            this.c.Module_AutoInvTotem = MathHelper.lerp(var23, this.c.Module_AutoInvTotem, var13 * var21);
            this.c.Module_AutoTotem = MathHelper.lerp(var23, this.c.Module_AutoTotem, var15 * var21);
            this.c.Module_DoubleAnchor = MathHelper.lerp(var23, this.c.Module_DoubleAnchor, var17 * var21);
         } else {
            this.c.set(var13 * var21, var15 * var21, var17 * var21);
         }

         this.HwidGen.Module_AutoInvTotem = this.HwidGen.Module_AutoInvTotem + this.c.Module_AutoInvTotem * var3;
         this.HwidGen.Module_AutoTotem = this.HwidGen.Module_AutoTotem + this.c.Module_AutoTotem * var3;
         this.HwidGen.Module_DoubleAnchor = this.HwidGen.Module_DoubleAnchor + this.c.Module_DoubleAnchor * var3;
      }
   }

   public void KeyFile(double d, double e) {
      this.Module += (float)d;
      this.SwapHelper += (float)e;
      this.Module = MathHelper.wrapDegrees(this.Module);
      this.SwapHelper = MathHelper.clamp(this.SwapHelper, -90.0F, 90.0F);
   }

   public double HwidGen(float f) {
      return MathHelper.lerp(f, this.KeyFile.Module_AutoInvTotem, this.HwidGen.Module_AutoInvTotem);
   }

   public double KeyFile(float f) {
      return MathHelper.lerp(f, this.KeyFile.Module_AutoTotem, this.HwidGen.Module_AutoTotem);
   }

   public double c(float f) {
      return MathHelper.lerp(f, this.KeyFile.Module_DoubleAnchor, this.HwidGen.Module_DoubleAnchor);
   }

   public float KeyFile(float f) {
      return MathHelper.lerp(f, this.Module_j, this.Module);
   }

   public float c(float f) {
      return MathHelper.lerp(f, this.Module_ActiveModules, this.SwapHelper);
   }

   public float SwapHelper() {
      return this.ClickBuf;
   }

   public void HwidGen(double d) {
      if (d != 0.0) {
         float var3 = this.Module_Configs + (float)Math.signum(d) * 0.2F;
         this.Module_Configs = MathHelper.clamp(var3, 0.1F, 10.0F);
      }
   }

   private float Module_j() {
      return MathHelper.clamp((Float)this.Module_BlockESP.HwidGen(), 0.1F, 10.0F);
   }
}
