class Module_LightESP$2 extends Setting {
   Module_LightESP$2(cj arg, String string, Integer integer, Integer integer2, Integer integer3) {
      super(string, integer, integer2, integer3);
   }

   @Override
   public boolean LicenseResult(String string) {
      return super.LicenseResult(string) || "Chunk Radius".equalsIgnoreCase(string) || "RenderDistance".equalsIgnoreCase(string);
   }
}
