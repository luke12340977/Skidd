import java.util.List;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.client.toast.Toast.Visibility;
import net.minecraft.item.ItemStack;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

final class Toast_bf implements Toast {
   private static final Identifier LicenseResult = Identifier.ofVanilla("toast/advancement");
   private final Text LicenseState;
   private final Text Module_f;
   private final ItemStack c;
   private Visibility HwidGen = Visibility.HIDE;

   Toast_bf(Text text, Text text2, ItemStack itemStack) {
      this.LicenseState = text;
      this.Module_f = text2;
      this.c = itemStack;
   }

   public Visibility getVisibility() {
      return this.HwidGen;
   }

   public void update(ToastManager manager, long time) {
      this.HwidGen = time >= 5000.0 * manager.getNotificationDisplayTimeMultiplier() ? Visibility.HIDE : Visibility.SHOW;
   }

   public void draw(DrawContext context, TextRenderer textRenderer, long startTime) {
      context.drawGuiTexture(RenderPipelines.GUI_TEXTURED, LicenseResult, 0, 0, this.getWidth(), this.getHeight());
      context.drawText(textRenderer, this.LicenseState, 30, 7, -256, false);
      List var5 = textRenderer.wrapLines(this.Module_f, 125);
      if (!var5.isEmpty()) {
         context.drawText(textRenderer, (OrderedText)var5.getFirst(), 30, 18, -1, false);
      }

      context.drawItemWithoutEntity(this.c, 8, 8);
   }
}
