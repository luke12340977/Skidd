public final class Module_Sprint extends Module {
   private boolean K = false;

   public Module_Sprint() {
      super("Sprint", Category.HwidGen);
   }

   @Override
   public void LicenseState() {
      if (HwidGen != null && HwidGen.options != null) {
         this.K = this.F();
         this.c(false);
      }
   }

   @Override
   public void Module_f() {
      if (HwidGen != null && HwidGen.options != null) {
         this.c(this.K);

         try {
            HwidGen.options.sprintKey.setPressed(false);
         } catch (Throwable var2) {
         }
      }
   }

   @Override
   public void Category() {
      if (HwidGen != null && HwidGen.player != null && HwidGen.options != null) {
         this.c(false);

         try {
            HwidGen.options.sprintKey.setPressed(true);
         } catch (Throwable var2) {
         }
      }
   }

   private boolean F() {
      try {
         Object var1 = HwidGen.options.getClass().getMethod("getSprintToggled").invoke(HwidGen.options);
         return var1 == null ? false : var1.getClass().getMethod("getValue").invoke(var1) instanceof Boolean var3 && var3;
      } catch (Throwable var4) {
         return false;
      }
   }

   private void c(boolean bl) {
      try {
         Object var2 = HwidGen.options.getClass().getMethod("getSprintToggled").invoke(HwidGen.options);
         if (var2 == null) {
            return;
         }

         var2.getClass().getMethod("setValue", Object.class).invoke(var2, bl);
      } catch (Throwable var3) {
      }
   }
}
