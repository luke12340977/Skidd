import java.awt.Color;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.chunk.WorldChunk;

public final class Module_AmethystESP extends Module {
   private final dd bQ = new Setting("Sim Distance", 8.0F, 1.0F, 32.0F);
   private final dd bR = new Setting("Min Cluster Size", 3.0F, 1.0F, 20.0F);
   private final dd bS = new Setting("Chunk Y Level", 55.0F, -64.0F, 320.0F);
   private final dd bT = new Setting("Block ESP", true);
   private final dd bU = new Setting("Chunk Mark", true);
   private final dd bV = new Setting("Show Tracers", true);
   private final dd bW = new Setting("Chat Alert", true);
   private final dd bX = new Setting("ESP Color", new Color(180, 100, 255));
   private final dd bY = new Setting("Chunk Color", new Color(180, 100, 255));
   private static ce HwidGen;
   private final Map Module_Configs = new ConcurrentHashMap();
   private final Set Module_Configs = ConcurrentHashMap.newKeySet();
   private int Module_Themes;

   public Module_AmethystESP() {
      super("Amethyst ESP", Category.KeyFile);
      HwidGen = this;
      this.HwidGen(this.bQ);
      this.HwidGen(this.bR);
      this.HwidGen(this.bS);
      this.HwidGen(this.bT);
      this.HwidGen(this.bU);
      this.HwidGen(this.bV);
      this.HwidGen(this.bW);
      this.HwidGen(this.bX);
      this.HwidGen(this.bY);
   }

   @Override
   public void LicenseState() {
      this.Module_Configs.clear();
      this.Module_Configs.clear();
      this.Module_Themes = 0;
   }

   @Override
   public void Module_f() {
      this.Module_Configs.clear();
      this.Module_Configs.clear();
   }

   private void HwidGen(WorldChunk worldChunk) {
      if (HwidGen.world != null) {
         ChunkPos var2 = worldChunk.getPos();
         HashSet var3 = new HashSet();
         int var4 = var2.x << 4;
         int var5 = var2.z << 4;

         for (int var6 = 0; var6 < 16; var6++) {
            for (int var7 = 0; var7 < 16; var7++) {
               int var8 = var4 + var6;
               int var9 = var5 + var7;

               for (int var10 = -64; var10 <= 50; var10++) {
                  BlockPos var11 = new BlockPos(var8, var10, var9);
                  if (HwidGen.world.getLightLevel(LightType.BLOCK, var11) == 5 && this.c(var11)) {
                     var3.add(var11.toImmutable());
                  }
               }
            }
         }

         if (var3.size() >= ((Float)this.bR.HwidGen()).intValue()) {
            this.Module_Configs.put(var2, var3);
            if ((Boolean)this.bW.HwidGen() && this.Module_Configs.add(var2)) {
               this.ClickBuf("Amethyst Clusters on " + var2.getCenterX() + " " + var2.getCenterZ() + " §7(" + var3.size() + " hits)");
            }
         } else {
            this.Module_Configs.remove(var2);
            this.Module_Configs.remove(var2);
         }
      }
   }

   private boolean c(BlockPos blockPos) {
      for (int var2 = -1; var2 <= 1; var2++) {
         for (int var3 = -1; var3 <= 1; var3++) {
            for (int var4 = -1; var4 <= 1; var4++) {
               BlockState var5 = HwidGen.world.getBlockState(blockPos.add(var2, var3, var4));
               if (var5.isOf(Blocks.AMETHYST_CLUSTER)
                  || var5.isOf(Blocks.LARGE_AMETHYST_BUD)
                  || var5.isOf(Blocks.MEDIUM_AMETHYST_BUD)
                  || var5.isOf(Blocks.SMALL_AMETHYST_BUD)
                  || var5.isOf(Blocks.BUDDING_AMETHYST)
                  || var5.isOf(Blocks.AMETHYST_BLOCK)) {
                  return true;
               }
            }
         }
      }

      return false;
   }

   @Override
   public void Category() {
      if (HwidGen.world != null && HwidGen.player != null) {
         int var1 = ((Float)this.bQ.HwidGen()).intValue();
         ChunkPos var2 = HwidGen.player.getChunkPos();
         int var3 = var1 * 2 + 1;
         int var4 = var3 * var3;

         for (int var5 = 0; var5 < 8; var5++) {
            int var6 = this.Module_Themes % var4;
            this.Module_Themes = (this.Module_Themes + 1) % var4;
            int var7 = var6 % var3 - var1;
            int var8 = var6 / var3 - var1;
            WorldChunk var9 = HwidGen.world.getChunkManager().getWorldChunk(var2.x + var7, var2.z + var8, false);
            if (var9 != null) {
               this.HwidGen(var9);
            }
         }
      }
   }

   @Override
   public void HwidGen(MatrixStack matrixStack, float f) {
      if (HwidGen.world != null && HwidGen.player != null && !this.Module_Configs.isEmpty()) {
         Camera var3 = Render_dm.HwidGen();
         if (var3 != null) {
            Vec3d var4 = Render_dm.HwidGen(var3);
            Vec3d var5 = Render_dm.KeyFile(var3);
            Vec3d var6 = Render_dm.c(var3);
            Vec3d var7 = Render_dm.HwidGen(var5, var6);
            Vec3d var8 = var5.multiply(150.0);
            Color var9 = this.HwidGen((Color)this.bX.HwidGen(), 180);
            Color var10 = this.HwidGen((Color)this.bY.HwidGen(), 200);
            Color var11 = this.HwidGen((Color)this.bX.HwidGen(), 220);
            matrixStack.push();
            do var12 = Render_dm.HwidGen(matrixStack);
            double var13 = ((Float)this.bS.HwidGen()).doubleValue();

            for (Entry var16 : this.Module_Configs.entrySet()) {
               ChunkPos var17 = (ChunkPos)var16.getKey();
               Set var18 = (Set)var16.getValue();
               if (!var18.isEmpty()) {
                  if ((Boolean)this.bU.HwidGen()) {
                     double var19 = var17.getStartX() - var4.x;
                     double var21 = var17.getStartZ() - var4.z;
                     double var23 = var17.getEndX() - var4.x + 1.0;
                     double var25 = var17.getEndZ() - var4.z + 1.0;
                     double var27 = var13 - var4.y;
                     double var29 = var27 + 0.05;
                     var12.HwidGen(var19, var27, var21, var23, var29, var25, var10);
                  }

                  if ((Boolean)this.bT.HwidGen()) {
                     for (BlockPos var20 : var18) {
                        double var34 = var20.getX() - var4.x;
                        double var36 = var20.getY() - var4.y;
                        double var39 = var20.getZ() - var4.z;
                        var12.HwidGen(var34, var36, var39, var34 + 1.0, var36 + 1.0, var39 + 1.0, var9);
                     }
                  }

                  if ((Boolean)this.bV.HwidGen()) {
                     BlockPos var32 = null;
                     double var33 = Double.MAX_VALUE;

                     for (BlockPos var37 : var18) {
                        double var24 = var37.getSquaredDistance(HwidGen.player.getBlockPos());
                        if (var24 < var33) {
                           var33 = var24;
                           var32 = var37;
                        }
                     }

                     if (var32 != null) {
                        Vec3d var35 = new Vec3d(var32.getX() + 0.5 - var4.x, var32.getY() + 0.5 - var4.y, var32.getZ() + 0.5 - var4.z);
                        Vec3d var38 = Render_dm.HwidGen(var35, var5, var6, var7, 24.0, 2.75);
                        var12.HwidGen(var11, var8, var38, Module_zelith.KeyFile());
                     }
                  }
               }
            }

            var12.Module_FakePay();
            matrixStack.pop();
         }
      }
   }

   private Color HwidGen(Color color, int i) {
      return new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.min(255, i));
   }

   private void ClickBuf(String string) {
      if (HwidGen.player != null) {
         HwidGen.player.sendMessage(Text.literal("§d[AmethystESP] §f" + string), false);
      }
   }
}
