public final class Module_SwingSpeed extends Module {
   public static ca HwidGen;
   private final dd bJ = new Setting("Swing Speed", 1.0F, 0.1F, 2.0F);

   public Module_SwingSpeed() {
      super("Swing Speed", Category.HwidGen);
      HwidGen = this;
      this.HwidGen(this.bJ);
   }

   public float Module() {
      float var1 = this.bJ.HwidGen() == null ? 1.0F : (Float)this.bJ.HwidGen();
      return var1 < 0.1F ? 0.1F : Math.min(var1, 2.0F);
   }
}
