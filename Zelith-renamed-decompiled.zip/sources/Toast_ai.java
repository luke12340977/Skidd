import java.util.List;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import net.minecraft.client.toast.Toast.Visibility;
import net.minecraft.item.ItemStack;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

final class Toast_ai implements Toast {
   private static final Identifier KeyFile = Identifier.ofVanilla("toast/advancement");
   private final Text HwidGen;
   private final Text KeyFile;
   private final ItemStack HwidGen;
   private Visibility HwidGen = Visibility.HIDE;

   Toast_ai(Text text, Text text2, ItemStack itemStack) {
      this.HwidGen = text;
      this.KeyFile = text2;
      this.HwidGen = itemStack;
   }

   public Visibility getVisibility() {
      return this.HwidGen;
   }

   public void update(ToastManager manager, long time) {
      this.HwidGen = time >= 5000.0 * manager.getNotificationDisplayTimeMultiplier() ? Visibility.HIDE : Visibility.SHOW;
   }

   public void draw(DrawContext context, TextRenderer textRenderer, long startTime) {
      context.drawGuiTexture(RenderPipelines.GUI_TEXTURED, KeyFile, 0, 0, this.getWidth(), this.getHeight());
      context.drawText(textRenderer, this.HwidGen, 30, 7, -256, false);
      List var5 = textRenderer.wrapLines(this.KeyFile, 125);
      if (!var5.isEmpty()) {
         context.drawText(textRenderer, (OrderedText)var5.getFirst(), 30, 18, -1, false);
      }

      context.drawItemWithoutEntity(this.HwidGen, 8, 8);
   }
}
