import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.UniformType;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;

public class Shader_ds {
   private static RenderPipeline HwidGen;
   private static GpuBuffer HwidGen;

   public static void Module() {
      if (HwidGen == null) {
         try {
            HwidGen = RenderPipeline.builder(new Snippet[0])
               .withLocation(Identifier.of("zelith", "outline"))
               .withVertexShader(Identifier.of("zelith", "outline_vertex"))
               .withFragmentShader(Identifier.of("zelith", "outline_fragment"))
               .withVertexFormat(VertexFormat.builder().build(), DrawMode.TRIANGLES)
               .withUniform("Uniforms", UniformType.UNIFORM_BUFFER)
               .withBlend(BlendFunction.TRANSLUCENT)
               .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
               .withCull(false)
               .build();
            HwidGen = RenderSystem.getDevice().createBuffer(() -> "Outline2D Uniforms", 136, 256L);
         } catch (Exception var1) {
            System.err.println("[Outline2D] Failed to init: " + var1.getMessage());
            var1.printStackTrace();
         }
      }
   }

   public static void HwidGen(Matrix4f matrix4f, float f, float g, float h, float i, float j, float k, float l, float m, float n, float o, int... is) {
      if (HwidGen == null) {
         Module();
      }

      if (HwidGen != null && HwidGen != null) {
         int[] var12 = HwidGen(is);
         ByteBuffer var13 = MemoryUtil.memAlloc(256);
         var13.putFloat(matrix4f.m00()).putFloat(matrix4f.m01()).putFloat(matrix4f.m02()).putFloat(matrix4f.m03());
         var13.putFloat(matrix4f.m10()).putFloat(matrix4f.m11()).putFloat(matrix4f.m12()).putFloat(matrix4f.m13());
         var13.putFloat(matrix4f.m20()).putFloat(matrix4f.m21()).putFloat(matrix4f.m22()).putFloat(matrix4f.m23());
         var13.putFloat(matrix4f.m30()).putFloat(matrix4f.m31()).putFloat(matrix4f.m32()).putFloat(matrix4f.m33());
         var13.position(64);
         var13.putFloat(f).putFloat(g).putFloat(h).putFloat(i);
         var13.putFloat(k).putFloat(l).putFloat(j).putFloat(m);
         var13.position(96);
         var13.putFloat(n).putFloat(o).putFloat(0.0F).putFloat(0.0F);
         var13.position(112);

         for (int var14 = 0; var14 < 9; var14++) {
            int var15 = var12[var14];
            var13.putFloat((var15 >> 16 & 0xFF) / 255.0F);
            var13.putFloat((var15 >> 8 & 0xFF) / 255.0F);
            var13.putFloat((var15 & 0xFF) / 255.0F);
            var13.putFloat((var15 >> 24 & 0xFF) / 255.0F);
         }

         var13.flip();
         CommandEncoder var21 = RenderSystem.getDevice().createCommandEncoder();
         var21.writeToBuffer(HwidGen.slice(), var13);
         MemoryUtil.memFree(var13);
         Framebuffer var22 = MinecraftClient.getInstance().getFramebuffer();
         RenderPass var16 = var21.createRenderPass(
            () -> "Outline2D", var22.getColorAttachmentView(), OptionalInt.empty(), var22.getDepthAttachmentView(), OptionalDouble.of(1.0)
         );

         try {
            Obj_dr.HwidGen(var16);
            var16.setPipeline(HwidGen);
            var16.setUniform("Uniforms", HwidGen);
            var16.draw(0, 6);
         } catch (Throwable var20) {
            if (var16 != null) {
               try {
                  var16.close();
               } catch (Throwable var19) {
                  var20.addSuppressed(var19);
               }
            }

            throw var20;
         }

         if (var16 != null) {
            var16.close();
         }
      }
   }

   private static int[] HwidGen(int[] is) {
      if (is.length == 1) {
         int var3 = is[0];
         return new int[]{var3, var3, var3, var3, var3, var3, var3, var3, var3};
      } else if (is.length >= 9) {
         return is;
      } else {
         int[] var1 = new int[9];

         for (int var2 = 0; var2 < 9; var2++) {
            var1[var2] = var2 < is.length ? is[var2] : is[is.length - 1];
         }

         return var1;
      }
   }
}
