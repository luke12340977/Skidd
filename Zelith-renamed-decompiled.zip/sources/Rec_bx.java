import java.util.UUID;
import net.minecraft.entity.player.PlayerSkinType;

record Rec_bx() {
   private final String B;
   private final UUID HwidGen;
   private final String C;
   private final PlayerSkinType HwidGen;

   Rec_bx(String string, UUID uUID, String string2, PlayerSkinType playerSkinType) {
      this.B = string;
      this.HwidGen = uUID;
      this.C = string2;
      this.HwidGen = playerSkinType;
   }

   public String Module_ActiveModules() {
      return this.B;
   }

   public UUID KeyFile() {
      return this.HwidGen;
   }

   public String Module_AnchorMacro() {
      return this.C;
   }
}
