import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

public final class SettingItem extends Setting {
   private final List SwapHelper = Registries.ITEM
      .stream()
      .filter(itemx -> itemx != Items.AIR)
      .sorted(Comparator.comparing(this::HwidGen, String.CASE_INSENSITIVE_ORDER))
      .toList();
   private long Module_AutoDoubleHand;

   public SettingItem(String string, Item item) {
      super(string, item != null ? item : Items.AIR);
   }

   public void KeyFile(Item item) {
      super.HwidGen(item != null ? item : Items.AIR);
      this.Module_AutoDoubleHand++;
   }

   public Item HwidGen() {
      return (Item)this.HwidGen();
   }

   public void c(Item item) {
      this.KeyFile(item);
   }

   public List KeyFile(String string) {
      String var2 = string == null ? "" : string.trim().toLowerCase(Locale.ROOT);
      if (var2.isEmpty()) {
         return this.SwapHelper;
      } else {
         ArrayList var3 = new ArrayList();

         for (Item var5 : this.SwapHelper) {
            String var6 = this.HwidGen(var5).toLowerCase(Locale.ROOT);
            Identifier var7 = Registries.ITEM.getId(var5);
            String var8 = var7 == null ? "" : var7.toString().toLowerCase(Locale.ROOT);
            if (var6.contains(var2) || var8.contains(var2)) {
               var3.add(var5);
            }
         }

         return var3;
      }
   }

   public String HwidGen(Item item) {
      try {
         return item.getName().getString();
      } catch (Exception var4) {
         Identifier var3 = Registries.ITEM.getId(item);
         return var3 == null ? "Item" : var3.getPath();
      }
   }

   public String Module_AutoCrystal() {
      Item var1 = (Item)this.HwidGen();
      return var1 != null && var1 != Items.AIR ? this.HwidGen(var1) : "None";
   }
}
