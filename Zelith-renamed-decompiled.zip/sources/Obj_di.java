import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.OrderedText;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Style;

public final class Obj_di {
   public static String Module_ActiveModules(String string) {
      if (string != null && Module_f()) {
         String var1 = D();
         String var2 = Module_zelith();
         if (var1 != null && var2 != null && !var1.isBlank() && !var1.equals(var2)) {
            return string.contains(var1) ? string.replace(var1, var2) : string;
         } else {
            return string;
         }
      } else {
         return string;
      }
   }

   public static StringVisitable HwidGen(StringVisitable stringVisitable) {
      if (stringVisitable != null && Module_f()) {
         List var1 = HwidGen(HwidGen(stringVisitable));
         if (var1 == null) {
            return stringVisitable;
         } else if (var1.isEmpty()) {
            return StringVisitable.EMPTY;
         } else {
            ArrayList var2 = new ArrayList(var1.size());

            for (Rec_dj var4 : var1) {
               var2.add(StringVisitable.styled(var4.E(), var4.HwidGen()));
            }

            return StringVisitable.concat(var2);
         }
      } else {
         return stringVisitable;
      }
   }

   public static OrderedText HwidGen(OrderedText orderedText) {
      if (orderedText != null && Module_f()) {
         List var1 = HwidGen(HwidGen(orderedText));
         if (var1 == null) {
            return orderedText;
         } else if (var1.isEmpty()) {
            return OrderedText.empty();
         } else {
            ArrayList var2 = new ArrayList(var1.size());

            for (Rec_dj var4 : var1) {
               var2.add(OrderedText.styledForwardsVisitedString(var4.E(), var4.HwidGen()));
            }

            return OrderedText.concat(var2);
         }
      } else {
         return orderedText;
      }
   }

   private static boolean Module_f() {
      return Module_NameProtect.HwidGen != null && Module_NameProtect.HwidGen.HwidGen() && D() != null && !D().isBlank();
   }

   private static String D() {
      MinecraftClient var0 = MinecraftClient.getInstance();
      return var0 != null && var0.getSession() != null ? var0.getSession().getUsername() : null;
   }

   private static String Module_zelith() {
      return Module_NameProtect.HwidGen == null ? null : Module_NameProtect.HwidGen.Module_zelith();
   }

   private static List HwidGen(StringVisitable stringVisitable) {
      ArrayList var1 = new ArrayList();
      stringVisitable.visit((style, string) -> {
         HwidGen(var1, string, style);
         return Optional.empty();
      }, Style.EMPTY);
      return var1;
   }

   private static List HwidGen(OrderedText orderedText) {
      ArrayList var1 = new ArrayList();
      orderedText.accept((i, style, j) -> {
         var1.add(new Rec_dj(new String(Character.toChars(j)), style));
         return true;
      });
      return var1;
   }

   private static void HwidGen(List list, String string, Style style) {
      if (string != null && !string.isEmpty()) {
         int var3 = 0;

         while (var3 < string.length()) {
            int var4 = string.codePointAt(var3);
            list.add(new Rec_dj(new String(Character.toChars(var4)), style));
            var3 += Character.charCount(var4);
         }
      }
   }

   private static List HwidGen(List list) {
      String var1 = D();
      String var2 = Module_zelith();
      if (var1 != null && var2 != null && !var1.isBlank() && !var1.equals(var2)) {
         StringBuilder var3 = new StringBuilder();
         ArrayList var4 = new ArrayList(list.size());

         for (Rec_dj var6 : list) {
            var4.add(var3.length());
            var3.append(var6.E());
         }

         String var12 = var3.toString();
         if (!var12.contains(var1)) {
            return null;
         } else {
            ArrayList var13 = new ArrayList();
            int var7 = 0;
            int var8 = 0;

            int var9;
            while ((var9 = var12.indexOf(var1, var8)) >= 0) {
               while (var7 < list.size() && var4.get(var7) < var9) {
                  var13.add((Rec_dj)list.get(var7++));
               }

               Style var10 = var7 < list.size() ? ((Rec_dj)list.get(var7)).HwidGen() : Style.EMPTY;
               var13.add(new Rec_dj(var2, var10));
               int var11 = var9 + var1.length();

               while (var7 < list.size() && var4.get(var7) < var11) {
                  var7++;
               }

               var8 = var11;
            }

            while (var7 < list.size()) {
               var13.add((Rec_dj)list.get(var7++));
            }

            return KeyFile(var13);
         }
      } else {
         return null;
      }
   }

   private static List KeyFile(List list) {
      if (list.isEmpty()) {
         return list;
      } else {
         ArrayList var1 = new ArrayList(list.size());
         Rec_dj var2 = (Rec_dj)list.getFirst();

         for (int var3 = 1; var3 < list.size(); var3++) {
            Rec_dj var4 = (Rec_dj)list.get(var3);
            if (Objects.equals(var2.HwidGen(), var4.HwidGen())) {
               var2 = new Rec_dj(var2.E() + var4.E(), var2.HwidGen());
            } else {
               var1.add(var2);
               var2 = var4;
            }
         }

         var1.add(var2);
         return var1;
      }
   }
}
