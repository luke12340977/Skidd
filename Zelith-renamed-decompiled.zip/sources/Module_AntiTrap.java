import java.util.ArrayList;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.Entity.RemovalReason;

public final class Module_AntiTrap extends Module {
   private final dd Module_ShieldBreaker = new Setting("Armor Stands", true);
   private final dd Module_SpearSwap = new Setting("Minecarts", true);
   private final dd Module_Triggerbot = new Setting("Chest Minecarts", true);
   private final dd Module_ActivityFinder = new Setting("Hopper Minecarts", true);

   public Module_AntiTrap() {
      super("Anti Trap", Category.LicenseState);
      this.HwidGen(this.Module_ShieldBreaker);
      this.HwidGen(this.Module_SpearSwap);
      this.HwidGen(this.Module_Triggerbot);
      this.HwidGen(this.Module_ActivityFinder);
   }

   @Override
   public void LicenseState() {
      this.Module_AutoTotem();
   }

   @Override
   public void Category() {
      this.Module_AutoTotem();
   }

   private void Module_AutoTotem() {
      if (HwidGen.world != null) {
         ArrayList var1 = new ArrayList();
         HwidGen.world.getEntities().forEach(entity -> {
            if (entity != null && this.HwidGen(entity.getType())) {
               var1.add(entity);
            }
         });
         var1.forEach(entity -> {
            if (!entity.isRemoved()) {
               entity.remove(RemovalReason.DISCARDED);
            }
         });
      }
   }

   private boolean HwidGen(EntityType entityType) {
      if (entityType == null) {
         return false;
      } else if ((Boolean)this.Module_ShieldBreaker.HwidGen() && entityType.equals(EntityType.ARMOR_STAND)) {
         return true;
      } else if ((Boolean)this.Module_SpearSwap.HwidGen() && entityType.equals(EntityType.MINECART)) {
         return true;
      } else {
         return this.Module_Triggerbot.HwidGen() && entityType.equals(EntityType.CHEST_MINECART)
            ? true
            : (Boolean)this.Module_ActivityFinder.HwidGen() && entityType.equals(EntityType.HOPPER_MINECART);
      }
   }
}
