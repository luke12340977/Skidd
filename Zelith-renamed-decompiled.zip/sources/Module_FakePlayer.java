import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.client.network.OtherClientPlayerEntity;

public final class Module_FakePlayer extends Module {
   private final dd Module_NameProtect = new Setting("Name", "FakePlayer");
   private OtherClientPlayerEntity HwidGen;

   public Module_FakePlayer() {
      super("Fake Player", Category.HwidGen);
      this.HwidGen(this.Module_NameProtect);
   }

   @Override
   public void LicenseState() {
      if (HwidGen.world != null && HwidGen.player != null) {
         GameProfile var1 = new GameProfile(UUID.randomUUID(), (String)this.Module_NameProtect.HwidGen());
         this.HwidGen = new OtherClientPlayerEntity(HwidGen.world, var1);
         this.HwidGen
            .refreshPositionAndAngles(HwidGen.player.getX(), HwidGen.player.getY(), HwidGen.player.getZ(), HwidGen.player.getYaw(), HwidGen.player.getPitch());
         this.HwidGen.setBodyYaw(HwidGen.player.getBodyYaw());
         this.HwidGen.setHeadYaw(HwidGen.player.getHeadYaw());
         HwidGen.world.addEntity(this.HwidGen);
      }
   }

   @Override
   public void Module_f() {
      if (this.HwidGen != null) {
         this.HwidGen.discard();
         this.HwidGen = null;
      }
   }
}
