import java.util.List;

public final class Settingdb extends Setting {
   private final String H;
   private final List Module_Friends;

   public List Module_f() {
      return this.Module_Friends;
   }

   public void Module_Hud(String string) {
      if (string == null) {
         this.F();
      } else {
         for (Rec_cz var3 : this.Module_Friends) {
            if (var3.Module_AutoDoubleHand().equalsIgnoreCase(string)) {
               this.HwidGen(var3.Module_AutoDoubleHand());
               return;
            }
         }
      }
   }

   public void F() {
      this.HwidGen(this.H);
   }

   public boolean HwidGen(cz arg) {
      return arg != null && this.HwidGen() != null && arg.Module_AutoDoubleHand().equalsIgnoreCase((String)this.HwidGen());
   }

   public cz HwidGen() {
      for (Rec_cz var2 : this.Module_Friends) {
         if (this.HwidGen(var2)) {
            return var2;
         }
      }

      return this.Module_Friends.isEmpty() ? null : (Rec_cz)this.Module_Friends.getFirst();
   }

   public String Module_AutoCrystal() {
      cz var1 = this.HwidGen();
      return var1 == null ? "Choose" : var1.Module_AutoInvTotem();
   }
}
