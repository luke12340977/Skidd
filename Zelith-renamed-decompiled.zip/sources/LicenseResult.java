public final class LicenseResult {
   public final e HwidGen;
   public final String KeyFile;
   public final String c;
   public final String LicenseResult;

   public LicenseResult(e arg, String string, String string2, String string3) {
      this.HwidGen = arg;
      this.KeyFile = string;
      this.c = string2;
      this.LicenseResult = string3;
   }

   public static d HwidGen() {
      return new LicenseResult(LicenseState.LicenseResult, null, null, null);
   }

   public static d HwidGen(String string) {
      return new LicenseResult(LicenseState.c, null, null, string);
   }

   public static d LicenseResult(String string, String string2) {
      return new LicenseResult(LicenseState.KeyFile, string, string2, null);
   }
}
