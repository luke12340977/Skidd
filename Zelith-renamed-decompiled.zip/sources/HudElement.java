public enum HudElement {
   HwidGen("Watermark"),
   KeyFile("Coordinates"),
   c("Info"),
   LicenseResult("Module List"),
   LicenseState("Potion Effects"),
   Module_f("Armor"),
   Category("Keybinds"),
   Module("Spotify HUD");

   public final String Category;

   public static p[] values() {
      return (p[])HwidGen.clone();
   }

   public static p valueOf(String string) {
      return Enum.valueOf(HudElement.class, string);
   }

   private HudElement(String string2) {
      this.Category = string2;
   }
}
