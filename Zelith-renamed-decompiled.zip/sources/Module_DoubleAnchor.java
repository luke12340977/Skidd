import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.HealthUpdateS2CPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;

public final class Module_DoubleAnchor extends Module_f {
   private final dd M = new Setting("Delay", 0.0F, 0.0F, 20.0F);
   private final dd N = new Setting("Totem Slot", 1.0F, 1.0F, 9.0F);
   private final dd O = new Setting("Switch Back", false);
   private int ClickBuf = 0;
   private int Module_Configs = 0;
   private boolean Module_Friends = false;
   private BlockPos HwidGen = null;
   private boolean Module_ActiveModules = false;

   public Module_DoubleAnchor() {
      super("Double Anchor", Category.c);
      this.HwidGen(this.M);
      this.HwidGen(this.N);
      this.HwidGen(this.O);
   }

   @Override
   public void LicenseState() {
      this.Module_AutoCrystal();
      this.Module_Friends = false;
      this.Module_ActiveModules = false;
      this.HwidGen = null;
      super.LicenseState();
   }

   @Override
   public void Module_f() {
      this.Module_AutoCrystal();
      this.Module_Friends = false;
      this.Module_ActiveModules = false;
      this.HwidGen = null;
      super.Module_f();
   }

   @Override
   public void LicenseResult() {
      super.LicenseResult();
   }

   @Override
   public void KeyFile() {
      if (this.HwidGen()) {
         this.Module_AutoCrystal();
         this.Module_Friends = true;
         this.Module_ActiveModules = false;
         this.HwidGen = null;
      }
   }

   @Override
   public void HwidGen(Packet packet) {
      if ((Boolean)this.O.HwidGen() && this.Module_ActiveModules && packet instanceof HealthUpdateS2CPacket) {
         this.Module_ActiveModules = false;
         if (HwidGen.player != null) {
            int var2 = this.c(Items.RESPAWN_ANCHOR);
            if (var2 != -1) {
               HwidGen.player.getInventory().setSelectedSlot(var2);
            }
         }
      }
   }

   @Override
   public void Category() {
      if (this.Module_Friends) {
         if (HwidGen.currentScreen == null) {
            if (HwidGen.player != null && HwidGen.world != null) {
               if (!this.ClickBuf()) {
                  this.Module_Friends = false;
                  this.Module_AutoCrystal();
               } else if (HwidGen.crosshairTarget instanceof BlockHitResult var1) {
                  if (HwidGen.world.getBlockState(var1.getBlockPos()).isOf(Blocks.AIR)) {
                     this.Module_Friends = false;
                     this.Module_AutoCrystal();
                  } else {
                     int var4 = Math.max(0, ((Float)this.M.HwidGen()).intValue());
                     if (this.ClickBuf < var4) {
                        this.ClickBuf++;
                     } else {
                        if (this.Module_Configs == 0) {
                           this.HwidGen(Items.RESPAWN_ANCHOR);
                        } else if (this.Module_Configs == 1) {
                           this.LicenseResult(var1);
                        } else if (this.Module_Configs == 2) {
                           this.HwidGen(Items.GLOWSTONE);
                        } else if (this.Module_Configs == 3) {
                           this.LicenseResult(var1);
                        } else if (this.Module_Configs == 4) {
                           this.HwidGen(Items.RESPAWN_ANCHOR);
                        } else if (this.Module_Configs == 5) {
                           this.LicenseResult(var1);
                           this.LicenseResult(var1);
                        } else if (this.Module_Configs == 6) {
                           this.HwidGen(Items.GLOWSTONE);
                        } else if (this.Module_Configs == 7) {
                           this.LicenseResult(var1);
                        } else if (this.Module_Configs == 8) {
                           int var3 = ((Float)this.N.HwidGen()).intValue() - 1;
                           this.LicenseState(var3);
                           this.HwidGen = var1.getBlockPos();
                        } else if (this.Module_Configs == 9) {
                           this.LicenseResult(var1);
                           if ((Boolean)this.O.HwidGen()) {
                              this.Module_ActiveModules = true;
                           }
                        } else if (this.Module_Configs == 10) {
                           this.Module_Friends = false;
                           this.Module_AutoCrystal();
                           return;
                        }

                        this.Module_Configs++;
                     }
                  }
               } else {
                  this.Module_Friends = false;
                  this.Module_AutoCrystal();
               }
            }
         }
      }
   }

   private void Module_AutoCrystal() {
      this.ClickBuf = 0;
      this.Module_Configs = 0;
   }

   private boolean ClickBuf() {
      boolean var1 = false;
      boolean var2 = false;

      for (int var3 = 0; var3 < 9; var3++) {
         ItemStack var4 = HwidGen.player.getInventory().getStack(var3);
         if (var4.isOf(Items.RESPAWN_ANCHOR)) {
            var1 = true;
         }

         if (var4.isOf(Items.GLOWSTONE)) {
            var2 = true;
         }
      }

      return var1 && var2;
   }

   private int c(Item item) {
      for (int var2 = 0; var2 < 9; var2++) {
         if (HwidGen.player.getInventory().getStack(var2).isOf(item)) {
            return var2;
         }
      }

      return -1;
   }

   private void HwidGen(Item item) {
      int var2 = this.c(item);
      if (var2 != -1) {
         HwidGen.player.getInventory().setSelectedSlot(var2);
      }
   }

   private void LicenseState(int i) {
      if (i >= 0 && i <= 8) {
         HwidGen.player.getInventory().setSelectedSlot(i);
      }
   }

   private void LicenseResult(BlockHitResult blockHitResult) {
      HwidGen.interactionManager.interactBlock(HwidGen.player, Hand.MAIN_HAND, blockHitResult);
      HwidGen.player.swingHand(Hand.MAIN_HAND);
   }
}
