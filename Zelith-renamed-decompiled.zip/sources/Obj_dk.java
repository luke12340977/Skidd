import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.text.Text;

public final class Obj_dk {
   private static final Set Module_zelith = Collections.newSetFromMap(new WeakHashMap());

   public static void HwidGen(EntityRenderState entityRenderState) {
      Module_zelith.remove(entityRenderState);
   }

   public static void KeyFile(EntityRenderState entityRenderState) {
      Module_zelith.add(entityRenderState);
   }

   public static boolean HwidGen(EntityRenderState entityRenderState) {
      return Module_zelith.contains(entityRenderState);
   }

   public static boolean KeyFile(Text text) {
      return false;
   }
}
