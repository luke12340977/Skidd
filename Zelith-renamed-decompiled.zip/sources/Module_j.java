public class Module_j extends Module {
   public Module_j(String string, g arg) {
      super(string, arg);
   }
}
