import java.awt.Color;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.passive.AllayEntity;
import net.minecraft.entity.passive.AxolotlEntity;
import net.minecraft.entity.passive.CamelEntity;
import net.minecraft.entity.passive.ChickenEntity;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.entity.passive.GoatEntity;
import net.minecraft.entity.passive.IronGolemEntity;
import net.minecraft.entity.passive.LlamaEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.entity.passive.RabbitEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.entity.passive.SnifferEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.vehicle.ChestMinecartEntity;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

public final class Module_EntityScanner extends Module {
   private static final Set LicenseResult = new HashSet();
   private final dd Module_ChunkFinder = new Setting("Threshold", 10, 1, 500);
   private final dd Toast_an = new Setting("Max Notify", 3, 1, 10);
   private final Map Module = new ConcurrentHashMap();
   private int Module_Themes;

   public Module_EntityScanner() {
      super("Entity Scanner", Category.LicenseState);
      this.HwidGen(this.Module_ChunkFinder);
      this.HwidGen(this.Toast_an);
   }

   @Override
   public void LicenseState() {
      this.Module.clear();
      this.Module_Themes = 0;
   }

   @Override
   public void Module_f() {
      this.Module.clear();
      this.Module_Themes = 0;
   }

   @Override
   public void Category() {
      if (HwidGen.world != null && HwidGen.player != null) {
         int var1 = HwidGen.options.getClampedViewDistance();
         ChunkPos var2 = HwidGen.player.getChunkPos();
         int var3 = var1 * 2 + 1;
         int var4 = var3 * var3;

         for (int var5 = 0; var5 < 8; var5++) {
            int var6 = this.Module_Themes % var4;
            this.Module_Themes = (this.Module_Themes + 1) % var4;
            int var7 = var6 % var3 - var1;
            int var8 = var6 / var3 - var1;
            int var9 = var2.x + var7;
            int var10 = var2.z + var8;
            WorldChunk var11 = HwidGen.world.getChunkManager().getWorldChunk(var9, var10, false);
            if (var11 != null && !var11.isEmpty()) {
               ChunkPos var12 = new ChunkPos(var9, var10);
               double var13 = this.HwidGen(var11, var12);
               this.Module.put(var12, var13);
            }
         }

         this.Module.keySet().removeIf(chunkPos2 -> this.HwidGen(chunkPos2, var2, var1));
      }
   }

   private double HwidGen(WorldChunk worldChunk, ChunkPos chunkPos) {
      double var3 = 0.0;

      for (Entity var6 : HwidGen.world.getEntities()) {
         if (!var6.isRemoved()) {
            ChunkPos var7 = var6.getChunkPos();
            if (var7.equals(chunkPos)) {
               Class var8 = var6.getClass();
               if (LicenseResult.contains(var8)) {
                  if (var6 instanceof PassiveEntity) {
                     var3 += 5.0;
                  }

                  if (var6 instanceof ArmorStandEntity) {
                     var3 += 8.0;
                  }

                  if (var6 instanceof ItemFrameEntity) {
                     var3 += 6.0;
                  }

                  if (var6 instanceof VillagerEntity) {
                     var3 += 10.0;
                  }

                  if (var6 instanceof IronGolemEntity) {
                     var3 += 12.0;
                  }

                  if (var6 instanceof AllayEntity) {
                     var3 += 15.0;
                  }

                  if (var6 instanceof ChestMinecartEntity) {
                     var3 += 20.0;
                  }
               }
            }
         }
      }

      return Math.min(var3, 100.0);
   }

   @Override
   public void HwidGen(MatrixStack matrixStack, float f) {
      if (HwidGen.world != null && HwidGen.player != null && !this.Module.isEmpty()) {
         Camera var3 = Render_dm.HwidGen();
         if (var3 != null) {
            Vec3d var4 = Render_dm.HwidGen(var3);
            matrixStack.push();
            do var5 = Render_dm.HwidGen(matrixStack);

            for (Entry var7 : this.Module.entrySet()) {
               ChunkPos var8 = (ChunkPos)var7.getKey();
               double var9 = (Double)var7.getValue();
               if (!(var9 < 1.0)) {
                  Color var11 = this.HwidGen(var9);
                  double var12 = var8.getStartX() - var4.x;
                  double var14 = var8.getStartZ() - var4.z;
                  double var16 = var12 + 16.0;
                  double var18 = var14 + 16.0;
                  double var20 = 55.0 - var4.y;
                  double var22 = var20 + 0.05;
                  var5.HwidGen(var12, var20, var14, var16, var22, var18, var11);
               }
            }

            var5.Module_FakePay();
            matrixStack.pop();
         }
      }
   }

   private Color HwidGen(double d) {
      double var3 = Math.min(d / 100.0, 1.0);
      short var5 = 255;
      int var6 = (int)(255.0 * (1.0 - var3));
      byte var7 = 0;
      short var8 = 150;
      return new Color(var5, var6, var7, var8);
   }

   private boolean HwidGen(ChunkPos chunkPos, ChunkPos chunkPos2, int i) {
      return Math.abs(chunkPos.x - chunkPos2.x) > i || Math.abs(chunkPos.z - chunkPos2.z) > i;
   }

   static {
      LicenseResult.addAll(
         Set.of(
            PigEntity.class,
            CowEntity.class,
            SheepEntity.class,
            ChickenEntity.class,
            RabbitEntity.class,
            VillagerEntity.class,
            IronGolemEntity.class,
            AllayEntity.class,
            AxolotlEntity.class,
            GoatEntity.class,
            LlamaEntity.class,
            CamelEntity.class,
            SnifferEntity.class,
            ArmorStandEntity.class,
            ItemFrameEntity.class,
            ChestMinecartEntity.class
         )
      );
   }
}
