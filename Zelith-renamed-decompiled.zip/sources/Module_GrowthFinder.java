import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PointedDripstoneBlock;
import net.minecraft.block.SweetBerryBushBlock;
import net.minecraft.block.VineBlock;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.Heightmap.Type;
import net.minecraft.world.chunk.WorldChunk;

public final class Module_GrowthFinder extends Module {
   private final dd aA = new Setting("Render Vines", true);
   private final dd aB = new Setting("Render Dripstone", true);
   private final dd aC = new Setting("Render Berries", true);
   private final dd aD = new Setting("Render Gray Chunks", true);
   private final dd aE = new Setting("Alpha", 80.0F, 0.0F, 255.0F);
   private static final Color LicenseResult = new Color(135, 135, 135);
   private static final Color LicenseState = new Color(100, 100, 100);
   private static final Color Module_f = new Color(203, 64, 255);
   private static final Color Category = new Color(255, 198, 64);
   private final Set LicenseState = new HashSet();
   private final Map SwapHelper = new HashMap();
   private final List LicenseResult = new ArrayList();
   private ChunkPos HwidGen = null;
   private int Module_Themes = 0;
   private final List LicenseState = new ArrayList();
   private final Map Module_j = new HashMap();

   public Module_GrowthFinder() {
      super("Growth Finder", Category.LicenseState);
      this.HwidGen(this.aA);
      this.HwidGen(this.aB);
      this.HwidGen(this.aC);
      this.HwidGen(this.aD);
      this.HwidGen(this.aE);
   }

   @Override
   public void LicenseState() {
      this.J();
   }

   @Override
   public void Module_f() {
      this.J();
   }

   private void J() {
      this.SwapHelper.clear();
      this.LicenseState.clear();
      this.LicenseResult.clear();
      this.Module_Themes = 0;
      this.HwidGen = null;
      this.LicenseState.clear();
      this.Module_j.clear();
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.world != null) {
         ChunkPos var1 = new ChunkPos(HwidGen.player.getBlockPos());
         this.KeyFile(var1);
         this.HwidGen(HwidGen.world);
         this.HwidGen(var1, 8);
         if (HwidGen.world.getTime() % 20L == 0L) {
            this.K();
         }
      }
   }

   private void KeyFile(ChunkPos chunkPos) {
      if (this.HwidGen == null || chunkPos.x != this.HwidGen.x || chunkPos.z != this.HwidGen.z || this.Module_Themes >= this.LicenseResult.size()) {
         this.LicenseResult.clear();

         for (int var2 = -8; var2 <= 8; var2++) {
            for (int var3 = -8; var3 <= 8; var3++) {
               this.LicenseResult.add(new ChunkPos(chunkPos.x + var2, chunkPos.z + var3));
            }
         }

         this.Module_Themes = 0;
         this.HwidGen = chunkPos;
      }
   }

   private void HwidGen(World world) {
      int var2 = 0;

      while (this.Module_Themes < this.LicenseResult.size() && var2 < 12) {
         ChunkPos var3 = (ChunkPos)this.LicenseResult.get(this.Module_Themes++);
         if (!this.LicenseState.contains(var3)) {
            WorldChunk var4 = world.getChunkManager().getWorldChunk(var3.x, var3.z, false);
            if (var4 != null) {
               this.HwidGen(var4, var3);
               this.LicenseState.add(var3);
            }

            var2++;
         }
      }
   }

   private void HwidGen(ChunkPos chunkPos, int i) {
      int var3 = i + 2;
      int var4 = chunkPos.x;
      int var5 = chunkPos.z;
      this.SwapHelper
         .entrySet()
         .removeIf(entry -> Math.abs(((ChunkPos)entry.getKey()).x - var4) > var3 || Math.abs(((ChunkPos)entry.getKey()).z - var5) > var3);
      this.LicenseState.removeIf(chunkPosx -> Math.abs(chunkPosx.x - var4) > var3 || Math.abs(chunkPosx.z - var5) > var3);
   }

   private void K() {
      if (this.SwapHelper.isEmpty()) {
         this.Module_j.clear();
      } else {
         for (Rec_aw var2 : this.SwapHelper.values()) {
            ChunkPos var3 = var2.c;
            this.Module_j.merge(var3, (double)var2.Module_DoubleAnchor, Double::sum);
         }

         this.Module_j.entrySet().removeIf(entry -> {
            double var1 = (Double)entry.getValue() * 0.95;
            entry.setValue(var1);
            return var1 < 0.5;
         });
         ArrayList var4 = new ArrayList(this.Module_j.entrySet());
         var4.sort((entry, entry2) -> Double.compare((Double)entry2.getValue(), (Double)entry.getValue()));
         this.LicenseState.clear();

         for (int var5 = 0; var5 < Math.min(2, var4.size()); var5++) {
            this.LicenseState.add((ChunkPos)((Entry)var4.get(var5)).getKey());
         }
      }
   }

   private void HwidGen(WorldChunk worldChunk, ChunkPos chunkPos) {
      int var3 = chunkPos.getStartX();
      int var4 = chunkPos.getStartZ();
      List var5 = this.aA.HwidGen() ? this.HwidGen(worldChunk, var3, var4) : Collections.emptyList();
      List var6 = this.aB.HwidGen() ? this.KeyFile(worldChunk, var3, var4) : Collections.emptyList();
      List var7 = this.aC.HwidGen() ? this.c(worldChunk, var3, var4) : Collections.emptyList();
      ArrayList var8 = new ArrayList();
      double var9 = 0.0;
      int var11 = 0;

      for (Obj_ax var13 : var5) {
         double var14 = var13.B;
         var9 += var14;
         if (var13.B > var11) {
            var11 = var13.B;
         }

         var8.add(new Rec_ay(var13.HwidGen(), var14));
      }

      double var20 = 0.0;

      for (Obj_av var15 : var6) {
         var20 += 2.5;
         var8.add(new Rec_ay(var15.c, 2.5));
      }

      double var22 = 0.0;

      for (Rec_au var17 : var7) {
         var22++;
         var8.add(new Rec_ay(var17.KeyFile, 1.0));
      }

      int var23 = (int)Math.round(var9 * 0.5 + var20 * 0.75 + var22 * 1.0);
      if (var23 > 0) {
         BlockPos var24 = this.HwidGen(var8, chunkPos);
         boolean var18 = var11 >= 100;
         boolean var19 = var11 >= 25;
         this.SwapHelper.put(chunkPos, new Rec_aw(chunkPos, var23, new ChunkPos(var24), var18, var19, var11));
      } else {
         this.SwapHelper.remove(chunkPos);
      }
   }

   private List HwidGen(WorldChunk worldChunk, int i, int j) {
      ArrayList var4 = new ArrayList();
      HashSet var5 = new HashSet();
      int var6 = worldChunk.getBottomY();
      int var7 = 0;

      for (int var8 = i; var8 < i + 16; var8 += 2) {
         for (int var9 = j; var9 < j + 16 && var7 < 2; var9 += 2) {
            int var10 = worldChunk.getHeightmap(Type.MOTION_BLOCKING).get(var8 - i, var9 - j);

            while (var10 >= var6) {
               BlockPos var11 = new BlockPos(var8, var10, var9);
               if (var5.contains(var11)) {
                  var10--;
               } else {
                  BlockState var12 = worldChunk.getBlockState(var11);
                  if (!this.HwidGen(var12.getBlock())) {
                     var10--;
                  } else {
                     ArrayList var13 = new ArrayList();

                     BlockPos var14;
                     for (var14 = var11; var14.getY() >= var6 && this.HwidGen(worldChunk.getBlockState(var14).getBlock()); var14 = var14.down()) {
                        var5.add(var14);
                        var13.add(var14);
                     }

                     if (var13.size() >= 6) {
                        var4.add(new Obj_ax(var13));
                        var7++;
                     }

                     var10 = var14.getY() - 1;
                  }
               }
            }
         }
      }

      return var4;
   }

   private boolean HwidGen(Block block) {
      return block instanceof VineBlock
         || block == Blocks.CAVE_VINES
         || block == Blocks.CAVE_VINES_PLANT
         || block == Blocks.WEEPING_VINES
         || block == Blocks.WEEPING_VINES_PLANT
         || block == Blocks.TWISTING_VINES
         || block == Blocks.TWISTING_VINES_PLANT;
   }

   private List KeyFile(WorldChunk worldChunk, int i, int j) {
      ArrayList var4 = new ArrayList();

      for (int var5 = i; var5 < i + 16; var5 += 4) {
         for (int var6 = j; var6 < j + 16; var6 += 4) {
            int var7 = worldChunk.getHeightmap(Type.MOTION_BLOCKING).get(var5 - i, var6 - j);

            for (byte var8 = -64; var8 <= var7; var8 += 4) {
               BlockPos var9 = new BlockPos(var5, var8, var6);
               if (worldChunk.getBlockState(var9).getBlock() instanceof PointedDripstoneBlock) {
                  var4.add(new Obj_av(var9));
                  break;
               }
            }
         }
      }

      return var4;
   }

   private List c(WorldChunk worldChunk, int i, int j) {
      ArrayList var4 = new ArrayList();

      for (int var5 = i; var5 < i + 16; var5 += 2) {
         for (int var6 = j; var6 < j + 16; var6 += 2) {
            int var7 = worldChunk.getHeightmap(Type.MOTION_BLOCKING).get(var5 - i, var6 - j);

            for (int var8 = var7; var8 >= var7 - 5; var8--) {
               BlockPos var9 = new BlockPos(var5, var8, var6);
               BlockState var10 = worldChunk.getBlockState(var9);
               if (var10.getBlock() instanceof SweetBerryBushBlock) {
                  try {
                     if ((Integer)var10.get(SweetBerryBushBlock.AGE) == 3) {
                        var4.add(new Rec_au(var9));
                     }
                  } catch (Exception var12) {
                  }
               }
            }
         }
      }

      return var4;
   }

   private BlockPos HwidGen(List list, ChunkPos chunkPos) {
      if (list.isEmpty()) {
         return new BlockPos(chunkPos.getStartX() + 8, 30, chunkPos.getStartZ() + 8);
      } else {
         double var3 = 0.0;
         double var5 = 0.0;
         double var7 = 0.0;
         double var9 = 0.0;

         for (Rec_ay var12 : list) {
            var3 += var12.LicenseResult.getX() * var12.HwidGen;
            var5 += var12.LicenseResult.getY() * var12.HwidGen;
            var7 += var12.LicenseResult.getZ() * var12.HwidGen;
            var9 += var12.HwidGen;
         }

         return new BlockPos((int)(var3 / var9), (int)(var5 / var9), (int)(var7 / var9));
      }
   }

   @Override
   public void HwidGen(MatrixStack matrixStack, float f) {
      if (HwidGen.world != null && HwidGen.player != null) {
         if (!this.SwapHelper.isEmpty()) {
            Camera var3 = Render_dm.HwidGen();
            if (var3 != null) {
               Vec3d var4 = Render_dm.HwidGen(var3);
               int var5 = Math.max(0, Math.min(255, ((Float)this.aE.HwidGen()).intValue()));
               matrixStack.push();
               do var6 = Render_dm.HwidGen(matrixStack);

               for (Rec_aw var8 : this.SwapHelper.values()) {
                  boolean var9 = !var8.Module_AutoDoubleHand && !var8.Module_AutoInvTotem;
                  if (!var9 || (Boolean)this.aD.HwidGen()) {
                     Color var10;
                     if (var8.Module_AutoDoubleHand) {
                        var10 = Category;
                     } else if (var8.Module_AutoInvTotem) {
                        var10 = Module_f;
                     } else if (var8.Module_DoubleAnchor < 5 && var8.A < 4) {
                        var10 = LicenseState;
                     } else {
                        var10 = LicenseResult;
                     }

                     Color var11 = new Color(var10.getRed(), var10.getGreen(), var10.getBlue(), var5);
                     double var12 = var8.KeyFile.getStartX();
                     double var14 = var8.KeyFile.getStartZ();
                     double var16 = 30.0;
                     double var18 = var12 - var4.x;
                     double var20 = var14 - var4.z;
                     double var22 = var12 + 16.0 - var4.x;
                     double var24 = var14 + 16.0 - var4.z;
                     double var26 = var16 - var4.y;
                     double var28 = var16 + 0.08 - var4.y;
                     var6.HwidGen(var18, var26, var20, var22, var28, var24, var11);
                  }
               }

               var6.Module_FakePay();
               matrixStack.pop();
            }
         }
      }
   }
}
