import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.util.math.BlockPos;

public final class Render_de {
   private static final Map Module_Themes = new ConcurrentHashMap();

   public static void HwidGen(int i, BlockPos blockPos, int j) {
      if (j >= 0) {
         Module_Themes.put(i, blockPos);
      } else {
         Module_Themes.remove(i);
      }
   }

   public static boolean c(int i) {
      return Module_Themes.containsKey(i);
   }
}
