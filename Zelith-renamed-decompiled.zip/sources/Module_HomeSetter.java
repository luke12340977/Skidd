import net.minecraft.client.network.ClientPlayNetworkHandler;

public final class Module_HomeSetter extends Module {
   private final dd bA = new Setting("Home Slot", 1.0F, 1.0F, 5.0F);
   private volatile boolean H = false;

   public Module_HomeSetter() {
      super("Home Setter", Category.HwidGen);
      this.HwidGen(this.bA);
   }

   @Override
   public void LicenseState() {
      super.LicenseState();
      if (!this.H) {
         if (HwidGen != null && HwidGen.player != null && HwidGen.world != null) {
            this.H = true;
            int var1 = Math.round((Float)this.bA.HwidGen());
            short var2 = 750;
            HwidGen.execute(() -> {
               this.Module("/delhome " + var1);
               new Thread(() -> {
                  try {
                     Thread.sleep(750L);
                  } catch (InterruptedException var3) {
                  }

                  HwidGen.execute(() -> {
                     this.Module("/sethome " + var1);
                     this.H = false;
                     this.c();
                  });
               }, "HomeSetter-DelayThread").start();
            });
         } else {
            this.c();
         }
      }
   }

   @Override
   public void Module_f() {
      super.Module_f();
      this.H = false;
   }

   private void Module(String string) {
      if (HwidGen != null) {
         ClientPlayNetworkHandler var2 = null;

         try {
            if (HwidGen.player != null) {
               var2 = HwidGen.player.networkHandler;
            }
         } catch (Throwable var8) {
         }

         if (var2 == null) {
            try {
               var2 = HwidGen.getNetworkHandler();
            } catch (Throwable var7) {
            }
         }

         if (var2 != null) {
            String var3 = string.startsWith("/") ? string.substring(1) : string;

            try {
               var2.sendChatCommand(var3);
            } catch (Throwable var6) {
               try {
                  var2.sendChatMessage(string);
               } catch (Throwable var5) {
               }
            }
         }
      }
   }
}
