public final class Module_Hitbox extends Module {
   public static aa HwidGen;
   public final dd P = new Setting("Expand", 1.0F, 0.5F, 2.0F);

   public Module_Hitbox() {
      super("Hitbox", Category.c);
      this.HwidGen(this.P);
      HwidGen = this;
   }
}
