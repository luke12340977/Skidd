import java.net.NetworkInterface;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.Collections;
import java.util.UUID;
import net.minecraft.client.MinecraftClient;

public final class HwidGen {
   private static String HwidGen = null;

   public static String HwidGen() {
      if (HwidGen != null) {
         return HwidGen;
      } else {
         Path var0 = MinecraftClient.getInstance().runDirectory.toPath().resolve(".zelith_hwid");

         try {
            if (Files.isReadable(var0)) {
               HwidGen = Files.readString(var0, StandardCharsets.UTF_8).trim();
               if (!HwidGen.isEmpty()) {
                  return HwidGen;
               }
            }
         } catch (Exception var10) {
         }

         try {
            StringBuilder var1 = new StringBuilder();

            for (NetworkInterface var3 : Collections.list(NetworkInterface.getNetworkInterfaces())) {
               byte[] var4 = var3.getHardwareAddress();
               if (var4 != null && var4.length > 0) {
                  for (byte var8 : var4) {
                     var1.append(String.format("%02X", var8));
                  }
                  break;
               }
            }

            var1.append(System.getProperty("os.name"));
            var1.append(System.getProperty("os.version"));
            var1.append(System.getProperty("user.name"));
            var1.append(Runtime.getRuntime().availableProcessors());
            MessageDigest var12 = MessageDigest.getInstance("SHA-256");
            byte[] var13 = var12.digest(var1.toString().getBytes(StandardCharsets.UTF_8));
            StringBuilder var14 = new StringBuilder();

            for (byte var18 : var13) {
               var14.append(String.format("%02x", var18));
            }

            HwidGen = var14.toString();
         } catch (Exception var11) {
            HwidGen = UUID.randomUUID().toString().replace("-", "");
         }

         try {
            Files.writeString(var0, HwidGen, StandardCharsets.UTF_8);
         } catch (Exception var9) {
         }

         return HwidGen;
      }
   }
}
