import java.awt.Color;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentHashMap.KeySetView;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

public final class Module_SpawnerFinder extends Module {
   private final dd aO = new Setting("Scan Radius", 4, 1, 8);
   private final dd aP = new Setting("Spawner Color", new Color(255, 0, 0, 100));
   private final dd aQ = new Setting("Fill Chunk", true);
   private final dd aR = new Setting("Fill Spawner", true);
   private final dd aS = new Setting("Show Nametag", true);
   private final dd aT = new Setting("Notification", true);
   private final Map Module_ActiveModules = new ConcurrentHashMap();
   private final Set Module_f = ConcurrentHashMap.newKeySet();
   private int Module_Themes;

   public Module_SpawnerFinder() {
      super("Spawner Finder", Category.LicenseState);
      this.HwidGen(this.aO);
      this.HwidGen(this.aP);
      this.HwidGen(this.aQ);
      this.HwidGen(this.aR);
      this.HwidGen(this.aS);
      this.HwidGen(this.aT);
   }

   @Override
   public void LicenseState() {
      this.Module_ActiveModules.clear();
      this.Module_f.clear();
      this.Module_Themes = 0;
   }

   @Override
   public void Module_f() {
      this.Module_ActiveModules.clear();
      this.Module_f.clear();
      this.Module_Themes = 0;
   }

   @Override
   public void Category() {
      if (HwidGen.world != null && HwidGen.player != null) {
         int var1 = (Integer)this.aO.HwidGen();
         ChunkPos var2 = HwidGen.player.getChunkPos();
         int var3 = var1 * 2 + 1;
         int var4 = var3 * var3;

         for (int var5 = 0; var5 < 8; var5++) {
            int var6 = this.Module_Themes % var4;
            this.Module_Themes = (this.Module_Themes + 1) % var4;
            int var7 = var6 % var3 - var1;
            int var8 = var6 / var3 - var1;
            int var9 = var2.x + var7;
            int var10 = var2.z + var8;
            WorldChunk var11 = HwidGen.world.getChunkManager().getWorldChunk(var9, var10, false);
            if (var11 != null && !var11.isEmpty()) {
               ChunkPos var12 = new ChunkPos(var9, var10);
               Set var13 = this.HwidGen(var11);
               if (!var13.isEmpty()) {
                  this.Module_ActiveModules.put(var12, var13);
                  if (this.Module_f.add(var12) && (Boolean)this.aT.HwidGen()) {
                     HwidGen.player
                        .sendMessage(Text.literal("§c[SpawnerFinder] §fSpawner found at X:" + var12.getCenterX() + " Z:" + var12.getCenterZ()), false);
                     HwidGen.player.playSound((SoundEvent)SoundEvents.BLOCK_NOTE_BLOCK_CHIME.value(), 1.0F, 1.0F);
                  }
               } else {
                  this.Module_ActiveModules.remove(var12);
                  this.Module_f.remove(var12);
               }
            }
         }

         this.Module_ActiveModules.keySet().removeIf(chunkPos2 -> this.HwidGen(chunkPos2, var2, var1));
      }
   }

   private Set HwidGen(WorldChunk worldChunk) {
      KeySetView var2 = ConcurrentHashMap.newKeySet();

      for (BlockPos var4 : worldChunk.getBlockEntityPositions()) {
         if (HwidGen.world.getBlockEntity(var4) instanceof MobSpawnerBlockEntity) {
            var2.add(var4);
         }
      }

      return var2;
   }

   @Override
   public void HwidGen(MatrixStack matrixStack, float f) {
      if (HwidGen.world != null && HwidGen.player != null && !this.Module_ActiveModules.isEmpty()) {
         Camera var3 = Render_dm.HwidGen();
         if (var3 != null) {
            Vec3d var4 = Render_dm.HwidGen(var3);
            Color var5 = (Color)this.aP.HwidGen();
            matrixStack.push();
            do var6 = Render_dm.HwidGen(matrixStack);

            for (Entry var8 : this.Module_ActiveModules.entrySet()) {
               ChunkPos var9 = (ChunkPos)var8.getKey();
               if ((Boolean)this.aQ.HwidGen()) {
                  double var10 = var9.getStartX() - var4.x;
                  double var12 = var9.getStartZ() - var4.z;
                  double var14 = var10 + 16.0;
                  double var16 = var12 + 16.0;
                  double var18 = 55.0 - var4.y;
                  double var20 = var18 + 0.05;
                  var6.HwidGen(var10, var18, var12, var14, var20, var16, new Color(var5.getRed(), var5.getGreen(), var5.getBlue(), 60));
               }

               for (BlockPos var11 : (Set)var8.getValue()) {
                  double var23 = var11.getX() - var4.x;
                  double var24 = var11.getY() - var4.y;
                  double var25 = var11.getZ() - var4.z;
                  if ((Boolean)this.aR.HwidGen()) {
                     var6.HwidGen(var23, var24, var25, var23 + 1.0, var24 + 1.0, var25 + 1.0, var5);
                  } else {
                     var6.KeyFile(var23, var24, var25, var23 + 1.0, var24 + 1.0, var25 + 1.0, var5);
                  }

                  var6.HwidGen(var5, new Vec3d(var23 + 0.5, var24 + 1.5, var25 + 0.5), new Vec3d(var23 + 0.5, var24 + 15.0, var25 + 0.5), 1.0F);
               }
            }

            var6.Module_FakePay();
            matrixStack.pop();
         }
      }
   }

   private boolean HwidGen(ChunkPos chunkPos, ChunkPos chunkPos2, int i) {
      return Math.abs(chunkPos.x - chunkPos2.x) > i || Math.abs(chunkPos.z - chunkPos2.z) > i;
   }
}
