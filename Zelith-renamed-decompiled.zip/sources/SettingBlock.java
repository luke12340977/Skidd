import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

public final class SettingBlock extends Setting {
   private final List Module = Registries.BLOCK
      .stream()
      .filter(block -> block != Blocks.AIR)
      .sorted(Comparator.comparing(this::KeyFile, String.CASE_INSENSITIVE_ORDER))
      .toList();
   private long Module_AutoDoubleHand;

   public SettingBlock(String string, Block... blocks) {
      super(string, HwidGen(blocks));
   }

   public void LicenseResult(Set set) {
      LinkedHashSet var2 = new LinkedHashSet();
      if (set != null) {
         for (Block var4 : set) {
            if (var4 != null && var4 != Blocks.AIR) {
               var2.add(var4);
            }
         }
      }

      super.HwidGen(var2);
      this.Module_AutoDoubleHand++;
   }

   public boolean KeyFile(Block block) {
      return block != null && ((Set)this.HwidGen()).contains(block);
   }

   public void HwidGen(Block block) {
      if (block != null && block != Blocks.AIR) {
         LinkedHashSet var2 = new LinkedHashSet((Collection)this.HwidGen());
         if (!var2.add(block)) {
            var2.remove(block);
         }

         this.LicenseResult(var2);
      }
   }

   public long c() {
      return this.Module_AutoDoubleHand;
   }

   public Set KeyFile() {
      return Collections.unmodifiableSet((Set)this.HwidGen());
   }

   public List KeyFile(String string) {
      String var2 = string == null ? "" : string.trim().toLowerCase(Locale.ROOT);
      if (var2.isEmpty()) {
         return this.Module;
      } else {
         ArrayList var3 = new ArrayList();

         for (Block var5 : this.Module) {
            String var6 = this.KeyFile(var5).toLowerCase(Locale.ROOT);
            Identifier var7 = Registries.BLOCK.getId(var5);
            String var8 = var7 == null ? "" : var7.toString().toLowerCase(Locale.ROOT);
            if (var6.contains(var2) || var8.contains(var2)) {
               var3.add(var5);
            }
         }

         return var3;
      }
   }

   public String KeyFile(Block block) {
      try {
         return block.getName().getString();
      } catch (Exception var4) {
         Identifier var3 = Registries.BLOCK.getId(block);
         return var3 == null ? "Block" : var3.getPath();
      }
   }

   public String Module_AutoCrystal() {
      if (((Set)this.HwidGen()).isEmpty()) {
         return "None";
      } else {
         Block var1 = (Block)((Set)this.HwidGen()).iterator().next();
         String var2 = this.KeyFile(var1);
         int var3 = ((Set)this.HwidGen()).size() - 1;
         return var3 > 0 ? var2 + " +" + var3 : var2;
      }
   }

   private static Set HwidGen(Block... blocks) {
      LinkedHashSet var1 = new LinkedHashSet();
      if (blocks != null) {
         Collections.addAll(var1, blocks);
         var1.remove(null);
         var1.remove(Blocks.AIR);
      }

      return var1;
   }
}
