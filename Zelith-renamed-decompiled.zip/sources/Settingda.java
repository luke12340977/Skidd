import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public final class Settingda extends Setting {
   private final List Module_Configs;

   public void LicenseResult(Set set) {
      LinkedHashSet var2 = new LinkedHashSet();
      if (set != null) {
         for (String var4 : set) {
            if (var4 != null) {
               for (Rec_cz var6 : this.Module_Configs) {
                  if (var6.Module_AutoDoubleHand().equalsIgnoreCase(var4)) {
                     var2.add(var6.Module_AutoDoubleHand());
                     break;
                  }
               }
            }
         }
      }

      super.HwidGen(var2);
   }

   public List Module_f() {
      return this.Module_Configs;
   }

   public void Module_Friends(String string) {
      if (string != null) {
         LinkedHashSet var2 = new LinkedHashSet((Collection)this.HwidGen());
         String var3 = null;

         for (Rec_cz var5 : this.Module_Configs) {
            if (var5.Module_AutoDoubleHand().equalsIgnoreCase(string)) {
               var3 = var5.Module_AutoDoubleHand();
               break;
            }
         }

         if (var3 != null) {
            if (!var2.add(var3)) {
               var2.remove(var3);
            }

            this.LicenseResult(var2);
         }
      }
   }

   public boolean Category(String string) {
      if (string == null) {
         return false;
      } else {
         for (String var3 : (Set)this.HwidGen()) {
            if (var3.equalsIgnoreCase(string)) {
               return true;
            }
         }

         return false;
      }
   }

   public boolean HwidGen(cz arg) {
      return arg != null && this.Category(arg.Module_AutoDoubleHand());
   }

   public List Category() {
      ArrayList var1 = new ArrayList();

      for (Rec_cz var3 : this.Module_Configs) {
         if (this.Category(var3.Module_AutoDoubleHand())) {
            var1.add(var3);
         }
      }

      return var1;
   }

   public String Module_AutoCrystal() {
      List var1 = this.Category();
      if (var1.isEmpty()) {
         return "Choose";
      } else {
         Rec_cz var2 = (Rec_cz)var1.getFirst();
         int var3 = var1.size() - 1;
         return var3 > 0 ? var2.Module_AutoInvTotem() + " +" + var3 : var2.Module_AutoInvTotem();
      }
   }
}
