import net.minecraft.item.ItemStack;

public record Rec_cz() {
   private final String F;
   private final String G;
   private final ItemStack Module_f;

   public String Module_AutoDoubleHand() {
      return this.F;
   }

   public String Module_AutoInvTotem() {
      return this.G;
   }
}
