final class Obj_cm {
   final double c;
   final double LicenseResult;
   final double LicenseState;
   final double Module_f;
   final double Category;
   final double Module;

   Obj_cm(double d, double e, double f, double g, double h, double i) {
      this.c = d;
      this.LicenseResult = e;
      this.LicenseState = f;
      this.Module_f = g;
      this.Category = h;
      this.Module = i;
   }
}
