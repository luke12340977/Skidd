import java.awt.Color;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.block.BeehiveBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

public final class Module_ChunkFinder extends Module {
   private static final Color c = new Color(5, 130, 45, 190);
   private final dd Module_BoneDropper = new Setting("Tracer", true);
   private final dd Enum_ak = new Setting("Notification", true);
   private final dd Enum_al = new Setting("Notification Sound", true);
   private final Set KeyFile = ConcurrentHashMap.newKeySet();
   private final Set c = ConcurrentHashMap.newKeySet();
   private final Map Category = new ConcurrentHashMap();
   private int Module_Themes;
   private int tickCounter;

   public Module_ChunkFinder() {
      super("Chunk Finder", Category.LicenseState);
      this.HwidGen(this.Module_BoneDropper);
      this.HwidGen(this.Enum_ak);
      this.HwidGen(this.Enum_al);
   }

   @Override
   public void LicenseState() {
      this.F();
   }

   @Override
   public void Module_f() {
      this.F();
   }

   @Override
   public void Category() {
      if (HwidGen.world != null && HwidGen.player != null) {
         this.tickCounter++;
         int var1 = HwidGen.options.getClampedViewDistance();
         ChunkPos var2 = HwidGen.player.getChunkPos();
         int var3 = var1 * 2 + 1;
         int var4 = var3 * var3;

         for (int var5 = 0; var5 < 8; var5++) {
            int var6 = this.Module_Themes % var4;
            this.Module_Themes = (this.Module_Themes + 1) % var4;
            int var7 = var6 % var3 - var1;
            int var8 = var6 / var3 - var1;
            int var9 = var2.x + var7;
            int var10 = var2.z + var8;
            WorldChunk var11 = HwidGen.world.getChunkManager().getWorldChunk(var9, var10, false);
            if (var11 != null && !var11.isEmpty()) {
               ChunkPos var12 = new ChunkPos(var9, var10);
               this.Category.putIfAbsent(var12, this.tickCounter);
               boolean var13 = this.tickCounter - (Integer)this.Category.get(var12) >= 200;
               if (var13 && this.HwidGen(var11)) {
                  this.KeyFile.add(var12);
                  if (this.c.add(var12) && (Boolean)this.Enum_ak.HwidGen()) {
                     this.HwidGen(var12);
                  }
               } else {
                  this.KeyFile.remove(var12);
               }
            }
         }

         this.KeyFile.removeIf(chunkPos2 -> this.HwidGen(chunkPos2, var2, var1));
         this.Category.keySet().removeIf(chunkPos2 -> this.HwidGen(chunkPos2, var2, var1));
      }
   }

   private boolean HwidGen(WorldChunk worldChunk) {
      for (ChunkSection var5 : worldChunk.getSectionArray()) {
         if (var5 != null && !var5.isEmpty() && var5.hasAny(blockState -> blockState.isOf(Blocks.BEEHIVE) || blockState.isOf(Blocks.BEE_NEST))) {
            for (int var6 = 0; var6 < 16; var6++) {
               for (int var7 = 0; var7 < 16; var7++) {
                  for (int var8 = 0; var8 < 16; var8++) {
                     BlockState var9 = var5.getBlockState(var6, var8, var7);
                     if ((var9.isOf(Blocks.BEEHIVE) || var9.isOf(Blocks.BEE_NEST))
                        && var9.contains(BeehiveBlock.HONEY_LEVEL)
                        && (Integer)var9.get(BeehiveBlock.HONEY_LEVEL) == 5) {
                        return true;
                     }
                  }
               }
            }
         }
      }

      return false;
   }

   @Override
   public void HwidGen(MatrixStack matrixStack, float f) {
      if (HwidGen.world != null && HwidGen.player != null && !this.KeyFile.isEmpty()) {
         Camera var3 = Render_dm.HwidGen();
         if (var3 != null) {
            Vec3d var4 = Render_dm.HwidGen(var3);
            matrixStack.push();
            do var5 = Render_dm.HwidGen(matrixStack);

            for (ChunkPos var7 : this.KeyFile) {
               double var8 = var7.getStartX() - var4.x;
               double var10 = var7.getStartZ() - var4.z;
               double var12 = var8 + 16.0;
               double var14 = var10 + 16.0;
               double var16 = 55.0 - var4.y;
               double var18 = var16 + 0.001;
               var5.HwidGen(var8, var16, var10, var12, var18, var14, c, 16, var7, this.KeyFile);
            }

            var5.Module_FakePay();
            matrixStack.pop();
            if ((Boolean)this.Module_BoneDropper.HwidGen()) {
               Vec3d var20 = Render_dm.KeyFile(var3);
               Vec3d var21 = Render_dm.c(var3);
               Vec3d var22 = Render_dm.HwidGen(var20, var21);
               boolean var9 = Module_Freecam.HwidGen != null && Module_Freecam.HwidGen.HwidGen();
               Vec3d var23;
               if (var9) {
                  var23 = new Vec3d(HwidGen.player.getX() - var4.x, HwidGen.player.getY() - var4.y, HwidGen.player.getZ() - var4.z);
               } else {
                  var23 = var20.multiply(150.0);
               }

               float var11 = Module_zelith.KeyFile();

               for (ChunkPos var13 : this.KeyFile) {
                  Vec3d var25 = Render_dm.HwidGen(var13.getCenterX() - var4.x, 55.0 - var4.y, var13.getCenterZ() - var4.z, var20, var21, var22, 24.0, 2.75);
                  Render_dm.HwidGen(matrixStack, c, var23, var25, var11);
               }
            }
         }
      }
   }

   private boolean HwidGen(ChunkPos chunkPos, ChunkPos chunkPos2, int i) {
      return Math.abs(chunkPos.x - chunkPos2.x) > i || Math.abs(chunkPos.z - chunkPos2.z) > i;
   }

   private void HwidGen(ChunkPos chunkPos) {
      if (HwidGen.getToastManager() != null) {
         HwidGen.getToastManager()
            .add(
               new Toast_an(
                  Text.literal("ChunkFinder"),
                  Text.literal("Full beehive at X:" + chunkPos.getCenterX() + " Z:" + chunkPos.getCenterZ()),
                  new ItemStack(Items.ENDER_EYE)
               )
            );
         if ((Boolean)this.Enum_al.HwidGen() && HwidGen.player != null) {
            HwidGen.player.playSound((SoundEvent)SoundEvents.BLOCK_NOTE_BLOCK_CHIME.value(), 1.0F, 1.0F);
         }
      }
   }

   private void F() {
      this.KeyFile.clear();
      this.c.clear();
      this.Category.clear();
      this.Module_Themes = 0;
      this.tickCounter = 0;
   }
}
