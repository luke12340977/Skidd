import net.minecraft.util.math.BlockPos;

record Rec_au() {
   final BlockPos KeyFile;

   Rec_au(BlockPos blockPos) {
      this.KeyFile = blockPos;
   }
}
