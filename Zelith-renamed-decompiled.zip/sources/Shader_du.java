import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.pipeline.RenderPipeline.Snippet;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat.DrawMode;
import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.UniformType;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.lwjgl.system.MemoryUtil;

public class Shader_du {
   private static RenderPipeline HwidGen;
   private static GpuBuffer HwidGen;

   public static void Module() {
      if (HwidGen == null) {
         try {
            HwidGen = RenderPipeline.builder(new Snippet[0])
               .withLocation(Identifier.of("zelith", "texture"))
               .withVertexShader(Identifier.of("zelith", "texture_vertex"))
               .withFragmentShader(Identifier.of("zelith", "texture_fragment"))
               .withVertexFormat(VertexFormat.builder().build(), DrawMode.TRIANGLES)
               .withUniform("Uniforms", UniformType.UNIFORM_BUFFER)
               .withSampler("Sampler0")
               .withBlend(BlendFunction.TRANSLUCENT)
               .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
               .withCull(false)
               .build();
            HwidGen = RenderSystem.getDevice().createBuffer(() -> "Texture2D Uniforms", 136, 128L);
         } catch (Exception var1) {
            System.err.println("[Texture2D] Failed to init: " + var1.getMessage());
            var1.printStackTrace();
         }
      }
   }

   public static void HwidGen(Matrix4f matrix4f, float f, float g, float h, GpuTextureView gpuTextureView, int i, float j, float k) {
      if (HwidGen == null) {
         Module();
      }

      if (HwidGen != null && HwidGen != null && gpuTextureView != null) {
         float var8 = (i >> 16 & 0xFF) / 255.0F;
         float var9 = (i >> 8 & 0xFF) / 255.0F;
         float var10 = (i & 0xFF) / 255.0F;
         float var11 = (i >> 24 & 0xFF) / 255.0F;
         ByteBuffer var12 = MemoryUtil.memAlloc(128);
         var12.putFloat(matrix4f.m00()).putFloat(matrix4f.m01()).putFloat(matrix4f.m02()).putFloat(matrix4f.m03());
         var12.putFloat(matrix4f.m10()).putFloat(matrix4f.m11()).putFloat(matrix4f.m12()).putFloat(matrix4f.m13());
         var12.putFloat(matrix4f.m20()).putFloat(matrix4f.m21()).putFloat(matrix4f.m22()).putFloat(matrix4f.m23());
         var12.putFloat(matrix4f.m30()).putFloat(matrix4f.m31()).putFloat(matrix4f.m32()).putFloat(matrix4f.m33());
         var12.position(64);
         var12.putFloat(f).putFloat(g).putFloat(h).putFloat(h);
         var12.putFloat(var8).putFloat(var9).putFloat(var10).putFloat(var11);
         var12.putFloat(j).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
         var12.putFloat(k).putFloat(0.0F).putFloat(0.0F).putFloat(0.0F);
         var12.flip();
         CommandEncoder var13 = RenderSystem.getDevice().createCommandEncoder();
         var13.writeToBuffer(HwidGen.slice(), var12);
         MemoryUtil.memFree(var12);
         GpuSampler var14 = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
         Framebuffer var15 = MinecraftClient.getInstance().getFramebuffer();
         RenderPass var16 = var13.createRenderPass(
            () -> "Texture2D", var15.getColorAttachmentView(), OptionalInt.empty(), var15.getDepthAttachmentView(), OptionalDouble.of(1.0)
         );

         try {
            Obj_dr.HwidGen(var16);
            var16.setPipeline(HwidGen);
            var16.setUniform("Uniforms", HwidGen);
            var16.bindTexture("Sampler0", gpuTextureView, var14);
            var16.draw(0, 6);
         } catch (Throwable var20) {
            if (var16 != null) {
               try {
                  var16.close();
               } catch (Throwable var19) {
                  var20.addSuppressed(var19);
               }
            }

            throw var20;
         }

         if (var16 != null) {
            var16.close();
         }
      }
   }
}
