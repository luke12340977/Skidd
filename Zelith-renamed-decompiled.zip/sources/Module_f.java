public abstract class Module_f extends Module {
   private int HwidGen = 0;
   public boolean HwidGen = false;

   public Module_f(String string, g arg) {
      super(string, arg);
   }

   public void KeyFile() {
      this.c();
   }

   public int HwidGen() {
      return this.HwidGen;
   }

   public void HwidGen(int i) {
      this.HwidGen = i;
      SwapHelper.HwidGen.Module_j();
   }

   void KeyFile(int i) {
      this.HwidGen = i;
   }
}
