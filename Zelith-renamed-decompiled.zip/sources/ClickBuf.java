final class ClickBuf {
   float HwidGen;
   boolean Category;

   ClickBuf(boolean bl) {
      this.Category = bl;
      this.HwidGen = bl ? 0.0F : 1.0F;
   }
}
