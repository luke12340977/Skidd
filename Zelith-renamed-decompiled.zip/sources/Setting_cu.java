public final class Setting_cu extends Setting {
   private final Runnable HwidGen;

   public void Toast_ai() {
      if (this.HwidGen != null) {
         this.HwidGen.run();
      }
   }
}
