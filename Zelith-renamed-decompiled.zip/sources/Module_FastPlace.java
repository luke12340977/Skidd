import com.zelith.mixin.MinecraftClientAccessor;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.RangedWeaponItem;

public final class Module_FastPlace extends Module {
   private final dd Module_NameTags = new Setting("Only XP", false);
   private final dd Rec_bt = new Setting("Blocks", true);
   private final dd Rec_bu = new Setting("Items", true);
   private final dd Module_SkinChanger = new Setting("Delay", 0.0F, 0.0F, 10.0F);

   public Module_FastPlace() {
      super("Fast Place", Category.HwidGen);
      this.HwidGen(this.Module_NameTags);
      this.HwidGen(this.Rec_bt);
      this.HwidGen(this.Rec_bu);
      this.HwidGen(this.Module_SkinChanger);
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.currentScreen == null) {
         if (HwidGen.options.useKey.isPressed()) {
            ItemStack var1 = HwidGen.player.getMainHandStack();
            ItemStack var2 = HwidGen.player.getOffHandStack();
            if (this.HwidGen(var1, var2)) {
               MinecraftClientAccessor var3 = (MinecraftClientAccessor)HwidGen;
               int var4 = Math.max(0, ((Float)this.Module_SkinChanger.HwidGen()).intValue());
               if (var3.zelith$getItemUseCooldown() != var4) {
                  var3.zelith$setItemUseCooldown(var4);
               }
            }
         }
      }
   }

   private boolean HwidGen(ItemStack itemStack, ItemStack itemStack2) {
      boolean var3 = itemStack.isOf(Items.EXPERIENCE_BOTTLE);
      boolean var4 = itemStack2.isOf(Items.EXPERIENCE_BOTTLE);
      if ((Boolean)this.Module_NameTags.HwidGen()) {
         return var3 || var4;
      } else {
         Item var5 = itemStack.getItem();
         Item var6 = itemStack2.getItem();
         if (this.c(itemStack) || this.c(itemStack2)) {
            return false;
         } else if (itemStack.isOf(Items.RESPAWN_ANCHOR)
            || itemStack.isOf(Items.GLOWSTONE)
            || itemStack2.isOf(Items.RESPAWN_ANCHOR)
            || itemStack2.isOf(Items.GLOWSTONE)) {
            return false;
         } else if (!(var5 instanceof RangedWeaponItem) && !(var6 instanceof RangedWeaponItem)) {
            boolean var7 = var5 instanceof BlockItem || var6 instanceof BlockItem;
            return var7 ? (Boolean)this.Rec_bt.HwidGen() : (Boolean)this.Rec_bu.HwidGen();
         } else {
            return false;
         }
      }
   }

   private boolean c(ItemStack itemStack) {
      return itemStack.getComponents().contains(DataComponentTypes.FOOD);
   }
}
