import java.util.List;

public final class Misc_cy extends Setting {
   private final List Module_ActiveModules;
   private final List ClickBuf;

   public Misc_cy(String string, String string2, String... strings) {
      this(string, string2, new String[0], strings);
   }

   public Misc_cy(String string, String string2, String[] strings, String... strings2) {
      super(string, string2);
      if (strings2 != null && strings2.length != 0) {
         this.Module_ActiveModules = List.of(strings2);
         this.ClickBuf = strings == null ? List.of() : List.of(strings);
         this.Module_Configs(string2);
      } else {
         throw new IllegalArgumentException("ModeSetting requires at least one mode");
      }
   }

   public void Module_BoneDropper() {
      this.Module_Configs(this.KeyFile(1));
   }

   public void Enum_ak() {
      this.Module_Configs(this.KeyFile(-1));
   }

   public boolean Module_f(String string) {
      return this.Module_j(string).equalsIgnoreCase((String)this.HwidGen());
   }

   public void Module_Configs(String string) {
      super.HwidGen(this.SwapHelper(string));
   }

   @Override
   public boolean LicenseResult(String string) {
      if (super.LicenseResult(string)) {
         return true;
      } else {
         String var2 = this.Module_j(string);

         for (String var4 : this.ClickBuf) {
            if (var4.equalsIgnoreCase(var2)) {
               return true;
            }
         }

         return false;
      }
   }

   private String KeyFile(int i) {
      int var2 = this.Module_ActiveModules.size();
      if (var2 == 0) {
         return "";
      } else {
         String var3 = (String)this.HwidGen();

         for (int var4 = 0; var4 < var2; var4++) {
            if (((String)this.Module_ActiveModules.get(var4)).equalsIgnoreCase(var3)) {
               int var5 = Math.floorMod(var4 + i, var2);
               return (String)this.Module_ActiveModules.get(var5);
            }
         }

         return (String)this.Module_ActiveModules.getFirst();
      }
   }

   private String SwapHelper(String string) {
      String var2 = this.Module_j(string);

      for (String var4 : this.Module_ActiveModules) {
         if (var4.equalsIgnoreCase(var2)) {
            return var4;
         }
      }

      return (String)this.Module_ActiveModules.getFirst();
   }

   private String Module_j(String string) {
      return string == null ? "" : string.trim();
   }
}
