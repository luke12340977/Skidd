import net.minecraft.util.AssetInfo.TextureAsset;

record Rec_bw() {
   private final bx HwidGen;
   private final TextureAsset KeyFile;

   Rec_bw(bx arg, TextureAsset textureAsset) {
      this.HwidGen = arg;
      this.KeyFile = textureAsset;
   }

   public TextureAsset HwidGen() {
      return this.KeyFile;
   }
}
