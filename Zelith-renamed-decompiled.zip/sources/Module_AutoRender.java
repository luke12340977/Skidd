import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;

public final class Module_AutoRender extends Module {
   private final dd Module_AntiTrap = new Setting("Notification", true);
   private final dd Module_AutoRender = new Setting("Notification Sound", true);
   private boolean Module_WaterMark;
   private boolean Module_zelith;
   private boolean Module_AnchorMacro;
   private int HudElement;

   public Module_AutoRender() {
      super("Auto Render", Category.LicenseState);
      this.HwidGen(this.Module_AntiTrap);
      this.HwidGen(this.Module_AutoRender);
   }

   @Override
   public void LicenseState() {
      this.Module_WaterMark = false;
      this.Module_zelith = false;
      this.Module_AnchorMacro = false;
      this.HudElement = 0;
   }

   @Override
   public void Module_f() {
      this.Module_WaterMark = false;
      this.Module_zelith = false;
      this.Module_AnchorMacro = false;
      this.HudElement = 0;
      if (HwidGen.options != null) {
         HwidGen.options.getViewDistance().setValue(8);
      }
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.world != null) {
         boolean var1 = HwidGen.player.getY() < -2.0;
         if (!var1) {
            this.Module_WaterMark = false;
            this.Module_zelith = false;
         }

         if (var1 && !this.Module_WaterMark && !this.Module_AnchorMacro) {
            if (HwidGen.options != null) {
               HwidGen.options.getViewDistance().setValue(2);
            }

            this.Module_AnchorMacro = true;
            this.HudElement = 0;
            this.Module_WaterMark = true;
            if ((Boolean)this.Module_AntiTrap.HwidGen() && !this.Module_zelith) {
               this.Module_DoubleAnchor();
               this.Module_zelith = true;
            }
         }

         if (this.Module_AnchorMacro) {
            this.HudElement++;
            if (this.HudElement >= 20) {
               if (HwidGen.options != null) {
                  HwidGen.options.getViewDistance().setValue(8);
               }

               this.Module_AnchorMacro = false;
            }
         }
      }
   }

   private void Module_DoubleAnchor() {
      if (HwidGen.getToastManager() != null) {
         HwidGen.getToastManager().add(new Toast_ai(Text.literal("AutoRender"), Text.literal("Y < -2! View distance reduced"), new ItemStack(Items.COMPASS)));
         if ((Boolean)this.Module_AutoRender.HwidGen() && HwidGen.player != null) {
            HwidGen.player.playSound((SoundEvent)SoundEvents.BLOCK_NOTE_BLOCK_CHIME.value(), 1.0F, 1.0F);
         }
      }
   }
}
