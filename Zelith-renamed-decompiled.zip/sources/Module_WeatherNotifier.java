import com.zelith.gui.notification.NotificationManager;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

public final class Module_WeatherNotifier extends Module {
   private final cy Module_j = new Misc_cy("Notification Mode", "Both", "Chat", "Toast", "Both");
   private final dd bP = new Setting("Notify Thunder", true);
   private Boolean HwidGen = null;
   private Boolean KeyFile = null;

   public Module_WeatherNotifier() {
      super("Weather Notifier", Category.HwidGen);
      this.HwidGen(this.Module_j);
      this.HwidGen(this.bP);
   }

   @Override
   public void LicenseState() {
      this.HwidGen = null;
      this.KeyFile = null;
   }

   @Override
   public void Module_f() {
      this.HwidGen = null;
      this.KeyFile = null;
   }

   @Override
   public void Category() {
      if (HwidGen.world != null && HwidGen.player != null) {
         boolean var1 = HwidGen.world.isRaining();
         boolean var2 = HwidGen.world.isThundering();
         if (this.HwidGen == null) {
            this.HwidGen = var1;
            this.KeyFile = var2;
         } else {
            if (var1 && !this.HwidGen) {
               this.c("The rain started.", "Rain Started", -10835482);
            } else if (!var1 && this.HwidGen) {
               this.c("The rain stopped.", "Rain Stopped", -340971);
            }

            if ((Boolean)this.bP.HwidGen()) {
               if (var2 && !this.KeyFile) {
                  this.c("A thunderstorm started.", "Thunder Started", -4879105);
               } else if (!var2 && this.KeyFile) {
                  this.c("The thunderstorm ended.", "Thunder Ended", -340971);
               }
            }

            this.HwidGen = var1;
            this.KeyFile = var2;
         }
      }
   }

   private void c(String string, String string2, int i) {
      String var4 = (String)this.Module_j.HwidGen();
      boolean var5 = "Chat".equalsIgnoreCase(var4) || "Both".equalsIgnoreCase(var4);
      boolean var6 = "Toast".equalsIgnoreCase(var4) || "Both".equalsIgnoreCase(var4);
      if (var5) {
         try {
            HwidGen.inGameHud.getChatHud().addMessage(Text.literal("[WeatherNotifier] " + string));
         } catch (Throwable var8) {
         }
      }

      if (var6) {
         NotificationManager.INSTANCE.push("WeatherNotifier", string2, ItemStack.EMPTY, i);
      }
   }
}
