enum LicenseStateDup {
   HwidGen,
   KeyFile,
   c;

   public static dh[] values() {
      return (dh[])HwidGen.clone();
   }

   public static dh valueOf(String string) {
      return Enum.valueOf(LicenseStateDup.class, string);
   }
}
