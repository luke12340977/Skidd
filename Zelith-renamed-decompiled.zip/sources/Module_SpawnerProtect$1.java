class Module_SpawnerProtect$1 extends Setting {
   Module_SpawnerProtect$1(bc arg, String string, String string2) {
      super(string, string2);
   }

   @Override
   public boolean LicenseResult(String string) {
      return super.LicenseResult(string) || "Webhook URL".equalsIgnoreCase(string);
   }
}
