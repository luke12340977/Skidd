import com.zelith.gui.notification.NotificationManager;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

public final class Module_TabDetector extends Module {
   private final cy Module = new Misc_cy("Detect", "List", "Any", "List");
   private final dd bK = new Setting("Target Players", "");
   private final cy SwapHelper = new Misc_cy("Notification Mode", "Both", "Chat", "Toast", "Both");
   private final dd bL = new Setting("Log Offline", true);
   private final Set Module_ActiveModules = new HashSet();
   private final Set ClickBuf = new HashSet();

   public Module_TabDetector() {
      super("Tab Detector", Category.HwidGen);
      this.bK.HwidGen(() -> this.Module.Module_f("List"));
      this.HwidGen(this.Module);
      this.HwidGen(this.bK);
      this.HwidGen(this.SwapHelper);
      this.HwidGen(this.bL);
   }

   @Override
   public void LicenseState() {
      this.Module_ActiveModules.clear();
      this.ClickBuf.clear();
      this.c(this.ClickBuf);
   }

   @Override
   public void Module_f() {
      this.Module_ActiveModules.clear();
      this.ClickBuf.clear();
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.world != null && HwidGen.getNetworkHandler() != null) {
         boolean var1 = this.Module.Module_f("Any");
         Set var2 = var1 ? Set.of() : this.KeyFile((String)this.bK.HwidGen());
         if (!var1 && var2.isEmpty()) {
            this.Module_ActiveModules.clear();
            this.ClickBuf.clear();
         } else {
            this.Module_ActiveModules.clear();

            for (PlayerListEntry var4 : HwidGen.getNetworkHandler().getPlayerList()) {
               String var5 = this.HwidGen(var4);
               if (!var5.isEmpty()
                  && (HwidGen.player == null || !var5.equalsIgnoreCase(HwidGen.player.getName().getString()))
                  && (var1 || this.HwidGen(var2, var5))) {
                  this.Module_ActiveModules.add(var5);
               }
            }

            HashSet var6 = new HashSet(this.Module_ActiveModules);
            var6.removeAll(this.ClickBuf);
            if (!var6.isEmpty()) {
               this.HwidGen(var6);
            }

            if ((Boolean)this.bL.HwidGen()) {
               HashSet var7 = new HashSet(this.ClickBuf);
               var7.removeAll(this.Module_ActiveModules);
               if (!var7.isEmpty()) {
                  this.KeyFile(var7);
               }
            }

            this.ClickBuf.clear();
            this.ClickBuf.addAll(this.Module_ActiveModules);
         }
      }
   }

   private void HwidGen(Set set) {
      String var2 = String.join(", ", set);
      String var3 = set.size() == 1 ? "Target player joined: " + var2 : "Target players joined: " + var2;
      this.c(var3, set.size() == 1 ? "Target Player Joined!" : "Target Players Joined!", -1938838);
   }

   private void KeyFile(Set set) {
      String var2 = String.join(", ", set);
      String var3 = set.size() == 1 ? "Target player left: " + var2 : "Target players left: " + var2;
      this.c(var3, set.size() == 1 ? "Target Player Left!" : "Target Players Left!", -11152222);
   }

   private void c(String string, String string2, int i) {
      String var4 = (String)this.SwapHelper.HwidGen();
      boolean var5 = "Chat".equalsIgnoreCase(var4) || "Both".equalsIgnoreCase(var4);
      boolean var6 = "Toast".equalsIgnoreCase(var4) || "Both".equalsIgnoreCase(var4);
      if (var5) {
         try {
            HwidGen.inGameHud.getChatHud().addMessage(Text.literal("[TabDetector] " + string));
         } catch (Throwable var8) {
         }
      }

      if (var6) {
         NotificationManager.INSTANCE.push("TabDetector", string2, ItemStack.EMPTY, i);
      }
   }

   private void c(Set set) {
      set.clear();
      if (HwidGen.getNetworkHandler() != null) {
         boolean var2 = this.Module.Module_f("Any");
         Set var3 = var2 ? Set.of() : this.KeyFile((String)this.bK.HwidGen());
         if (var2 || !var3.isEmpty()) {
            for (PlayerListEntry var5 : HwidGen.getNetworkHandler().getPlayerList()) {
               String var6 = this.HwidGen(var5);
               if (!var6.isEmpty()
                  && (HwidGen.player == null || !var6.equalsIgnoreCase(HwidGen.player.getName().getString()))
                  && (var2 || this.HwidGen(var3, var6))) {
                  set.add(var6);
               }
            }
         }
      }
   }

   private String HwidGen(PlayerListEntry playerListEntry) {
      try {
         if (playerListEntry != null && playerListEntry.getProfile() != null) {
            try {
               String var2 = playerListEntry.getProfile().name();
               return var2 == null ? "" : var2;
            } catch (Throwable var3) {
               return "";
            }
         } else {
            return "";
         }
      } catch (Throwable var4) {
         return "";
      }
   }

   private boolean HwidGen(Set set, String string) {
      return set.contains(string.toLowerCase(Locale.ROOT));
   }

   private Set KeyFile(String string) {
      if (string != null && !string.isBlank()) {
         String var2 = string.replace('\n', ',').replace('\r', ',');
         LinkedHashSet var3 = new LinkedHashSet();

         for (String var7 : var2.split(",")) {
            String var8 = var7 == null ? "" : var7.trim();
            if (!var8.isEmpty()) {
               var3.add(var8.toLowerCase(Locale.ROOT));
            }
         }

         return var3;
      } else {
         return Set.of();
      }
   }
}
