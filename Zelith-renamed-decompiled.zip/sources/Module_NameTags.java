import com.zelith.gui.ClickGUI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.EntityAttachmentType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3x2fStack;

public final class Module_NameTags extends Module {
   private static final Identifier LicenseState = Identifier.ofVanilla("hud/heart/container");
   private static final Identifier Module_f = Identifier.ofVanilla("hud/heart/full");
   private static final Identifier Category = Identifier.ofVanilla("hud/heart/half");
   private static final Identifier Module = Identifier.ofVanilla("hud/heart/absorbing_full");
   private static final Identifier SwapHelper = Identifier.ofVanilla("hud/heart/absorbing_half");
   private static final Pattern HwidGen = Pattern.compile("§.");
   public static bs HwidGen;
   private final dd bC = new Setting("Self", true);
   private final dd bD = new Setting("Name", true);
   private final dd bE = new Setting("Health", true);
   private final dd bF = new Setting("MainHand", true);
   private final dd bG = new Setting("OffHand", true);
   private final dd bH = new Setting("Armor", true);
   private final Map ClickBuf = new HashMap();
   private final dq HwidGen = new Obj_dq();
   private int Q = Integer.MIN_VALUE;

   public Module_NameTags() {
      super("Name Tags", Category.HwidGen);
      HwidGen = this;
      this.HwidGen(this.bC);
      this.HwidGen(this.bD);
      this.HwidGen(this.bE);
      this.HwidGen(this.bF);
      this.HwidGen(this.bG);
      this.HwidGen(this.bH);
   }

   public static boolean Module_f() {
      return HwidGen != null && HwidGen.HwidGen() && HwidGen != null && HwidGen.player != null;
   }

   public static void HwidGen(DrawContext drawContext, float f) {
      if (Module_f() && HwidGen.world != null && !HwidGen.options.hudHidden && !B()) {
         bs var2 = HwidGen;
         if (var2 != null) {
            var2.X();
            var2.Y();
            long var3 = System.currentTimeMillis();
            Camera var5 = Render_dm.HwidGen();
            if (var5 != null) {
               Vec3d var6 = Render_dm.HwidGen(var5);
               double var7 = var6.x;
               double var9 = var6.y;
               double var11 = var6.z;
               double var13 = 4096.0;
               double var15 = HwidGen.getWindow().getScaledWidth() * 0.5 * Math.abs(Render_dp.KeyFile.m00()) * 0.025F;
               double var17 = HwidGen.getWindow().getScaledHeight() * 0.5 * Math.abs(Render_dp.KeyFile.m11()) * 0.025F;
               Matrix3x2fStack var19 = drawContext.getMatrices();

               for (PlayerEntity var21 : HwidGen.world.getPlayers()) {
                  if (var2.c(var21)) {
                     double var22 = MathHelper.lerp(f, var21.lastRenderX, var21.getX());
                     double var24 = MathHelper.lerp(f, var21.lastRenderY, var21.getY());
                     double var26 = MathHelper.lerp(f, var21.lastRenderZ, var21.getZ());
                     double var28 = var22 - var7;
                     double var30 = var24 - var9;
                     double var32 = var26 - var11;
                     double var34 = var28 * var28 + var30 * var30 + var32 * var32;
                     if (!(var34 > var13)) {
                        bt var36 = var2.HwidGen(var21, var3);
                        if (!var36.C()) {
                           double var37 = Math.max(0.35, var21.getWidth() * 0.5);
                           if (Render_dm.HwidGen(var22 - var37, var24, var26 - var37, var22 + var37, var24 + var21.getHeight() + 1.25, var26 + var37)) {
                              float var39 = var2.HwidGen(var21, f, var22, var24, var26, var15, var17);
                              if (!(var39 <= 0.0F)) {
                                 var19.pushMatrix();
                                 HwidGen(var19, (float)var2.HwidGen.Module_Themes, (float)var2.HwidGen.Module_WaterMark, var39);
                                 HwidGen(drawContext, var36.HwidGen(), var36.Module_AutoInvTotem(), 0, false);
                                 HwidGen(drawContext, var36.HwidGen(), var36.HwidGen() != null ? 10 : 0);
                                 HwidGen(drawContext, var36.LicenseState(), var36.Module_AutoTotem(), var36.HwidGen() != null, var36.HwidGen() != null);
                                 var19.popMatrix();
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   public boolean c(LivingEntity livingEntity) {
      if (!livingEntity.isAlive() || livingEntity instanceof ArmorStandEntity || !(livingEntity instanceof PlayerEntity)) {
         return false;
      } else if (livingEntity != HwidGen.player && livingEntity.isInvisibleTo(HwidGen.player)) {
         return false;
      } else {
         return livingEntity != HwidGen.player
            ? true
            : (Boolean)this.bC.HwidGen()
               && (!HwidGen.options.getPerspective().isFirstPerson() || Module_Freecam.HwidGen != null && Module_Freecam.HwidGen.HwidGen());
      }
   }

   public boolean HwidGen(LivingEntity livingEntity, double d) {
      return this.c(livingEntity) && !B() ? d <= 4096.0 : false;
   }

   @Override
   public void LicenseState() {
      this.ClickBuf.clear();
      this.Q = Integer.MIN_VALUE;
   }

   @Override
   public void Module_f() {
      this.ClickBuf.clear();
   }

   @Override
   public void Category() {
   }

   public Text HwidGen(LivingEntity livingEntity) {
      MutableText var2 = Text.empty();
      boolean var3 = false;
      if ((Boolean)this.bD.HwidGen()) {
         Text var4;
         if (Module_FakeRoles.Module_f() && livingEntity == HwidGen.player) {
            var4 = Module_FakeRoles.HwidGen(HwidGen.getSession().getUsername());
         } else {
            var4 = livingEntity.getDisplayName();
         }

         if (var4 != null) {
            var2.append(var4.copy().formatted(Formatting.WHITE));
            var3 = true;
         }
      }

      if ((Boolean)this.bE.HwidGen()) {
         float var6 = Math.max(0.0F, livingEntity.getAbsorptionAmount());
         if (var6 > 0.0F) {
            int var5 = Math.max(1, MathHelper.ceil(var6));
            if (var3) {
               var2.append(Text.literal(" ").formatted(Formatting.GRAY));
            }

            var2.append(Text.literal("+" + var5).formatted(Formatting.GOLD));
            var3 = true;
         }
      }

      return var3 ? var2 : null;
   }

   private bu HwidGen(LivingEntity livingEntity) {
      if (!(Boolean)this.bE.HwidGen()) {
         return null;
      } else {
         float var2 = Math.max(1.0F, livingEntity.getMaxHealth());
         float var3 = MathHelper.clamp(livingEntity.getHealth(), 0.0F, var2);
         float var4 = Math.max(0.0F, livingEntity.getAbsorptionAmount());
         int var5 = Math.max(1, MathHelper.ceil(var2 / 2.0F));
         if (var5 > 10) {
            float var6 = 10.0F / var5;
            var3 *= var6;
            var4 *= var6;
            var5 = 10;
         }

         int var15 = MathHelper.clamp(Math.round(var3), 0, var5 * 2);
         int var7 = var15 / 2;
         boolean var8 = (var15 & 1) != 0;
         int var9 = Math.max(0, var5 - var7 - (var8 ? 1 : 0));
         int var10 = Math.max(0, Math.round(var4));
         int var11 = var10 / 2;
         boolean var12 = (var10 & 1) != 0;
         int var13 = var5 + var11 + (var12 ? 1 : 0);
         if (var7 <= 0 && !var8 && var11 <= 0 && !var12 && var9 <= 0) {
            return null;
         } else {
            int var14 = (var13 - 1) * 8 + 9;
            return new Rec_bu(var5, var7, var8, var9, var11, var12, var14);
         }
      }
   }

   public List HwidGen(LivingEntity livingEntity) {
      ArrayList var2 = new ArrayList(6);
      if ((Boolean)this.bG.HwidGen()) {
         this.HwidGen(var2, livingEntity.getOffHandStack());
      }

      if ((Boolean)this.bH.HwidGen()) {
         this.HwidGen(var2, livingEntity.getEquippedStack(EquipmentSlot.FEET));
         this.HwidGen(var2, livingEntity.getEquippedStack(EquipmentSlot.LEGS));
         this.HwidGen(var2, livingEntity.getEquippedStack(EquipmentSlot.CHEST));
         this.HwidGen(var2, livingEntity.getEquippedStack(EquipmentSlot.HEAD));
      }

      if ((Boolean)this.bF.HwidGen()) {
         this.HwidGen(var2, livingEntity.getMainHandStack());
      }

      return var2;
   }

   private void HwidGen(List list, ItemStack itemStack) {
      if (itemStack != null && !itemStack.isEmpty()) {
         list.add(new Rec_dl(itemStack.copy()));
      }
   }

   private static void HwidGen(DrawContext drawContext, List list, int i, boolean bl, boolean bl2) {
      if (!list.isEmpty()) {
         int var5 = -(i / 2);
         int var6 = bl2 ? 34 : (bl ? 16 : 0);
         int var7 = -var6;
         int var8 = var5 - 2;
         int var9 = var7 - 2;
         int var10 = i + 4;
         byte var11 = 20;
         Obj_dr.HwidGen(drawContext, (float)var8, (float)var9, (float)var10, (float)var11, 4.0F, -1728053248, false);

         for (int var12 = 0; var12 < list.size(); var12++) {
            ItemStack var13 = ((Rec_dl)list.get(var12)).KeyFile();
            int var14 = var5 + var12 * 18;
            drawContext.drawItem(var13, var14, var7);
            drawContext.drawStackOverlay(HwidGen.textRenderer, var13, var14, var7, null);
         }
      }
   }

   private static void HwidGen(DrawContext drawContext, Text text, int i, int j, boolean bl) {
      if (text != null) {
         int var5 = -(i / 2);
         int var6 = -j;
         if (bl) {
            String var7 = text.getString();

            for (int var8 = -1; var8 <= 1; var8++) {
               for (int var9 = -1; var9 <= 1; var9++) {
                  if (var8 != 0 || var9 != 0) {
                     drawContext.drawText(HwidGen.textRenderer, var7, var5 + var8, var6 + var9, -16777216, false);
                  }
               }
            }
         }

         drawContext.drawText(HwidGen.textRenderer, text, var5, var6, -1, false);
      }
   }

   private static void HwidGen(DrawContext drawContext, bu arg, int i) {
      if (arg != null) {
         int var3 = -(arg.C() / 2);
         int var4 = -i;

         for (int var5 = 0; var5 < arg.Module_DoubleAnchor(); var5++) {
            int var6 = var3 + var5 * 8;
            HwidGen(drawContext, LicenseState, var6, var4);
         }

         for (int var9 = 0; var9 < arg.A(); var9++) {
            int var12 = var3 + var9 * 8;
            HwidGen(drawContext, Module_f, var12, var4);
         }

         if (arg.D()) {
            int var10 = var3 + arg.A() * 8;
            HwidGen(drawContext, Category, var10, var4);
         }

         int var11 = var3 + arg.Module_DoubleAnchor() * 8;
         int var13 = arg.B() + (arg.E() ? 1 : 0);

         for (int var7 = 0; var7 < var13; var7++) {
            int var8 = var11 + var7 * 8;
            HwidGen(drawContext, LicenseState, var8, var4);
         }

         for (int var14 = 0; var14 < arg.B(); var14++) {
            int var16 = var11 + var14 * 8;
            HwidGen(drawContext, Module, var16, var4);
         }

         if (arg.E()) {
            int var15 = var11 + arg.B() * 8;
            HwidGen(drawContext, SwapHelper, var15, var4);
         }
      }
   }

   private static void HwidGen(DrawContext drawContext, Identifier identifier, int i, int j) {
      drawContext.drawGuiTexture(RenderPipelines.GUI_TEXTURED, identifier, i, j, 9, 9);
   }

   private void X() {
      int var1 = this.Module_AutoDoubleHand();
      if (var1 != this.Q) {
         this.Q = var1;
         this.ClickBuf.clear();
      }
   }

   private void Y() {
      if (HwidGen.world != null && this.ClickBuf.size() > HwidGen.world.getPlayers().size() + 8) {
         this.ClickBuf.keySet().removeIf(uUID -> HwidGen.world.getPlayerByUuid(uUID) == null);
      }
   }

   private int Module_AutoDoubleHand() {
      byte var1 = 0;
      if ((Boolean)this.bC.HwidGen()) {
         var1 |= 1;
      }

      if ((Boolean)this.bD.HwidGen()) {
         var1 |= 2;
      }

      if ((Boolean)this.bE.HwidGen()) {
         var1 |= 4;
      }

      if ((Boolean)this.bF.HwidGen()) {
         var1 |= 8;
      }

      if ((Boolean)this.bG.HwidGen()) {
         var1 |= 16;
      }

      if ((Boolean)this.bH.HwidGen()) {
         var1 |= 32;
      }

      return var1;
   }

   private bt HwidGen(PlayerEntity playerEntity, long l) {
      Rec_bt var4 = (Rec_bt)this.ClickBuf.get(playerEntity.getUuid());
      if (var4 != null && var4.KeyFile() > l) {
         return var4;
      } else {
         Text var5 = this.HwidGen(playerEntity);
         List var6 = this.HwidGen(playerEntity);
         Rec_bt var7 = new Rec_bt(
            l + 125L,
            var5,
            var5 != null ? HwidGen.textRenderer.getWidth(var5) : 0,
            this.HwidGen(playerEntity),
            var6,
            var6.isEmpty() ? 0 : var6.size() * 16 + (var6.size() - 1) * 2
         );
         this.ClickBuf.put(playerEntity.getUuid(), var7);
         return var7;
      }
   }

   private static void HwidGen(Matrix3x2fStack matrix3x2fStack, float f, float g, float h) {
      matrix3x2fStack.translate(f, g);
      matrix3x2fStack.scale(h, h);
   }

   private float HwidGen(PlayerEntity playerEntity, float f, double d, double e, double g, double h, double i) {
      Vec3d var13 = playerEntity.getAttachments().getPointNullable(EntityAttachmentType.NAME_TAG, 0, playerEntity.getLerpedYaw(f));
      double var14;
      double var16;
      double var18;
      if (var13 == null) {
         var14 = d;
         var16 = e + playerEntity.getHeight() + 0.5 + 0.62;
         var18 = g;
      } else {
         var14 = d + var13.x;
         var16 = e + var13.y + 0.62;
         var18 = g + var13.z;
      }

      if (!Render_dp.HwidGen(Render_dp.c, Render_dp.KeyFile, var14, var16, var18, this.HwidGen)) {
         return 0.0F;
      } else if (this.HwidGen.X && !(this.HwidGen.Module_zelith < 0.0) && !(this.HwidGen.Module_zelith > 1.0) && !(this.HwidGen.Module_AnchorMacro <= 0.0)) {
         double var20 = h / this.HwidGen.Module_AnchorMacro;
         double var22 = i / this.HwidGen.Module_AnchorMacro;
         float var24 = (float)((var20 + var22) * 0.5);
         return Float.isFinite(var24) && var24 > 0.0F ? var24 : 0.0F;
      } else {
         return 0.0F;
      }
   }

   private static boolean B() {
      return HwidGen.currentScreen instanceof ClickGUI;
   }
}
