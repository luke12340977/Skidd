import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Collection;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult.Type;

public final class Module_AutoLog extends Module {
   private long Module_Configs;
   private long Module_Friends;
   private long Module_Hud;
   private float LicenseState = -1.0F;
   private int L = -1;
   private int M = -1;

   public Module_AutoLog() {
      super("Auto Log", Category.HwidGen);
   }

   @Override
   public void LicenseState() {
      this.Module_Configs = 0L;
      this.Module_Friends = 0L;
      this.Module_Hud = 0L;
      this.LicenseState = this.c();
      this.L = this.Module_AnchorMacro();
      this.M = this.Module_AutoCrystal();
      if (HwidGen.player != null && HwidGen.world != null && (this.Module_Themes() || this.Module_WaterMark() || this.Module_AutoInvTotem())) {
         this.c(System.currentTimeMillis());
      }
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.world != null) {
         long var1 = System.currentTimeMillis();
         float var3 = this.c();
         boolean var4 = this.LicenseState >= 0.0F && var3 + 0.001F < this.LicenseState;
         this.LicenseState = var3;
         if (HwidGen.player.hurtTime > 0 || var4 || this.Module_zelith()) {
            this.Module_Configs = var1;
         }

         boolean var5 = this.Module_AutoInvTotem();
         if (var5) {
            this.Module_Hud = var1;
         }

         if (HwidGen.options.attackKey.isPressed()
            && HwidGen.crosshairTarget != null
            && HwidGen.crosshairTarget.getType() == Type.ENTITY
            && HwidGen.crosshairTarget instanceof EntityHitResult var6
            && var6.getEntity() instanceof PlayerEntity var7
            && var7 != HwidGen.player) {
            this.Module_Friends = var1;
         }

         if (this.Module_AnchorMacro()) {
            this.Module_Friends = var1;
         }

         if (!this.HwidGen(var1, var5)) {
            for (PlayerEntity var10 : HwidGen.world.getPlayers()) {
               if (var10 != HwidGen.player && !var10.isSpectator() && (!Module_Friends.LicenseResult() || !Module_Friends.HwidGen(var10.getName().getString()))
                  )
                {
                  if (HwidGen.getNetworkHandler() != null) {
                     HwidGen.getNetworkHandler().getConnection().disconnect(Text.literal("[AutoLog] Player detected: " + var10.getName().getString()));
                  }

                  return;
               }
            }
         }
      }
   }

   private boolean HwidGen(long l, boolean bl) {
      if (bl || this.Module_WaterMark() || l - this.Module_Hud < 1500L) {
         return true;
      } else if (this.Module_Configs <= 0L && this.Module_Friends <= 0L) {
         return false;
      } else {
         long var4 = Math.max(this.Module_Configs, this.Module_Friends);
         return l - var4 < 20000L;
      }
   }

   private boolean Module_Themes() {
      if (HwidGen.player != null && HwidGen.world != null) {
         if (HwidGen.player.hurtTime <= 0 && !this.Module_WaterMark()) {
            if (HwidGen.crosshairTarget != null
               && HwidGen.crosshairTarget.getType() == Type.ENTITY
               && HwidGen.crosshairTarget instanceof EntityHitResult var1
               && var1.getEntity() instanceof PlayerEntity var2
               && var2 != HwidGen.player
               && !var2.isSpectator()) {
               return true;
            } else {
               double var5 = 64.0;

               for (PlayerEntity var4 : HwidGen.world.getPlayers()) {
                  if (var4 != HwidGen.player && !var4.isSpectator() && HwidGen.player.squaredDistanceTo(var4) <= var5) {
                     return true;
                  }
               }

               return false;
            }
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private void c(long l) {
      this.Module_Configs = l;
      this.Module_Friends = l;
      this.Module_Hud = l;
   }

   private boolean Module_WaterMark() {
      return this.Module_AutoCrystal() || this.Module_AutoDoubleHand();
   }

   private boolean Module_zelith() {
      int var1 = this.Module_AnchorMacro();
      if (var1 > 0 && var1 != this.L) {
         this.L = var1;
         return this.Module_AutoCrystal();
      } else {
         return false;
      }
   }

   private boolean Module_AnchorMacro() {
      int var1 = this.Module_AutoCrystal();
      if (var1 > 0 && var1 != this.M) {
         this.M = var1;
         return this.Module_AutoDoubleHand();
      } else {
         return false;
      }
   }

   private boolean Module_AutoCrystal() {
      if (HwidGen.player == null) {
         return false;
      } else {
         return HwidGen.player.getLastAttacker() instanceof PlayerEntity var1 && var1 != HwidGen.player && !var1.isSpectator()
            ? this.KeyFile(HwidGen.player.getLastAttackedTime())
            : false;
      }
   }

   private boolean Module_AutoDoubleHand() {
      if (HwidGen.player == null) {
         return false;
      } else {
         return HwidGen.player.getAttacking() instanceof PlayerEntity var1 && var1 != HwidGen.player && !var1.isSpectator()
            ? this.KeyFile(HwidGen.player.getLastAttackTime())
            : false;
      }
   }

   private boolean KeyFile(int i) {
      if (HwidGen.player != null && i > 0) {
         int var2 = HwidGen.player.age - i;
         return var2 >= 0 && var2 < 400;
      } else {
         return false;
      }
   }

   private int Module_AnchorMacro() {
      return HwidGen.player != null ? HwidGen.player.getLastAttackedTime() : -1;
   }

   private int Module_AutoCrystal() {
      return HwidGen.player != null ? HwidGen.player.getLastAttackTime() : -1;
   }

   private boolean Module_AutoInvTotem() {
      if (HwidGen.world != null && this.HwidGen(HwidGen.world.getScoreboard())) {
         return true;
      } else {
         Set var1 = Collections.newSetFromMap(new IdentityHashMap());
         return HwidGen.inGameHud != null && this.HwidGen(HwidGen.inGameHud, 0, var1);
      }
   }

   private boolean HwidGen(Scoreboard scoreboard) {
      if (scoreboard == null) {
         return false;
      } else {
         for (ScoreboardObjective var3 : scoreboard.getObjectives()) {
            if (this.LicenseState(var3.getName()) || this.HwidGen(var3.getDisplayName())) {
               return true;
            }
         }

         for (ScoreboardDisplaySlot var5 : ScoreboardDisplaySlot.values()) {
            ScoreboardObjective var6 = scoreboard.getObjectiveForSlot(var5);
            if (var6 != null) {
               if (this.LicenseState(var6.getName()) || this.HwidGen(var6.getDisplayName())) {
                  return true;
               }

               for (ScoreboardEntry var8 : scoreboard.getScoreboardEntries(var6)) {
                  if (this.LicenseState(var8.owner()) || this.HwidGen(var8.name()) || this.HwidGen(var8.display())) {
                     return true;
                  }

                  Team var9 = scoreboard.getScoreHolderTeam(var8.owner());
                  if (this.HwidGen(var9)) {
                     return true;
                  }
               }
            }
         }

         for (Team var13 : scoreboard.getTeams()) {
            if (this.HwidGen(var13)) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean HwidGen(Team team) {
      return team != null
         && (this.LicenseState(team.getName()) || this.HwidGen(team.getDisplayName()) || this.HwidGen(team.getPrefix()) || this.HwidGen(team.getSuffix()));
   }

   private boolean HwidGen(Object object, int i, Set set) {
      if (object == null || i > 4) {
         return false;
      } else if (object instanceof Text var15) {
         return this.LicenseState(var15.getString());
      } else if (object instanceof String var14) {
         return this.LicenseState(var14);
      } else if (!set.add(object)) {
         return false;
      } else if (object instanceof Map var13) {
         for (Entry var19 : var13.entrySet()) {
            if (this.HwidGen(var19.getKey(), i + 1, set) || this.HwidGen(var19.getValue(), i + 1, set)) {
               return true;
            }
         }

         return false;
      } else if (object instanceof Collection) {
         for (Object var18 : (Collection)object) {
            if (this.HwidGen(var18, i + 1, set)) {
               return true;
            }
         }

         return false;
      } else {
         Class var4 = object.getClass();
         if (!this.HwidGen(var4)) {
            return false;
         } else {
            for (Class var5 = var4; var5 != null && var5 != Object.class; var5 = var5.getSuperclass()) {
               for (Field var9 : var5.getDeclaredFields()) {
                  if (!Modifier.isStatic(var9.getModifiers()) && !var9.getType().isPrimitive()) {
                     var9.setAccessible(true);

                     try {
                        Object var10 = var9.get(object);
                        if (this.HwidGen(var10, i + 1, set)) {
                           return true;
                        }
                     } catch (IllegalAccessException var11) {
                     }
                  }
               }
            }

            return false;
         }
      }
   }

   private boolean HwidGen(Class class_) {
      String var2 = class_.getName();
      return var2.startsWith("net.minecraft.scoreboard.")
         || var2.startsWith("net.minecraft.text.")
         || var2.startsWith("net.minecraft.client.gui.hud.")
         || var2.startsWith("net.minecraft.client.network.")
         || var2.startsWith("java.util.");
   }

   private boolean LicenseState(String string) {
      if (string == null) {
         return false;
      } else {
         String var2 = string.toLowerCase();
         return var2.contains("combat");
      }
   }

   private boolean HwidGen(Text text) {
      return text != null && this.LicenseState(text.getString());
   }

   private float c() {
      return HwidGen.player == null ? -1.0F : HwidGen.player.getHealth() + HwidGen.player.getAbsorptionAmount();
   }
}
