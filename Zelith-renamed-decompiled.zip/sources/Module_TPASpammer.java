import net.minecraft.text.Text;

public final class Module_TPASpammer extends Module {
   private final dd bM = new Setting("Target Player", "");
   private final dd bN = new Setting("TPA Here", false);
   private final dd bO = new Setting("Delay", 20, 10, 200);
   private int tickCounter = 0;

   public Module_TPASpammer() {
      super("TPA Spammer", Category.HwidGen);
      this.HwidGen(this.bM);
      this.HwidGen(this.bN);
      this.HwidGen(this.bO);
   }

   @Override
   public void LicenseState() {
      this.tickCounter = 0;
      String var1 = ((String)this.bM.HwidGen()).trim();
      if (var1.isEmpty()) {
         HwidGen.inGameHud.getChatHud().addMessage(Text.literal("§c[TPA Spammer] Please set a target player name."));
         this.c();
      } else {
         HwidGen.inGameHud.getChatHud().addMessage(Text.literal("§a[TPA Spammer] Started spamming requests to: " + var1));
      }
   }

   @Override
   public void Module_f() {
      HwidGen.inGameHud.getChatHud().addMessage(Text.literal("§c[TPA Spammer] Stopped."));
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.getNetworkHandler() != null) {
         this.tickCounter++;
         if (this.tickCounter >= (Integer)this.bO.HwidGen()) {
            this.Module_Hitbox();
            this.tickCounter = 0;
         }
      }
   }

   private void Module_Hitbox() {
      String var1 = ((String)this.bM.HwidGen()).trim();
      if (var1.isEmpty()) {
         HwidGen.inGameHud.getChatHud().addMessage(Text.literal("§c[TPA Spammer] Target player name is empty."));
         this.c();
      } else {
         String var2 = this.bN.HwidGen() ? "tpahere" : "tpa";
         HwidGen.getNetworkHandler().sendChatCommand(var2 + " " + var1);
         HwidGen.inGameHud.getChatHud().addMessage(Text.literal("§a[TPA Spammer] Sent " + var2.toUpperCase() + " request to: " + var1));
      }
   }
}
