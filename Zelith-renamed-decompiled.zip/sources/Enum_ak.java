enum Enum_ak {
   KeyFile,
   c,
   LicenseResult,
   LicenseState,
   Module_f,
   Category,
   Module,
   SwapHelper,
   Module_j,
   Module_ActiveModules,
   ClickBuf,
   Module_Configs,
   Module_Friends,
   Module_Hud;

   public static ak[] values() {
      return (ak[])HwidGen.clone();
   }

   public static ak valueOf(String string) {
      return Enum.valueOf(Enum_ak.class, string);
   }
}
