import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.CommandExecutionC2SPacket;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

public final class Module_FakePay extends Module {
   public Module_FakePay() {
      super("Fake Pay", Category.LicenseState);
   }

   @Override
   public boolean HwidGen(Packet packet) {
      if (!this.HwidGen()) {
         return false;
      } else if (HwidGen.player == null || HwidGen.world == null) {
         return false;
      } else if (packet instanceof CommandExecutionC2SPacket var2) {
         String var3 = var2.command().trim();
         if (!var3.startsWith("pay ")) {
            return false;
         } else {
            String[] var4 = var3.substring(4).split(" ");
            if (var4.length < 2) {
               return false;
            } else {
               String var5 = var4[0];
               String var6 = var4[1];
               long var7 = this.KeyFile(var6);
               if (var7 >= 1000L && var7 <= 1000000000000000L) {
                  String var9 = this.KeyFile(var7);
                  String var10 = this.c(var7);
                  MutableText var11 = Text.literal("You paid ").setStyle(Style.EMPTY.withColor(11184810));
                  var11.append(Text.literal(var5).setStyle(Style.EMPTY.withColor(1024999)));
                  var11.append(Text.literal(" ").setStyle(Style.EMPTY.withColor(16777215)));
                  var11.append(Text.literal("$" + var9 + var10).setStyle(Style.EMPTY.withColor(5635925)));
                  var11.append(Text.literal(".").setStyle(Style.EMPTY.withColor(11184810)));
                  if (HwidGen.inGameHud != null) {
                     HwidGen.inGameHud.getChatHud().addMessage(var11);
                  }

                  if (HwidGen.player != null) {
                     HwidGen.player.playSound(SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.0F);
                  }

                  as var12 = Module_FakeScoreboard.HwidGen();
                  if (var12 != null && var12.HwidGen()) {
                     var12.HwidGen(var7);
                  }

                  return true;
               } else {
                  return true;
               }
            }
         }
      } else {
         return false;
      }
   }

   private long KeyFile(String string) {
      string = string.toLowerCase().trim();

      try {
         if (string.endsWith("Module_ActiveModules")) {
            return (long)(Double.parseDouble(string.substring(0, string.length() - 1)) * 1000.0);
         } else if (string.endsWith("Module_Configs")) {
            return (long)(Double.parseDouble(string.substring(0, string.length() - 1)) * 1000000.0);
         } else if (string.endsWith("KeyFile")) {
            return (long)(Double.parseDouble(string.substring(0, string.length() - 1)) * 1.0E9);
         } else {
            return string.endsWith("Module_zelith") ? (long)(Double.parseDouble(string.substring(0, string.length() - 1)) * 1.0E12) : Long.parseLong(string);
         }
      } catch (NumberFormatException var3) {
         return -1L;
      }
   }

   private String KeyFile(long l) {
      if (l >= 1000000000000L) {
         return String.format("%.0f", l / 1.0E12);
      } else if (l >= 1000000000L) {
         return String.format("%.0f", l / 1.0E9);
      } else if (l >= 1000000L) {
         return String.format("%.0f", l / 1000000.0);
      } else {
         return l >= 1000L ? String.format("%.0f", l / 1000.0) : String.valueOf(l);
      }
   }

   private String c(long l) {
      if (l >= 1000000000000L) {
         return "T";
      } else if (l >= 1000000000L) {
         return "B";
      } else if (l >= 1000000L) {
         return "M";
      } else {
         return l >= 1000L ? "K" : "";
      }
   }
}
