import net.minecraft.util.math.ChunkPos;

record Rec_aw() {
   final ChunkPos KeyFile;
   final int Module_DoubleAnchor;
   final ChunkPos c;
   final boolean Module_AutoDoubleHand;
   final boolean Module_AutoInvTotem;
   final int A;

   Rec_aw(ChunkPos chunkPos, int i, ChunkPos chunkPos2, boolean bl, boolean bl2, int j) {
      this.KeyFile = chunkPos;
      this.Module_DoubleAnchor = i;
      this.c = chunkPos2;
      this.Module_AutoDoubleHand = bl;
      this.Module_AutoInvTotem = bl2;
      this.A = j;
   }
}
