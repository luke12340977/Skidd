import java.util.Random;
import net.minecraft.util.Hand;

public final class Module_AntiAFK extends Module {
   private final dd Module_AntiAFK = new Setting("Jump", true);
   private final dd Module_AutoEat = new Setting("Swing", false);
   private final dd Module_AutoLog = new Setting("Sneak", false);
   private final dd Module_AutoTool = new Setting("Sneak Ticks", 5, 1, 20);
   private final dd Module_CoordSnapper = new Setting("Strafe", false);
   private final dd Rec_bm = new Setting("Spin", true);
   private final dd Module_FakePlayer = new Setting("Spin Speed", 7, 1, 30);
   private final Random c = new Random();
   private int H;
   private int I;
   private boolean D;
   private float LicenseResult;

   public Module_AntiAFK() {
      super("Anti AFK", Category.HwidGen);
      this.HwidGen(this.Module_AntiAFK);
      this.HwidGen(this.Module_AutoEat);
      this.HwidGen(this.Module_AutoLog);
      this.HwidGen(this.Module_AutoTool);
      this.HwidGen(this.Module_CoordSnapper);
      this.HwidGen(this.Rec_bm);
      this.HwidGen(this.Module_FakePlayer);
   }

   @Override
   public void LicenseState() {
      this.LicenseResult = HwidGen.player != null ? HwidGen.player.getYaw() : 0.0F;
      this.H = 0;
      this.I = 0;
      this.D = false;
   }

   @Override
   public void Module_f() {
      if (HwidGen.options != null) {
         HwidGen.options.sneakKey.setPressed(false);
         HwidGen.options.leftKey.setPressed(false);
         HwidGen.options.rightKey.setPressed(false);
      }
   }

   @Override
   public void Category() {
      if (HwidGen.player != null) {
         if ((Boolean)this.Module_AntiAFK.HwidGen()) {
            if (HwidGen.options.jumpKey.isPressed()) {
               HwidGen.options.jumpKey.setPressed(false);
            } else if (this.c.nextInt(99) == 0) {
               HwidGen.options.jumpKey.setPressed(true);
            }
         }

         if ((Boolean)this.Module_AutoEat.HwidGen() && this.c.nextInt(99) == 0) {
            HwidGen.player.swingHand(Hand.MAIN_HAND);
         }

         if ((Boolean)this.Module_AutoLog.HwidGen()) {
            if (this.H >= (Integer)this.Module_AutoTool.HwidGen()) {
               HwidGen.options.sneakKey.setPressed(false);
               if (this.c.nextInt(99) == 0) {
                  this.H = 0;
               }
            } else {
               HwidGen.options.sneakKey.setPressed(true);
               this.H++;
            }
         }

         if ((Boolean)this.Module_CoordSnapper.HwidGen() && this.I-- <= 0) {
            HwidGen.options.leftKey.setPressed(!this.D);
            HwidGen.options.rightKey.setPressed(this.D);
            this.D = !this.D;
            this.I = 20;
         }

         if ((Boolean)this.Rec_bm.HwidGen()) {
            this.LicenseResult = this.LicenseResult + ((Integer)this.Module_FakePlayer.HwidGen()).intValue();
            HwidGen.player.setYaw(this.LicenseResult);
         }
      }
   }
}
