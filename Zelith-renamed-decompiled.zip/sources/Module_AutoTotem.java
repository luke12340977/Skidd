import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public final class Module_AutoTotem extends Module {
   private final dd L = new Setting("Delay", 1.0F, 0.0F, 5.0F);
   private int ClickBuf;

   public Module_AutoTotem() {
      super("Auto Totem", Category.c);
      this.HwidGen(this.L);
   }

   @Override
   public void LicenseState() {
      super.LicenseState();
   }

   @Override
   public void Module_f() {
      super.Module_f();
   }

   @Override
   public void Category() {
      if (HwidGen.player != null) {
         if (HwidGen.player.getOffHandStack().getItem() == Items.TOTEM_OF_UNDYING) {
            this.ClickBuf = ((Float)this.L.HwidGen()).intValue();
         } else if (this.ClickBuf > 0) {
            this.ClickBuf--;
         } else {
            int var1 = this.HwidGen(Items.TOTEM_OF_UNDYING);
            if (var1 != -1) {
               HwidGen.interactionManager.clickSlot(HwidGen.player.currentScreenHandler.syncId, LicenseState(var1), 40, SlotActionType.SWAP, HwidGen.player);
               this.ClickBuf = ((Float)this.L.HwidGen()).intValue();
            }
         }
      }
   }

   public int HwidGen(Item item) {
      if (HwidGen.player == null) {
         return -1;
      } else {
         for (int var2 = 0; var2 < 36; var2++) {
            if (HwidGen.player.getInventory().getStack(var2).isOf(item)) {
               return var2;
            }
         }

         return -1;
      }
   }

   private static int LicenseState(int i) {
      return i < 9 ? 36 + i : i;
   }
}
