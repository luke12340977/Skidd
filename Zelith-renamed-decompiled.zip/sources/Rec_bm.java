record Rec_bm() {
   private final String Module_AnchorMacro;
   private final String Module_AutoCrystal;
   private final int N;
   private final int O;
   private final int P;
   private final String Module_AutoDoubleHand;
   private final String Module_AutoInvTotem;
   private final String Module_AutoTotem;

   Rec_bm(String string, String string2, int i, int j, int k, String string3, String string4, String string5) {
      this.Module_AnchorMacro = string;
      this.Module_AutoCrystal = string2;
      this.N = i;
      this.O = j;
      this.P = k;
      this.Module_AutoDoubleHand = string3;
      this.Module_AutoInvTotem = string4;
      this.Module_AutoTotem = string5;
   }

   String Module_Themes() {
      return "X: " + this.N + " Y: " + this.O + " Z: " + this.P;
   }

   String Module_WaterMark() {
      return this.N + ", " + this.O + ", " + this.P;
   }

   public String Module() {
      return this.Module_AnchorMacro;
   }

   public String Module_ActiveModules() {
      return this.Module_AutoCrystal;
   }

   public String Module_Friends() {
      return this.Module_AutoDoubleHand;
   }

   public String Module_Hud() {
      return this.Module_AutoInvTotem;
   }

   public String HudElement() {
      return this.Module_AutoTotem;
   }
}
