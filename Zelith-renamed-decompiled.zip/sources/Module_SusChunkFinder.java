import java.awt.Color;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.block.AbstractPlantStemBlock;
import net.minecraft.block.AmethystClusterBlock;
import net.minecraft.block.BambooBlock;
import net.minecraft.block.BeehiveBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PillarBlock;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.world.chunk.WorldChunk;

public final class Module_SusChunkFinder extends Module {
   private final dd aX = new Setting("Simulation Distance", 4, 2, 16);
   private final dd aY = new Setting("Sensitivity", 3, 1, 20);
   private final dd aZ = new Setting("Alpha", 80.0F, 10.0F, 255.0F);
   private final dd Module_RegionMap = new Setting("Kelp", true);
   private final dd Module_SpawnerFinder = new Setting("Cave Vines", true);
   private final dd Module_SpawnerProtect = new Setting("Vines", true);
   private final dd Rec_bd = new Setting("Amethyst", true);
   private final dd Module_StashFinder = new Setting("Bamboo", true);
   private final dd Toast_bf = new Setting("Bee Nest", true);
   private final dd Module_SusChunkFinder = new Setting("Rotated Deepslate", true);
   private final Set Module_j = ConcurrentHashMap.newKeySet();
   private int Module_Themes;

   public Module_SusChunkFinder() {
      super("Sus Chunk Finder", Category.LicenseState);
      this.HwidGen(this.aX);
      this.HwidGen(this.aY);
      this.HwidGen(this.aZ);
      this.HwidGen(this.Module_RegionMap);
      this.HwidGen(this.Module_SpawnerFinder);
      this.HwidGen(this.Module_SpawnerProtect);
      this.HwidGen(this.Rec_bd);
      this.HwidGen(this.Module_StashFinder);
      this.HwidGen(this.Toast_bf);
      this.HwidGen(this.Module_SusChunkFinder);
   }

   @Override
   public void LicenseState() {
      this.F();
   }

   @Override
   public void Module_f() {
      this.F();
   }

   @Override
   public void Category() {
      if (HwidGen.world != null && HwidGen.player != null) {
         int var1 = (Integer)this.aX.HwidGen();
         ChunkPos var2 = HwidGen.player.getChunkPos();
         int var3 = var1 * 2 + 1;
         int var4 = var3 * var3;

         for (int var5 = 0; var5 < 8; var5++) {
            int var6 = this.Module_Themes % var4;
            this.Module_Themes = (this.Module_Themes + 1) % var4;
            int var7 = var6 % var3 - var1;
            int var8 = var6 / var3 - var1;
            int var9 = var2.x + var7;
            int var10 = var2.z + var8;
            WorldChunk var11 = HwidGen.world.getChunkManager().getWorldChunk(var9, var10, false);
            if (var11 != null && !var11.isEmpty()) {
               ChunkPos var12 = new ChunkPos(var9, var10);
               int var13 = this.HwidGen(var11, var12);
               if (var13 >= (Integer)this.aY.HwidGen()) {
                  this.Module_j.add(var12);
               } else {
                  this.Module_j.remove(var12);
               }
            }
         }

         this.Module_j.removeIf(chunkPos2 -> this.HwidGen(chunkPos2, var2, var1));
      }
   }

   private int HwidGen(WorldChunk worldChunk, ChunkPos chunkPos) {
      int var3 = chunkPos.getStartX();
      int var4 = chunkPos.getStartZ();
      int var5 = 0;
      Mutable var6 = new Mutable();

      for (int var7 = 0; var7 < 16; var7++) {
         for (int var8 = 0; var8 < 16; var8++) {
            for (int var9 = -64; var9 < 320; var9++) {
               int var10 = var3 + var7;
               int var11 = var4 + var8;
               var6.set(var10, var9, var11);
               BlockState var12 = worldChunk.getBlockState(var6);
               if (!var12.isAir()) {
                  Block var13 = var12.getBlock();
                  if ((Boolean)this.Rec_bd.HwidGen() && var13 == Blocks.AMETHYST_CLUSTER) {
                     var5++;
                  }

                  if ((Boolean)this.Rec_bd.HwidGen()) {
                     try {
                        if (var12.contains(AmethystClusterBlock.WATERLOGGED) && (Boolean)var12.get(AmethystClusterBlock.WATERLOGGED)) {
                           var5++;
                        }
                     } catch (Throwable var15) {
                     }
                  }

                  if ((Boolean)this.Module_RegionMap.HwidGen()) {
                     try {
                        if (var13 == Blocks.KELP || var13 == Blocks.KELP_PLANT) {
                           var6.set(var10, var9 + 1, var11);
                           BlockState var14 = worldChunk.getBlockState(var6);
                           var6.set(var10, var9, var11);
                           if (var14.getBlock() == Blocks.KELP || var14.getBlock() == Blocks.KELP_PLANT) {
                              var5++;
                           }
                        }
                     } catch (Throwable var21) {
                     }
                  }

                  if ((Boolean)this.Module_SpawnerFinder.HwidGen()) {
                     try {
                        if (var13 == Blocks.CAVE_VINES && var12.contains(AbstractPlantStemBlock.AGE) && (Integer)var12.get(AbstractPlantStemBlock.AGE) == 25) {
                           var6.set(var10, var9 - 1, var11);
                           BlockState var22 = worldChunk.getBlockState(var6);
                           var6.set(var10, var9, var11);
                           if (var22.isAir()) {
                              var5++;
                           }
                        }
                     } catch (Throwable var20) {
                     }
                  }

                  if ((Boolean)this.Module_SpawnerProtect.HwidGen()) {
                     try {
                        if (var13 == Blocks.VINE) {
                           var6.set(var10, var9 + 1, var11);
                           BlockState var23 = worldChunk.getBlockState(var6);
                           var6.set(var10, var9, var11);
                           if (var23.getBlock() != Blocks.VINE) {
                              var5++;
                           }
                        }
                     } catch (Throwable var19) {
                     }
                  }

                  if ((Boolean)this.Module_StashFinder.HwidGen()) {
                     try {
                        if (var13 == Blocks.BAMBOO && var12.contains(BambooBlock.AGE) && (Integer)var12.get(BambooBlock.AGE) == 1) {
                           var6.set(var10, var9 + 1, var11);
                           BlockState var24 = worldChunk.getBlockState(var6);
                           var6.set(var10, var9, var11);
                           if (var24.getBlock() == Blocks.BAMBOO) {
                              var5++;
                           }
                        }
                     } catch (Throwable var18) {
                     }
                  }

                  if ((Boolean)this.Toast_bf.HwidGen()) {
                     try {
                        if (var13 == Blocks.BEE_NEST && var12.contains(BeehiveBlock.HONEY_LEVEL) && (Integer)var12.get(BeehiveBlock.HONEY_LEVEL) == 5) {
                           var5++;
                        }
                     } catch (Throwable var17) {
                     }
                  }

                  if ((Boolean)this.Module_SusChunkFinder.HwidGen() && var9 >= 0 && var9 <= 60) {
                     try {
                        if (var13 == Blocks.DEEPSLATE && var12.contains(PillarBlock.AXIS) && var12.get(PillarBlock.AXIS) != Axis.Y) {
                           var5++;
                        }
                     } catch (Throwable var16) {
                     }
                  }
               }
            }
         }
      }

      return var5;
   }

   @Override
   public void HwidGen(MatrixStack matrixStack, float f) {
      if (HwidGen.world != null && HwidGen.player != null && !this.Module_j.isEmpty()) {
         Camera var3 = Render_dm.HwidGen();
         if (var3 != null) {
            Vec3d var4 = Render_dm.HwidGen(var3);
            int var5 = Math.max(10, Math.min(255, ((Float)this.aZ.HwidGen()).intValue()));
            Color var6 = new Color(255, 80, 80, var5);
            matrixStack.push();
            do var7 = Render_dm.HwidGen(matrixStack);

            for (ChunkPos var9 : this.Module_j) {
               double var10 = var9.getStartX() - var4.x;
               double var12 = var9.getStartZ() - var4.z;
               double var14 = var10 + 16.0;
               double var16 = var12 + 16.0;
               double var18 = 55.0 - var4.y;
               double var20 = var18 + 0.001;
               var7.HwidGen(var10, var18, var12, var14, var20, var16, var6);
            }

            var7.Module_FakePay();
            matrixStack.pop();
         }
      }
   }

   private boolean HwidGen(ChunkPos chunkPos, ChunkPos chunkPos2, int i) {
      return Math.abs(chunkPos.x - chunkPos2.x) > i || Math.abs(chunkPos.z - chunkPos2.z) > i;
   }

   private void F() {
      this.Module_j.clear();
      this.Module_Themes = 0;
   }
}
