import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.item.ItemStack;

public final class Module_AutoEat extends Module {
   private final dd Module_FastPlace = new Setting("Hunger", 16, 1, 19);
   private final cy Module_f = new Misc_cy("Priority", "Saturation", "Combined", "Hunger", "Saturation");
   public boolean E;
   private int J;
   private int K;

   public Module_AutoEat() {
      super("Auto Eat", Category.HwidGen);
      this.HwidGen(this.Module_FastPlace);
      this.HwidGen(this.Module_f);
   }

   @Override
   public void Module_f() {
      if (this.E) {
         this.S();
      }
   }

   @Override
   public void Category() {
      if (HwidGen.player != null) {
         if (this.E) {
            if (!this.Module_SpotifyHUD()) {
               this.S();
            } else {
               if (!this.c(HwidGen.player.getInventory().getStack(this.J))) {
                  int var1 = this.Module_zelith();
                  if (var1 == -1) {
                     this.S();
                     return;
                  }

                  this.HwidGen(var1);
               }

               this.R();
            }
         } else {
            if (this.Module_SpotifyHUD()) {
               this.Q();
            }
         }
      }
   }

   private void Q() {
      this.K = HwidGen.player.getInventory().getSelectedSlot();
      this.R();
   }

   private void R() {
      if (this.HwidGen(this.J)) {
         HwidGen.options.useKey.setPressed(true);
         if (!HwidGen.player.isUsingItem()) {
            HwidGen.interactionManager.interactItem(HwidGen.player, HwidGen.player.getActiveHand());
         }

         this.E = true;
      }
   }

   private void S() {
      if (this.K >= 0 && this.K <= 8 && this.K != HwidGen.player.getInventory().getSelectedSlot()) {
         HwidGen.player.getInventory().setSelectedSlot(this.K);
      }

      HwidGen.options.useKey.setPressed(false);
      this.E = false;
      this.J = -1;
      this.K = -1;
   }

   private boolean HwidGen(int i) {
      if (i >= 0 && i <= 8) {
         HwidGen.player.getInventory().setSelectedSlot(i);
         this.J = i;
         return true;
      } else {
         return false;
      }
   }

   private boolean Module_SpotifyHUD() {
      boolean var1 = HwidGen.player.getHungerManager().getFoodLevel() <= (Integer)this.Module_FastPlace.HwidGen();
      if (!var1) {
         return false;
      } else {
         this.J = this.Module_zelith();
         if (this.J == -1) {
            return false;
         } else {
            ItemStack var2 = HwidGen.player.getInventory().getStack(this.J);
            FoodComponent var3 = (FoodComponent)var2.get(DataComponentTypes.FOOD);
            return var3 != null && this.c(var2) ? HwidGen.player.getHungerManager().getFoodLevel() < 20 || var3.canAlwaysEat() : false;
         }
      }
   }

   private int Module_zelith() {
      int var1 = -1;
      float var2 = -1.0F;

      for (int var3 = 0; var3 <= 8; var3++) {
         ItemStack var4 = HwidGen.player.getInventory().getStack(var3);
         if (this.c(var4)) {
            FoodComponent var5 = (FoodComponent)var4.get(DataComponentTypes.FOOD);
            if (var5 != null) {
               String var9 = (String)this.Module_f.HwidGen();

               float var8 = switch (var9) {
                  case "Combined" -> var5.nutrition() + var5.saturation();
                  case "Hunger" -> var5.nutrition();
                  case "Saturation" -> var5.saturation();
                  default -> 1.0F;
               };
               if (var8 > var2) {
                  var2 = var8;
                  var1 = var3;
               }
            }
         }
      }

      return var1;
   }

   private boolean c(ItemStack itemStack) {
      return !itemStack.isEmpty() && itemStack.getComponents().contains(DataComponentTypes.FOOD);
   }
}
