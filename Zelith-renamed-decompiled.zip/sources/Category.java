import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public enum Category {
   HwidGen("Misc"),
   KeyFile("Render"),
   c("Combat"),
   LicenseResult("Base"),
   LicenseState("Donut"),
   Module_f("Client");

   private final String LicenseState;

   public static g[] values() {
      return (g[])HwidGen.clone();
   }

   public static g valueOf(String string) {
      return Enum.valueOf(Category.class, string);
   }

   private Category(String string2) {
      this.LicenseState = string2;
   }

   public String c() {
      return this.LicenseState;
   }

   public ItemStack HwidGen() {
      return switch (this) {
         case HwidGen -> new ItemStack(Items.COMPASS);
         case KeyFile -> new ItemStack(Items.SPYGLASS);
         case c -> new ItemStack(Items.NETHERITE_SWORD);
         case LicenseResult -> new ItemStack(Items.MAP);
         case LicenseState -> new ItemStack(Items.HEART_OF_THE_SEA);
         case Module_f -> new ItemStack(Items.NETHER_STAR);
      };
   }
}
