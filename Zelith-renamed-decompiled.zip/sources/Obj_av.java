import net.minecraft.util.math.BlockPos;

class Obj_av {
   final BlockPos c;

   Obj_av(BlockPos blockPos) {
      this.c = blockPos;
   }
}
