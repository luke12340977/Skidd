import com.zelith.gui.ClickGUI;
import java.awt.Color;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;

public final class Module_Hud extends Module {
   private static o HwidGen;
   private final dd Category = new Setting("Watermark", true);
   private final dd Module = new Setting("Coordinates", true);
   private final dd SwapHelper = new Setting("Info", true);
   private final dd Module_j = new Setting("Module List", true);
   private final dd Module_ActiveModules = new Setting("Potion Effects", true);
   private final dd ClickBuf = new Setting("Armor", true);
   private final dd Module_Configs = new Setting("Keybinds", true);
   private final dd Module_Friends = new Setting("Notifications", true);
   private static final EnumMap HwidGen = new EnumMap<>(HudElement.class);

   public static int[] HwidGen(p arg) {
      return HwidGen.computeIfAbsent(arg, argx -> c(argx));
   }

   public static void HwidGen(p arg, int i, int j) {
      HwidGen.put(arg, new int[]{i, j});
      SwapHelper.HwidGen.SwapHelper();
   }

   public static int HwidGen(p arg) {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1 == null) {
         return 100;
      } else {
         return switch (arg) {
            case HwidGen -> var1.textRenderer.getWidth("zelith +") + 20;
            case KeyFile -> var1.textRenderer.getWidth("XYZ: -00000.0 / -256.0 / -00000.0") + 14;
            case c -> var1.textRenderer.getWidth("999 FPS | 999ms | 23:59:59") + 14;
            case LicenseResult -> 120;
            case LicenseState -> 110;
            case Module_f -> var1.textRenderer.getWidth(" 100%") + 22;
            case Category -> 120;
            case Module -> Module_SpotifyHUD.c();
         };
      }
   }

   public static int[] KeyFile(p arg) {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1 != null && var1.player != null) {
         TextRenderer var16 = var1.textRenderer;
         int[] var3 = HwidGen(arg);

         return switch (arg) {
            case HwidGen -> {
               int var31 = var16.getWidth("zelith");
               int var36 = var16.getWidth(" +");
               int var43 = var31 + var36 + 16;
               int[] var26 = new int[]{Obj_dr.Category(var3[0]), Obj_dr.Module(var3[1]), var43, 16};
               yield var26;
            }
            case KeyFile -> {
               String var30 = String.format("%.1f / %.1f / %.1f", var1.player.getX(), var1.player.getY(), var1.player.getZ());
               int var35 = var16.getWidth(var30) + 14;
               int[] var25 = new int[]{Obj_dr.Category(var3[0]), Obj_dr.Module(var3[1]), var35, 14};
               yield var25;
            }
            case c -> {
               int var29 = var1.getCurrentFps();
               int var34 = 0;

               try {
                  if (var1.getNetworkHandler() != null) {
                     PlayerListEntry var41 = var1.getNetworkHandler().getPlayerListEntry(var1.player.getUuid());
                     if (var41 != null) {
                        var34 = var41.getLatency();
                     }
                  }
               } catch (Exception var15) {
               }

               String var42 = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
               String var47 = var29 + " FPS | " + var34 + "ms | " + var42;
               int var51 = var16.getWidth(var47) + 14;
               int[] var24 = new int[]{Obj_dr.Category(var3[0]), Obj_dr.Module(var3[1]), var51, 14};
               yield var24;
            }
            case LicenseResult -> {
               int[] var23 = HwidGen();
               yield var23;
            }
            case LicenseState -> {
               ArrayList var28 = new ArrayList(var1.player.getStatusEffects());
               if (var28.isEmpty()) {
                  int[] var21 = new int[]{Obj_dr.Category(var3[0]), Obj_dr.Module(var3[1]), HwidGen(arg), 14};
                  yield var21;
               } else {
                  int var33 = 0;

                  for (StatusEffectInstance var46 : var28) {
                     int var50 = var16.getWidth(HwidGen(var46)) + 14;
                     if (var50 > var33) {
                        var33 = var50;
                     }
                  }

                  int var40 = var28.size() * 14 + (var28.size() - 1) * 3;
                  int[] var22 = new int[]{Obj_dr.Category(var3[0]), Obj_dr.Module(var3[1]), Math.max(1, var33), Math.max(1, var40)};
                  yield var22;
               }
            }
            case Module_f -> {
               int var27 = 0;
               int var32 = 0;
               EquipmentSlot[] var38 = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

               for (EquipmentSlot var11 : var38) {
                  ItemStack var12 = var1.player.getEquippedStack(var11);
                  if (var12 != null && !var12.isEmpty()) {
                     var32++;
                     int var13;
                     if (var12.isDamageable() && var12.getMaxDamage() > 0) {
                        var13 = (int)Math.round((1.0 - (double)var12.getDamage() / var12.getMaxDamage()) * 100.0);
                     } else {
                        var13 = 100;
                     }

                     int var14 = var16.getWidth(var13 + "%");
                     if (var14 > var27) {
                        var27 = var14;
                     }
                  }
               }

               if (var32 == 0) {
                  int[] var19 = new int[]{Obj_dr.Category(var3[0]), Obj_dr.Module(var3[1]), HwidGen(arg), 18};
                  yield var19;
               } else {
                  int var45 = 22 + var27 + 6;
                  int var49 = var32 * 18 + (var32 - 1) * 2;
                  int[] var20 = new int[]{Obj_dr.Category(var3[0]), Obj_dr.Module(var3[1]), var45, var49};
                  yield var20;
               }
            }
            case Category -> {
               List var5 = c();
               if (var5.isEmpty()) {
                  int[] var17 = new int[]{Obj_dr.Category(var3[0]), Obj_dr.Module(var3[1]), HwidGen(arg), 14};
                  yield var17;
               } else {
                  int var6 = 0;

                  for (Module var8 : var5) {
                     int var9 = var16.getWidth(HwidGen(var8)) + 14;
                     if (var9 > var6) {
                        var6 = var9;
                     }
                  }

                  int var37 = var5.size() * 14 + (var5.size() - 1) * 3;
                  int[] var18 = new int[]{Obj_dr.Category(var3[0]), Obj_dr.Module(var3[1]), Math.max(1, var6), Math.max(1, var37)};
                  yield var18;
               }
            }
            case Module -> {
               int[] var4 = new int[]{Obj_dr.Category(var3[0]), Obj_dr.Module(var3[1]), Module_SpotifyHUD.c(), Module_SpotifyHUD.LicenseResult()};
               yield var4;
            }
         };
      } else {
         int[] var2 = HwidGen(arg);
         return new int[]{Obj_dr.Category(var2[0]), Obj_dr.Module(var2[1]), HwidGen(arg), 14};
      }
   }

   private static List c() {
      ArrayList var0 = new ArrayList();

      for (Module var2 : SwapHelper.HwidGen.KeyFile()) {
         if (var2.KeyFile() != 0) {
            var0.add(var2);
         }
      }

      var0.sort(Comparator.comparing(Module::c));
      return var0;
   }

   private static String HwidGen(h arg) {
      return arg.c() + " [" + ClickGUI.getKeyDisplayNameStatic(arg.KeyFile()) + "]";
   }

   public static boolean HwidGen(p arg) {
      if (HwidGen != null && HwidGen.HwidGen()) {
         return switch (arg) {
            case HwidGen -> HwidGen.Category.HwidGen();
            case KeyFile -> HwidGen.Module.HwidGen();
            case c -> HwidGen.SwapHelper.HwidGen();
            case LicenseResult -> HwidGen.Module_j.HwidGen();
            case LicenseState -> HwidGen.Module_ActiveModules.HwidGen();
            case Module_f -> HwidGen.ClickBuf.HwidGen();
            case Category -> HwidGen.Module_Configs.HwidGen();
            case Module -> Module_SpotifyHUD.Module_f();
         };
      } else {
         return false;
      }
   }

   private static int[] c(p arg) {
      int var1 = Obj_dr.G();

      return switch (arg) {
         case HwidGen -> new int[]{8, 8};
         case KeyFile -> new int[]{8, 30};
         case c -> new int[]{8, 48};
         case LicenseResult -> new int[]{var1 - 130, 72};
         case LicenseState -> new int[]{8, 66};
         case Module_f -> new int[]{var1 - 60, 200};
         case Category -> new int[]{8, 120};
         case Module -> new int[]{8, 50};
      };
   }

   public Module_Hud() {
      super("Hud", Category.Module_f);
      this.HwidGen(this.Category);
      this.HwidGen(this.Module);
      this.HwidGen(this.SwapHelper);
      this.HwidGen(this.Module_j);
      this.HwidGen(this.Module_ActiveModules);
      this.HwidGen(this.ClickBuf);
      this.HwidGen(this.Module_Configs);
      this.HwidGen(this.Module_Friends);
      HwidGen = this;
   }

   public static int[] HwidGen() {
      MinecraftClient var0 = MinecraftClient.getInstance();
      if (var0 == null) {
         return new int[]{0, 0, 120, 14};
      } else {
         TextRenderer var1 = var0.textRenderer;
         int[] var2 = HwidGen(HudElement.LicenseResult);
         int var3 = Obj_dr.Category(var2[0]);
         int var4 = Obj_dr.Module(var2[1]);
         ArrayList var5 = new ArrayList();

         for (Module var7 : SwapHelper.HwidGen.KeyFile()) {
            if (var7.HwidGen() && var7.HwidGen() != Category.Module_f) {
               var5.add(var7);
            }
         }

         if (var5.isEmpty()) {
            return new int[]{var3 - 120, var4, 120, 14};
         } else {
            var5.sort(Comparator.<h>comparingInt(arg -> var1.getWidth(arg.c())).reversed());
            int var8 = var1.getWidth(((Module)var5.get(0)).c()) + 14;
            int var9 = var5.size() * 14 + (var5.size() - 1) * 4;
            return new int[]{var3 - var8, var4, var8, var9};
         }
      }
   }

   public static void HwidGen(DrawContext drawContext) {
      if (HwidGen != null && HwidGen.HwidGen()) {
         MinecraftClient var1 = MinecraftClient.getInstance();
         if (var1 != null && var1.player != null && var1.options != null) {
            if (!(var1.currentScreen instanceof ClickGUI)) {
               if (!var1.getDebugHud().shouldShowDebugHud()) {
                  TextRenderer var2 = var1.textRenderer;
                  int var3 = Module_zelith.Category();
                  Color var4 = Module_zelith.c();
                  float var5 = Obj_dr.Module_ActiveModules();
                  if ((Boolean)HwidGen.Category.HwidGen()) {
                     int[] var6 = HwidGen(HudElement.HwidGen);
                     int var7 = Obj_dr.Category(var6[0]);
                     int var8 = Obj_dr.Module(var6[1]);
                     int var9 = Math.round(var2.getWidth("zelith") * var5);
                     int var10 = Math.round(var2.getWidth(" +") * var5);
                     int var11 = var9 + var10 + Math.round(16.0F * var5);
                     int var12 = Math.round(16.0F * var5);
                     Obj_dr.HwidGen(drawContext, (float)var7, (float)var8, (float)var11, (float)var12, 6.0F * var5, -652993496, false);
                     Obj_dr.HwidGen(drawContext, (float)var7, (float)var8, (float)var11, (float)var12, 6.0F * var5, 1.0F * var5, -869253035, false);
                     int var13 = var7 + Math.round(8.0F * var5);
                     int var14 = var8 + Math.round(4.0F * var5);
                     drawContext.getMatrices().pushMatrix();
                     drawContext.getMatrices().translate(var13, var14);
                     drawContext.getMatrices().scale(var5, var5);
                     drawContext.drawText(var2, "zelith", 0, 0, -985864, true);
                     drawContext.getMatrices().popMatrix();
                     drawContext.getMatrices().pushMatrix();
                     drawContext.getMatrices().translate(var13 + var9, var14);
                     drawContext.getMatrices().scale(var5, var5);
                     drawContext.drawText(var2, " +", 0, 0, var3, true);
                     drawContext.getMatrices().popMatrix();
                  }

                  if ((Boolean)HwidGen.Module.HwidGen()) {
                     int[] var26 = HwidGen(HudElement.KeyFile);
                     int var32 = Obj_dr.Category(var26[0]);
                     int var38 = Obj_dr.Module(var26[1]);
                     String var44 = String.format("%.1f / %.1f / %.1f", var1.player.getX(), var1.player.getY(), var1.player.getZ());
                     int var50 = Math.round(var2.getWidth(var44) * var5) + Math.round(14.0F * var5);
                     int var57 = Math.round(14.0F * var5);
                     Obj_dr.HwidGen(drawContext, (float)var32, (float)var38, (float)var50, (float)var57, 5.0F * var5, -652993496, false);
                     Obj_dr.HwidGen(drawContext, (float)var32, (float)var38, (float)var50, (float)var57, 5.0F * var5, 1.0F * var5, -869253035, false);
                     int var66 = var32 + Math.round(7.0F * var5);
                     int var74 = var38 + Math.round(3.0F * var5);
                     drawContext.getMatrices().pushMatrix();
                     drawContext.getMatrices().translate(var66, var74);
                     drawContext.getMatrices().scale(var5, var5);
                     drawContext.drawText(var2, var44, 0, 0, -3090200, false);
                     drawContext.getMatrices().popMatrix();
                  }

                  if ((Boolean)HwidGen.SwapHelper.HwidGen()) {
                     int[] var27 = HwidGen(HudElement.c);
                     int var33 = Obj_dr.Category(var27[0]);
                     int var39 = Obj_dr.Module(var27[1]);
                     int var45 = var1.getCurrentFps();
                     int var51 = 0;

                     try {
                        if (var1.getNetworkHandler() != null && var1.player != null) {
                           PlayerListEntry var58 = var1.getNetworkHandler().getPlayerListEntry(var1.player.getUuid());
                           if (var58 != null) {
                              var51 = var58.getLatency();
                           }
                        }
                     } catch (Exception var25) {
                     }

                     String var59 = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
                     String var67 = var45 + " FPS | " + var51 + "ms | " + var59;
                     int var75 = Math.round(var2.getWidth(var67) * var5) + Math.round(14.0F * var5);
                     int var82 = Math.round(14.0F * var5);
                     Obj_dr.HwidGen(drawContext, (float)var33, (float)var39, (float)var75, (float)var82, 5.0F * var5, -652993496, false);
                     Obj_dr.HwidGen(drawContext, (float)var33, (float)var39, (float)var75, (float)var82, 5.0F * var5, 1.0F * var5, -869253035, false);
                     int var15 = var33 + Math.round(7.0F * var5);
                     int var16 = var39 + Math.round(3.0F * var5);
                     drawContext.getMatrices().pushMatrix();
                     drawContext.getMatrices().translate(var15, var16);
                     drawContext.getMatrices().scale(var5, var5);
                     drawContext.drawText(var2, var67, 0, 0, -3090200, false);
                     drawContext.getMatrices().popMatrix();
                  }

                  if ((Boolean)HwidGen.Module_ActiveModules.HwidGen()) {
                     ArrayList var28 = new ArrayList(var1.player.getStatusEffects());
                     if (!var28.isEmpty()) {
                        var28.sort(Comparator.comparingInt(statusEffectInstance -> var2.getWidth(HwidGen(statusEffectInstance))));
                        int[] var34 = HwidGen(HudElement.LicenseState);
                        int var40 = Obj_dr.Category(var34[0]);
                        int var46 = Obj_dr.Module(var34[1]);
                        int var52 = var46;

                        for (StatusEffectInstance var68 : var28) {
                           String var76 = HwidGen(var68);
                           int var83 = Math.round(var2.getWidth(var76) * var5) + Math.round(14.0F * var5);
                           int var89 = Math.round(14.0F * var5);
                           int var95 = ((StatusEffect)var68.getEffectType().value()).getColor();
                           int var17 = -872415232 | var95 & 16777215;
                           Obj_dr.HwidGen(drawContext, (float)var40, (float)var52, (float)var83, (float)var89, 5.0F * var5, -652993496, false);
                           Obj_dr.HwidGen(drawContext, (float)var40, (float)var52, (float)var83, (float)var89, 5.0F * var5, 1.0F * var5, var17, false);
                           Obj_dr.HwidGen(drawContext, (float)var40, (float)var52, 2.0F * var5, (float)var89, 2.0F * var5, var17, false);
                           int var18 = var40 + Math.round(7.0F * var5);
                           int var19 = var52 + Math.round(3.0F * var5);
                           drawContext.getMatrices().pushMatrix();
                           drawContext.getMatrices().translate(var18, var19);
                           drawContext.getMatrices().scale(var5, var5);
                           drawContext.drawText(var2, var76, 0, 0, -3090200, false);
                           drawContext.getMatrices().popMatrix();
                           var52 += var89 + Math.round(3.0F * var5);
                        }
                     }
                  }

                  if ((Boolean)HwidGen.ClickBuf.HwidGen()) {
                     int[] var29 = HwidGen(HudElement.Module_f);
                     int var35 = Obj_dr.Category(var29[0]);
                     int var41 = Obj_dr.Module(var29[1]);
                     ArrayList var47 = new ArrayList();
                     EquipmentSlot[] var53 = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

                     for (EquipmentSlot var84 : var53) {
                        ItemStack var90 = var1.player.getEquippedStack(var84);
                        if (var90 != null && !var90.isEmpty()) {
                           var47.add(var90);
                        }
                     }

                     if (!var47.isEmpty()) {
                        int var62 = 0;

                        for (ItemStack var78 : var47) {
                           int var85 = var78.isDamageable() && var78.getMaxDamage() > 0
                              ? (int)Math.round((1.0 - (double)var78.getDamage() / var78.getMaxDamage()) * 100.0)
                              : 100;
                           int var91 = var2.getWidth(var85 + "%");
                           if (var91 > var62) {
                              var62 = var91;
                           }
                        }

                        int var71 = Math.round(var62 * var5);
                        int var79 = Math.round(22.0F * var5) + var71 + Math.round(6.0F * var5);
                        int var86 = Math.round(18.0F * var5);
                        int var92 = var41;

                        for (ItemStack var99 : var47) {
                           int var102 = var99.isDamageable() && var99.getMaxDamage() > 0
                              ? (int)Math.round((1.0 - (double)var99.getDamage() / var99.getMaxDamage()) * 100.0)
                              : 100;
                           int var104;
                           if (var102 >= 66) {
                              var104 = -867508608;
                           } else if (var102 >= 33) {
                              var104 = -855978987;
                           } else {
                              var104 = -856734652;
                           }

                           Obj_dr.HwidGen(drawContext, (float)var35, (float)var92, (float)var79, (float)var86, 5.0F * var5, -652993496, false);
                           Obj_dr.HwidGen(drawContext, (float)var35, (float)var92, (float)var79, (float)var86, 5.0F * var5, 1.0F * var5, -869253035, false);
                           Obj_dr.HwidGen(drawContext, (float)var35, (float)var92, 2.0F * var5, (float)var86, 2.0F * var5, var104, false);
                           int var20 = var35 + Math.round(4.0F * var5);
                           int var21 = var92 + Math.round(1.0F * var5);
                           drawContext.getMatrices().pushMatrix();
                           drawContext.getMatrices().translate(var20 + 8, var21 + 8);
                           drawContext.getMatrices().scale(var5, var5);
                           drawContext.drawItem(var99, -8, -8);
                           drawContext.getMatrices().popMatrix();
                           String var22 = var102 + "%";
                           int var23 = var35 + Math.round(22.0F * var5);
                           int var24 = var92 + Math.round(5.0F * var5);
                           drawContext.getMatrices().pushMatrix();
                           drawContext.getMatrices().translate(var23, var24);
                           drawContext.getMatrices().scale(var5, var5);
                           drawContext.drawText(var2, var22, 0, 0, -3090200, false);
                           drawContext.getMatrices().popMatrix();
                           var92 += var86 + Math.round(2.0F * var5);
                        }
                     }
                  }

                  if ((Boolean)HwidGen.Module_Configs.HwidGen()) {
                     List var30 = c();
                     if (!var30.isEmpty()) {
                        int[] var36 = HwidGen(HudElement.Category);
                        int var42 = Obj_dr.Category(var36[0]);
                        int var48 = Obj_dr.Module(var36[1]);
                        int var54 = var48;

                        for (Module var72 : var30) {
                           String var80 = HwidGen(var72);
                           int var87 = Math.round(var2.getWidth(var80) * var5) + Math.round(14.0F * var5);
                           int var93 = Math.round(14.0F * var5);
                           Obj_dr.HwidGen(drawContext, (float)var42, (float)var54, (float)var87, (float)var93, 5.0F * var5, -652993496, false);
                           Obj_dr.HwidGen(drawContext, (float)var42, (float)var54, (float)var87, (float)var93, 5.0F * var5, 1.0F * var5, -869253035, false);
                           Obj_dr.HwidGen(drawContext, (float)var42, (float)var54, 2.0F * var5, (float)var93, 2.0F * var5, var3, false);
                           int var97 = var42 + Math.round(7.0F * var5);
                           int var100 = var54 + Math.round(3.0F * var5);
                           drawContext.getMatrices().pushMatrix();
                           drawContext.getMatrices().translate(var97, var100);
                           drawContext.getMatrices().scale(var5, var5);
                           drawContext.drawText(var2, var80, 0, 0, -3090200, false);
                           drawContext.getMatrices().popMatrix();
                           var54 += var93 + Math.round(3.0F * var5);
                        }
                     }
                  }

                  if ((Boolean)HwidGen.Module_j.HwidGen()) {
                     int[] var31 = HwidGen(HudElement.LicenseResult);
                     int var37 = Obj_dr.Category(var31[0]);
                     int var43 = Obj_dr.Module(var31[1]);
                     ArrayList var49 = new ArrayList();

                     for (Module var64 : SwapHelper.HwidGen.KeyFile()) {
                        if (var64.HwidGen() && var64.HwidGen() != Category.Module_f) {
                           var49.add(var64);
                        }
                     }

                     var49.sort(Comparator.<h>comparingInt(arg -> var2.getWidth(arg.c())).reversed());
                     int var56 = var43;

                     for (Module var73 : var49) {
                        String var81 = var73.c();
                        int var88 = Math.round(var2.getWidth(var81) * var5) + Math.round(14.0F * var5);
                        int var94 = Math.round(14.0F * var5);
                        int var98 = var37 - var88;
                        Obj_dr.HwidGen(drawContext, (float)var98, (float)var56, (float)var88, (float)var94, 6.0F * var5, -652993496, false);
                        Obj_dr.HwidGen(drawContext, (float)var98, (float)var56, (float)var88, (float)var94, 6.0F * var5, 1.0F * var5, -869253035, false);
                        Obj_dr.HwidGen(
                           drawContext,
                           (float)var98,
                           (float)(var56 + Math.round(1.0F * var5)),
                           2.0F * var5,
                           (float)(var94 - Math.round(2.0F * var5)),
                           1.0F * var5,
                           var3,
                           false
                        );
                        int var101 = var98 + Math.round(6.0F * var5);
                        int var103 = var56 + Math.round(3.0F * var5);
                        drawContext.getMatrices().pushMatrix();
                        drawContext.getMatrices().translate(var101, var103);
                        drawContext.getMatrices().scale(var5, var5);
                        drawContext.drawText(var2, var81, 0, 0, -854277, false);
                        drawContext.getMatrices().popMatrix();
                        var56 += var94 + Math.round(4.0F * var5);
                     }
                  }
               }
            }
         }
      }
   }

   public static String HwidGen(StatusEffectInstance statusEffectInstance) {
      String var1 = Registries.STATUS_EFFECT.getId((StatusEffect)statusEffectInstance.getEffectType().value()).getPath();
      String[] var2 = var1.split("_");
      StringBuilder var3 = new StringBuilder();

      for (String var7 : var2) {
         if (!var7.isEmpty()) {
            var3.append(Character.toUpperCase(var7.charAt(0)));
            if (var7.length() > 1) {
               var3.append(var7.substring(1));
            }

            var3.append(' ');
         }
      }

      String var8 = var3.toString().trim();
      int var9 = statusEffectInstance.getAmplifier();
      if (var9 > 0) {
         var8 = var8 + " " + HwidGen(var9 + 1);
      }

      int var10 = statusEffectInstance.getDuration();
      if (var10 < 32767) {
         int var11 = var10 / 20;
         var8 = var8 + " " + String.format("%d:%02d", var11 / 60, var11 % 60);
      }

      return var8;
   }

   private static String HwidGen(int i) {
      return switch (i) {
         case 1 -> "I";
         case 2 -> "II";
         case 3 -> "III";
         case 4 -> "IV";
         case 5 -> "V";
         case 6 -> "VI";
         case 7 -> "VII";
         case 8 -> "VIII";
         case 9 -> "IX";
         case 10 -> "X";
         default -> String.valueOf(i);
      };
   }
}
