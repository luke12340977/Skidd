import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import org.lwjgl.glfw.GLFW;

public final class Module_AutoCrystal extends Module_f {
   private final dd Module_DoubleAnchor = new Setting("Place Delay", 0.0F, 0.0F, 20.0F);
   private final dd A = new Setting("Break Delay", 0.0F, 0.0F, 20.0F);
   private int Module_f;
   private int Category;

   public Module_AutoCrystal() {
      super("Auto Crystal", Category.c);
      this.HwidGen(this.Module_DoubleAnchor);
      this.HwidGen(this.A);
   }

   @Override
   public void LicenseState() {
      this.Module_zelith();
      super.LicenseState();
   }

   @Override
   public void Category() {
      if (HwidGen.currentScreen == null) {
         if (HwidGen.player != null && HwidGen.world != null) {
            this.Module_AnchorMacro();
            if (!this.Module_ActiveModules()) {
               this.Module_zelith();
            } else {
               Entity var1 = null;
               double var2 = Double.MAX_VALUE;

               for (Entity var5 : HwidGen.world.getEntities()) {
                  if (var5 instanceof EndCrystalEntity) {
                     double var6 = HwidGen.player.distanceTo(var5);
                     if (var6 <= 5.0 && var6 < var2) {
                        var2 = var6;
                        var1 = var5;
                     }
                  }
               }

               if (var1 != null && this.Category == 0) {
                  HwidGen.interactionManager.attackEntity(HwidGen.player, var1);
                  HwidGen.player.swingHand(Hand.MAIN_HAND);
                  this.Category = Math.max(0, ((Float)this.A.HwidGen()).intValue());
               }

               if (HwidGen.crosshairTarget instanceof BlockHitResult var8) {
                  if (var8.getType() == Type.BLOCK) {
                     BlockPos var10 = var8.getBlockPos();
                     if (!(HwidGen.player.squaredDistanceTo(var10.toCenterPos()) > 25.0)) {
                        if (this.HwidGen(var10)) {
                           HwidGen.options.useKey.setPressed(false);
                           int var11 = this.KeyFile(Items.END_CRYSTAL);
                           if (var11 != -1) {
                              if (HwidGen.player.getMainHandStack().getItem() != Items.END_CRYSTAL) {
                                 HwidGen.player.getInventory().setSelectedSlot(var11);
                              }

                              if (this.Module_f == 0) {
                                 this.LicenseResult(var8);
                                 this.Module_f = Math.max(0, ((Float)this.Module_DoubleAnchor.HwidGen()).intValue());
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }

   private boolean Module_ActiveModules() {
      return HwidGen.getWindow() != null && GLFW.glfwGetMouseButton(HwidGen.getWindow().getHandle(), 1) == 1;
   }

   private void Module_zelith() {
      this.Module_f = 0;
      this.Category = 0;
   }

   private void Module_AnchorMacro() {
      if (this.Module_f > 0) {
         this.Module_f--;
      }

      if (this.Category > 0) {
         this.Category--;
      }
   }

   private int KeyFile(Item item) {
      for (int var2 = 0; var2 < 9; var2++) {
         if (HwidGen.player.getInventory().getStack(var2).isOf(item)) {
            return var2;
         }
      }

      return -1;
   }

   private boolean HwidGen(BlockPos blockPos) {
      if (!HwidGen.world.getBlockState(blockPos).isOf(Blocks.OBSIDIAN) && !HwidGen.world.getBlockState(blockPos).isOf(Blocks.BEDROCK)) {
         return false;
      } else {
         BlockPos var2 = blockPos.up();
         if (!HwidGen.world.isAir(var2)) {
            return false;
         } else {
            int var3 = var2.getX();
            int var4 = var2.getY();
            int var5 = var2.getZ();
            Box var6 = new Box(var3, var4, var5, var3 + 1.0, var4 + 2.0, var5 + 1.0);
            return HwidGen.world.getOtherEntities(null, var6).isEmpty();
         }
      }
   }

   private void LicenseResult(BlockHitResult blockHitResult) {
      HwidGen.interactionManager.interactBlock(HwidGen.player, Hand.MAIN_HAND, blockHitResult);
      HwidGen.player.swingHand(Hand.MAIN_HAND);
   }
}
