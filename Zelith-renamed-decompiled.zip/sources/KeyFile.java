import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.client.MinecraftClient;

public final class KeyFile {
   public static String KeyFile() {
      try {
         Path var0 = MinecraftClient.getInstance().runDirectory.toPath().resolve("zelith_key.txt");
         if (Files.isReadable(var0)) {
            return Files.readString(var0, StandardCharsets.UTF_8).trim();
         }
      } catch (Exception var1) {
      }

      return null;
   }

   public static void HwidGen(String string) {
      try {
         Path var1 = MinecraftClient.getInstance().runDirectory.toPath().resolve("zelith_key.txt");
         Files.writeString(var1, string, StandardCharsets.UTF_8);
      } catch (IOException var2) {
      }
   }

   public static void HwidGen() {
      try {
         Path var0 = MinecraftClient.getInstance().runDirectory.toPath().resolve("zelith_key.txt");
         Files.deleteIfExists(var0);
      } catch (IOException var1) {
      }
   }
}
