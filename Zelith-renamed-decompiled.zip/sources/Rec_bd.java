record Rec_bd() {
   private final String Module_ActiveModules;
   private final String ClickBuf;
   private final String Module_Configs;
   private final int F;
   private final String Module_Friends;
   private final String Module_Hud;
   private final String HudElement;
   private final int G;
   private final boolean C;
   private final String Module_SpotifyHUD;
   private final String Module_Themes;
   private final String Module_WaterMark;
   private final String Module_zelith;

   Rec_bd(
      String string,
      String string2,
      String string3,
      int i,
      String string4,
      String string5,
      String string6,
      int j,
      boolean bl,
      String string7,
      String string8,
      String string9,
      String string10
   ) {
      this.Module_ActiveModules = string;
      this.ClickBuf = string2;
      this.Module_Configs = string3;
      this.F = i;
      this.Module_Friends = string4;
      this.Module_Hud = string5;
      this.HudElement = string6;
      this.G = j;
      this.C = bl;
      this.Module_SpotifyHUD = string7;
      this.Module_Themes = string8;
      this.Module_WaterMark = string9;
      this.Module_zelith = string10;
   }

   public String Module() {
      return this.Module_ActiveModules;
   }

   public String SwapHelper() {
      return this.ClickBuf;
   }

   public String Module_j() {
      return this.Module_Configs;
   }

   public int Module_Themes() {
      return this.F;
   }

   public String Module_ActiveModules() {
      return this.Module_Friends;
   }

   public String ClickBuf() {
      return this.Module_Hud;
   }

   public String Module_Configs() {
      return this.HudElement;
   }

   public int Module_WaterMark() {
      return this.G;
   }

   public boolean HudElement() {
      return this.C;
   }

   public String Module_Friends() {
      return this.Module_SpotifyHUD;
   }

   public String Module_Hud() {
      return this.Module_Themes;
   }

   public String HudElement() {
      return this.Module_WaterMark;
   }

   public String Module_SpotifyHUD() {
      return this.Module_zelith;
   }
}
