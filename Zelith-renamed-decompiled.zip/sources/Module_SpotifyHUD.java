import com.zelith.gui.ClickGUI;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

public final class Module_SpotifyHUD extends Module {
   private static q HwidGen;
   private final dd Module_Hud = new Setting("Scale", 1.0F, 0.6F, 2.0F);
   private volatile String Module = "";
   private volatile String SwapHelper = "";
   private volatile boolean Module = false;
   private volatile long KeyFile = 0L;
   private volatile long c = 0L;
   private volatile long LicenseResult = 0L;
   private ScheduledExecutorService HwidGen;
   private ExecutorService HwidGen;
   private File HwidGen;
   private File KeyFile;
   private File c;
   private static final Identifier HwidGen = Identifier.of("zelith", "spotify_art");
   private NativeImageBackedTexture HwidGen = null;
   private volatile long LicenseState = 0L;
   private volatile boolean SwapHelper = false;
   private float KeyFile = 0.0F;
   private long HwidGen = 0L;
   private float c = 0.0F;
   private long Module_f = 0L;
   private volatile boolean Module_j = false;
   private final AtomicBoolean HwidGen = new AtomicBoolean(false);
   private final AtomicInteger HwidGen = new AtomicInteger(0);

   public Module_SpotifyHUD() {
      super("Spotify HUD", Category.KeyFile);
      this.HwidGen(this.Module_Hud);
      HwidGen = this;
   }

   public static boolean Module_f() {
      return HwidGen != null && HwidGen.HwidGen();
   }

   public static float HwidGen() {
      return HwidGen == null ? 1.0F : (Float)HwidGen.Module_Hud.HwidGen();
   }

   public static void HwidGen(float f) {
      if (HwidGen != null) {
         float var1 = HwidGen.Module_Hud.KeyFile() instanceof Float var2 ? var2 : 0.6F;
         float var5 = HwidGen.Module_Hud.c() instanceof Float var6 ? var6 : 2.0F;
         HwidGen.Module_Hud.HwidGen(Math.max(var1, Math.min(var5, f)));
      }
   }

   public static int c() {
      return Math.round(248.0F * HwidGen() * Obj_dr.Module_ActiveModules());
   }

   public static int LicenseResult() {
      return Math.round(110.0F * HwidGen() * Obj_dr.Module_ActiveModules());
   }

   private static int HwidGen(int i) {
      return Math.round(i * HwidGen() * Obj_dr.Module_ActiveModules());
   }

   private static float HwidGen(float f) {
      return f * HwidGen() * Obj_dr.Module_ActiveModules();
   }

   private static int KeyFile(int i) {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1 != null && var1.getWindow() != null) {
         int var2 = Math.max(0, Obj_dr.G() - c());
         return Math.max(0, Math.min(i, var2));
      } else {
         return i;
      }
   }

   private static int c(int i) {
      MinecraftClient var1 = MinecraftClient.getInstance();
      if (var1 != null && var1.getWindow() != null) {
         int var2 = Math.max(0, Obj_dr.H() - LicenseResult());
         return Math.max(0, Math.min(i, var2));
      } else {
         return i;
      }
   }

   private static int LicenseState() {
      int[] var0 = Module_Hud.HwidGen(HudElement.Module);
      return KeyFile(var0[0]);
   }

   private static int Module_f() {
      int[] var0 = Module_Hud.HwidGen(HudElement.Module);
      return c(var0[1]);
   }

   @Override
   public void LicenseState() {
      this.Module_Friends();
   }

   @Override
   public void Category() {
      if (this.HwidGen == null || this.HwidGen.isShutdown()) {
         this.Module_Friends();
      }
   }

   private void Module_Friends() {
      if (this.HwidGen == null || this.HwidGen.isShutdown()) {
         this.KeyFile = 0.0F;
         this.c = 0.0F;
         this.HwidGen = 0L;
         this.Module_f = 0L;
         this.Module_j = false;
         this.HwidGen.set(0);
         this.Module_Hud();
         this.c = new File(System.getenv("TEMP"), "zelith_spotify_art.png");
         Thread var1 = new Thread(this::HudElement, "zelith-spotify-initial-poll");
         var1.setDaemon(true);
         var1.start();
         this.HwidGen = Executors.newSingleThreadScheduledExecutor(runnable -> {
            Thread var1x = new Thread(runnable, "zelith-spotify");
            var1x.setDaemon(true);
            return var1x;
         });
         this.HwidGen = Executors.newSingleThreadExecutor(runnable -> {
            Thread var1x = new Thread(runnable, "zelith-spotify-ctrl");
            var1x.setDaemon(true);
            return var1x;
         });
         this.HwidGen.scheduleAtFixedRate(() -> {
            int var1x = this.HwidGen.getAndIncrement();
            if (var1x < 10) {
               this.HudElement();
               if (!this.Module.isEmpty()) {
                  this.HwidGen.set(Integer.MAX_VALUE);
               }
            }
         }, 1000L, 800L, TimeUnit.MILLISECONDS);
         this.HwidGen.scheduleAtFixedRate(this::HudElement, 2L, 2L, TimeUnit.SECONDS);
      }
   }

   @Override
   public void Module_f() {
      if (this.HwidGen != null) {
         this.HwidGen.shutdownNow();
      }

      if (this.HwidGen != null) {
         this.HwidGen.shutdownNow();
      }

      this.Module = "";
      this.SwapHelper = "";
      this.Module = false;
      this.KeyFile = 0L;
      this.c = 0L;
      this.LicenseResult = 0L;
      this.KeyFile = 0.0F;
      this.c = 0.0F;
      this.SwapHelper = false;
      if (this.HwidGen != null) {
         try {
            MinecraftClient.getInstance().getTextureManager().destroyTexture(HwidGen);
         } catch (Exception var2) {
         }

         this.HwidGen = null;
      }
   }

   private void Module_Hud() {
      try {
         this.HwidGen = File.createTempFile("zelith_smtc_poll_", ".ps1");
         this.HwidGen.deleteOnExit();

         try (FileWriter var1 = new FileWriter(this.HwidGen, StandardCharsets.UTF_8)) {
            var1.write(
               "[void][System.Reflection.Assembly]::LoadFile('C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\System.Runtime.WindowsRuntime.dll')\r\n$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager,Windows.Media.Control,ContentType=WindowsRuntime]\r\n$g = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -like 'IAsyncOperation*' })[0]\r\nfunction Aw($op,$t){$m=$g.MakeGenericMethod($t);$task=$m.Invoke($null,@($op));$task.GetAwaiter().GetResult()}\r\n$asStreamForRead = [System.IO.WindowsRuntimeStreamExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsStreamForRead' -and $_.GetParameters().Count -eq 1 } | Select-Object -First 1\r\ntry {\r\n  $mgr = Aw([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])\r\n  $s = $mgr.GetCurrentSession()\r\n  if ($s) {\r\n    $p = Aw($s.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])\r\n    $tl = $s.GetTimelineProperties()\r\n    $pb = $s.GetPlaybackInfo()\r\n    if ($p.Title) {\r\n      if ($p.Thumbnail -and $asStreamForRead) {\r\n        try {\r\n          $stream = Aw($p.Thumbnail.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])\r\n          $netStream = $asStreamForRead.Invoke($null, @($stream))\r\n          $outPath = Join-Path $env:TEMP 'zelith_spotify_art.png'\r\n          $fs = [System.IO.File]::Create($outPath)\r\n          $netStream.CopyTo($fs)\r\n          $fs.Close()\r\n          $netStream.Close()\r\n        } catch {}\r\n      }\r\n      Write-Output ($p.Artist + '|||' + $p.Title + '|||' + [long]$tl.Position.TotalMilliseconds + '|||' + [long]$tl.EndTime.TotalMilliseconds + '|||' + ($pb.PlaybackStatus.ToString() -eq 'Playing'))\r\n    }\r\n  }\r\n} catch {}\r\n"
            );
         }

         this.KeyFile = File.createTempFile("zelith_smtc_ctrl_", ".ps1");
         this.KeyFile.deleteOnExit();

         try (FileWriter var9 = new FileWriter(this.KeyFile, StandardCharsets.UTF_8)) {
            var9.write(
               "param([string]$action)\r\n[void][System.Reflection.Assembly]::LoadFile('C:\\Windows\\Microsoft.NET\\Framework64\\v4.0.30319\\System.Runtime.WindowsRuntime.dll')\r\n$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager,Windows.Media.Control,ContentType=WindowsRuntime]\r\n$g = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -like 'IAsyncOperation*' })[0]\r\nfunction Aw($op,$t){$m=$g.MakeGenericMethod($t);$task=$m.Invoke($null,@($op));$task.GetAwaiter().GetResult()}\r\ntry {\r\n  $mgr = Aw([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])\r\n  $s = $mgr.GetCurrentSession()\r\n  if ($s) {\r\n    switch ($action) {\r\n      'next'   { Aw($s.TrySkipNextAsync()) ([bool]) | Out-Null }\r\n      'prev'   { Aw($s.TrySkipPreviousAsync()) ([bool]) | Out-Null }\r\n      'toggle' { Aw($s.TryTogglePlayPauseAsync()) ([bool]) | Out-Null }\r\n    }\r\n  }\r\n} catch {}\r\n"
            );
         }
      } catch (Exception var8) {
         this.HwidGen = null;
         this.KeyFile = null;
      }
   }

   private void HudElement() {
      if (this.HwidGen == null || !this.HwidGen.exists()) {
         this.Module_Hud();
      }

      if (this.HwidGen == null) {
         this.Module_j = true;
      } else if (this.HwidGen.compareAndSet(false, true)) {
         try {
            long var1 = System.currentTimeMillis();
            Process var3 = new ProcessBuilder(
                  "powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", this.HwidGen.getAbsolutePath()
               )
               .redirectErrorStream(true)
               .start();
            String var4 = null;
            BufferedReader var5 = new BufferedReader(new InputStreamReader(var3.getInputStream(), StandardCharsets.UTF_8));

            String var6;
            try {
               while ((var6 = var5.readLine()) != null) {
                  var6 = var6.trim();
                  if (var6.contains("|||")) {
                     var4 = var6;
                     break;
                  }
               }
            } catch (Throwable var27) {
               try {
                  var5.close();
               } catch (Throwable var26) {
                  var27.addSuppressed(var26);
               }

               throw var27;
            }

            var5.close();
            var3.waitFor(8L, TimeUnit.SECONDS);
            long var30 = System.currentTimeMillis();
            long var7 = (var1 + var30) / 2L;
            if (var4 == null) {
               return;
            }

            String[] var9 = var4.split("\\|\\|\\|", -1);
            if (var9.length < 2 || var9[1].trim().isEmpty()) {
               return;
            }

            String var10 = var9[1].trim();
            String var11 = var9[0].trim();
            long var12 = var9.length > 2 ? HwidGen(var9[2]) : 0L;
            long var14 = var9.length > 3 ? HwidGen(var9[3]) : 0L;
            boolean var16 = var9.length > 4 && var9[4].trim().equalsIgnoreCase("True");
            String var17 = this.Module;
            boolean var18 = this.Module;
            this.Module = var10;
            this.SwapHelper = var11;
            this.LicenseResult = var14;
            this.Module = var16;
            if (var10.equals(var17) && this.c != 0L && var16 == var18) {
               long var19 = this.KeyFile + Math.max(0L, var7 - this.c);
               if (Math.abs(var12 - var19) <= 500L) {
                  this.KeyFile = var12;
                  this.c = var7;
               }
            } else {
               this.c = 0.0F;
               this.KeyFile = var12;
               this.c = var7;
            }
         } catch (Exception var28) {
            return;
         } finally {
            this.Module_j = true;
            this.HwidGen.set(false);
         }
      }
   }

   private static long HwidGen(String string) {
      try {
         return Long.parseLong(string.trim());
      } catch (Exception var2) {
         return 0L;
      }
   }

   public static void Module_f(String string) {
      if (HwidGen != null && HwidGen.HwidGen != null && HwidGen.KeyFile != null) {
         long var1 = System.currentTimeMillis();
         if ("toggle".equals(string)) {
            if (HwidGen.Module) {
               long var3 = HwidGen.c > 0L ? Math.max(0L, var1 - HwidGen.c) : 0L;
               HwidGen.KeyFile += var3;
               HwidGen.c = var1;
               HwidGen.Module = false;
            } else {
               HwidGen.c = var1;
               HwidGen.Module = true;
            }
         }

         HwidGen.HwidGen
            .submit(
               () -> {
                  try {
                     Process var1x = new ProcessBuilder(
                           "powershell",
                           "-NoProfile",
                           "-NonInteractive",
                           "-ExecutionPolicy",
                           "Bypass",
                           "-File",
                           HwidGen.KeyFile.getAbsolutePath(),
                           "-action",
                           string
                        )
                        .redirectErrorStream(true)
                        .start();
                     var1x.waitFor(5L, TimeUnit.SECONDS);
                     if (HwidGen.HwidGen != null && !HwidGen.HwidGen.isShutdown()) {
                        HwidGen.HwidGen.submit(HwidGen::HudElement);
                     }
                  } catch (Exception var2) {
                  }
               }
            );
      }
   }

   private static int[] HwidGen(int i, int j, int k) {
      int var3 = i + k + HwidGen(6);
      int var4 = Math.max(2, HwidGen(2));
      int var5 = 8 + HwidGen(3) + 8 + HwidGen(5) + var4 + HwidGen(4) + 8 + HwidGen(5) + 8;
      int var6 = i + j - HwidGen(6) - (var3 + var5);
      int var7 = var3 + Math.max(0, var6 / 2);
      int var9 = var7 + 8 + HwidGen(3);
      int var10 = var9 + 8 + HwidGen(5);
      int var11 = var10 + var4 + HwidGen(4);
      int var12 = var11 + 8 + HwidGen(5);
      return new int[]{var7, var9, var10, var11, var12};
   }

   public static boolean HwidGen(double d, double e) {
      if (HwidGen != null && HwidGen.HwidGen()) {
         MinecraftClient var4 = MinecraftClient.getInstance();
         if (var4 != null && var4.textRenderer != null) {
            int var5 = Obj_dr.Category(LicenseState());
            int var6 = Obj_dr.Module(Module_f());
            int var7 = c();
            int var8 = LicenseResult();
            TextRenderer var9 = var4.textRenderer;
            float var10 = Obj_dr.Module_ActiveModules();
            String var11 = "◀◀";
            String var12 = HwidGen.Module ? "❙❙" : "▶";
            String var13 = "▶▶";
            int var14 = Math.round(var9.getWidth(var11) * var10);
            int var15 = Math.round(var9.getWidth(var12) * var10);
            int var16 = Math.round(var9.getWidth(var13) * var10);
            int var17 = HwidGen(20);
            int[] var18 = HwidGen(var6, var8, var17);
            int var19 = var18[4];
            int var20 = var5 + var7 / 2;
            int var21 = HwidGen(14);
            int var22 = var20 - var15 / 2;
            int var23 = var22 - var21 - var14;
            int var24 = var22 + var15 + var21;
            int var25 = HwidGen(5);
            int var26 = HwidGen(3);
            int[][] var27 = new int[][]{
               {var23 - var25, var19 - var26, var14 + 2 * var25, 8 + 2 * var26},
               {var22 - var25, var19 - var26, var15 + 2 * var25, 8 + 2 * var26},
               {var24 - var25, var19 - var26, var16 + 2 * var25, 8 + 2 * var26}
            };
            String[] var28 = new String[]{"prev", "toggle", "next"};

            for (int var29 = 0; var29 < var27.length; var29++) {
               int[] var30 = var27[var29];
               if (d >= var30[0] && d <= var30[0] + var30[2] && e >= var30[1] && e <= var30[1] + var30[3]) {
                  Module_f(var28[var29]);
                  return true;
               }
            }

            return false;
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private void Module_SpotifyHUD() {
      if (this.c != null && this.c.exists()) {
         long var1 = this.c.lastModified();
         long var3 = this.c.length();
         if (var3 >= 200L) {
            if (var1 != this.LicenseState || this.HwidGen == null) {
               try {
                  byte[] var5 = Files.readAllBytes(this.c.toPath());

                  try (ByteArrayInputStream var6 = new ByteArrayInputStream(var5)) {
                     NativeImage var7 = NativeImage.read(var6);
                     if (this.HwidGen != null) {
                        try {
                           MinecraftClient.getInstance().getTextureManager().destroyTexture(HwidGen);
                        } catch (Exception var10) {
                        }
                     }

                     this.HwidGen = new NativeImageBackedTexture(() -> "spotify_art", var7);
                     MinecraftClient.getInstance().getTextureManager().registerTexture(HwidGen, this.HwidGen);
                     this.LicenseState = var1;
                     this.SwapHelper = true;
                  }
               } catch (Exception var12) {
               }
            }
         }
      }
   }

   public static void HwidGen(DrawContext drawContext) {
      if (HwidGen != null && HwidGen.HwidGen()) {
         MinecraftClient var1 = MinecraftClient.getInstance();
         if (var1 != null && var1.player != null) {
            if (!(var1.currentScreen instanceof ClickGUI)) {
               if (!var1.getDebugHud().shouldShowDebugHud()) {
                  long var2 = System.nanoTime();
                  float var4 = HwidGen.HwidGen == 0L ? 0.016F : Math.min(0.1F, (float)(var2 - HwidGen.HwidGen) / 1.0E9F);
                  HwidGen.HwidGen = var2;
                  HwidGen.KeyFile = HwidGen.KeyFile + (1.0F - HwidGen.KeyFile) * (1.0F - (float)Math.exp(-12.0F * var4));
                  float var5 = HwidGen.KeyFile;
                  if (!(var5 < 0.01F)) {
                     HwidGen.Module_SpotifyHUD();
                     int var6 = c();
                     int var7 = LicenseResult();
                     int var8 = HwidGen(48);
                     int var9 = HwidGen(8);
                     int var10 = HwidGen(20);
                     int var11 = Obj_dr.Category(LicenseState()) + Math.round((1.0F - var5) * -(var6 + HwidGen(20)));
                     int var12 = Obj_dr.Module(Module_f());
                     TextRenderer var13 = var1.textRenderer;
                     float var14 = Obj_dr.Module_ActiveModules();
                     int var15 = Module_zelith.Category();
                     int var16 = HwidGen(1118488, (int)(232.0F * var5));
                     int var17 = HwidGen(1644835, (int)(240.0F * var5));
                     int var18 = HwidGen(3553354, (int)(170.0F * var5));
                     int var19 = HwidGen(15263982, (int)(255.0F * var5));
                     int var20 = HwidGen(9408666, (int)(255.0F * var5));
                     int var21 = HwidGen(855315, (int)(255.0F * var5));
                     int var22 = HwidGen(1448998, (int)(210.0F * var5));
                     int var23 = HwidGen(var15 & 16777215, (int)(160.0F * var5));
                     float var25 = HwidGen(8.0F);
                     if (Module_zelith.Module()) {
                        Obj_dr.HwidGen(
                           drawContext, (float)(var11 + 4), (float)(var12 + 5), (float)var6, (float)var7, var25, HwidGen(0, (int)(119.0F * var5)), false
                        );
                     }

                     Obj_dr.HwidGen(drawContext, (float)var11, (float)var12, (float)var6, (float)var7, var25, var16, false);
                     Obj_dr.HwidGen(drawContext, (float)var11, (float)var12, (float)var6, (float)var7, var25, HwidGen(1.0F), var18, false);
                     Obj_dr.HwidGen(
                        drawContext, (float)var11, (float)var12, (float)var6, (float)var10, var25, var25, HwidGen(3.0F), HwidGen(3.0F), false, var17
                     );
                     Obj_dr.HwidGen(
                        drawContext,
                        (float)(var11 + 8),
                        (float)(var12 + var10 - 2),
                        (float)(var6 - 16),
                        (float)Math.max(1, Math.round(HwidGen(1.0F))),
                        (float)Math.round(HwidGen(0.5F)),
                        HwidGen(var15 & 16777215, (int)(200.0F * var5)),
                        false
                     );
                     drawContext.getMatrices().pushMatrix();
                     drawContext.getMatrices().translate(var11 + Math.round(12.0F * var14), var12 + Math.round((var10 - Math.round(9.0F * var14)) / 2.0F));
                     drawContext.getMatrices().scale(var14, var14);
                     drawContext.drawText(var13, "SPOTIFY", 0, 0, var19, false);
                     drawContext.getMatrices().popMatrix();
                     int var26 = var11 + var9;
                     int var27 = var12 + var10 + HwidGen(6);
                     int var28 = var12 + var7 - var9 - var8;
                     if (var27 > var28) {
                        var27 = var28;
                     }

                     if (HwidGen.SwapHelper) {
                        int var29 = Math.max(0, Math.min(255, (int)(255.0F * var5))) << 24 | 16777215;
                        Obj_dr.HwidGen(drawContext, (float)var26, (float)var27, (float)var8, HwidGen, var29, HwidGen(2.0F), false);
                     } else {
                        Obj_dr.HwidGen(drawContext, (float)var26, (float)var27, (float)var8, (float)var8, HwidGen(2.0F), var22, false);
                        String var62 = "♫";
                        int var30 = Math.round(var13.getWidth(var62) * var14);
                        int var31 = var26 + Math.round((var8 - var30) / 2.0F);
                        int var32 = var27 + Math.round((var8 - Math.round(9.0F * var14)) / 2.0F);
                        drawContext.getMatrices().pushMatrix();
                        drawContext.getMatrices().translate(var31, var32);
                        drawContext.getMatrices().scale(var14, var14);
                        drawContext.drawText(var13, var62, 0, 0, var23, false);
                        drawContext.getMatrices().popMatrix();
                     }

                     int var63 = var26 + var8 + var9;
                     int var64 = Math.max(20, var11 + var6 - var9 - var63);
                     int[] var65 = HwidGen(var12, var7, var10);
                     int var66 = var65[0];
                     int var33 = var65[1];
                     int var34 = var65[2];
                     int var35 = var65[3];
                     int var36 = var65[4];
                     int var37 = Math.max(2, HwidGen(2));
                     String var38 = !HwidGen.Module_j ? "" : (HwidGen.Module.isEmpty() ? "NO TRACK" : HwidGen.Module.toUpperCase(Locale.ROOT));
                     if (!var38.isEmpty()) {
                        int var39 = Math.round(var13.getWidth(var38) * var14);
                        if (var39 > var64) {
                           long var40 = System.nanoTime();
                           float var42 = HwidGen.Module_f == 0L ? 0.0F : Math.min(0.1F, (float)(var40 - HwidGen.Module_f) / 1.0E9F);
                           HwidGen.Module_f = var40;
                           HwidGen.c += 28.0F * var42;
                           if (HwidGen.c > var39 + Math.round(18.0F * var14)) {
                              HwidGen.c = 0.0F;
                           }

                           int var43 = (int)HwidGen.c;
                           drawContext.enableScissor(var63, var66 - 1, var63 + var64, var66 + Math.round(10.0F * var14));
                           drawContext.getMatrices().pushMatrix();
                           drawContext.getMatrices().translate(var63 - var43, var66);
                           drawContext.getMatrices().scale(var14, var14);
                           drawContext.drawText(var13, var38, 0, 0, var19, false);
                           drawContext.getMatrices().popMatrix();
                           drawContext.getMatrices().pushMatrix();
                           drawContext.getMatrices().translate(var63 - var43 + var39 + Math.round(18.0F * var14), var66);
                           drawContext.getMatrices().scale(var14, var14);
                           drawContext.drawText(var13, var38, 0, 0, var19, false);
                           drawContext.getMatrices().popMatrix();
                           drawContext.disableScissor();
                        } else {
                           HwidGen.c = 0.0F;
                           drawContext.getMatrices().pushMatrix();
                           drawContext.getMatrices().translate(var63, var66);
                           drawContext.getMatrices().scale(var14, var14);
                           drawContext.drawText(var13, var38, 0, 0, var19, false);
                           drawContext.getMatrices().popMatrix();
                        }
                     }

                     if (!HwidGen.SwapHelper.isEmpty()) {
                        drawContext.getMatrices().pushMatrix();
                        drawContext.getMatrices().translate(var63, var33);
                        drawContext.getMatrices().scale(var14, var14);
                        drawContext.drawText(
                           var13, var13.trimToWidth(HwidGen.SwapHelper.toUpperCase(Locale.ROOT), Math.round(var64 / var14)), 0, 0, var20, false
                        );
                        drawContext.getMatrices().popMatrix();
                     }

                     Obj_dr.HwidGen(drawContext, (float)var63, (float)var34, (float)var64, (float)var37, var37 / 2.0F, var21, false);
                     long var67 = System.currentTimeMillis();
                     long var41;
                     if (HwidGen.Module && HwidGen.c > 0L) {
                        long var68 = Math.max(0L, var67 - HwidGen.c);
                        var41 = HwidGen.KeyFile + var68;
                        if (HwidGen.LicenseResult > 0L) {
                           var41 = Math.min(HwidGen.LicenseResult, var41);
                        }
                     } else {
                        var41 = HwidGen.KeyFile;
                     }

                     if (HwidGen.LicenseResult > 0L && var41 > 0L) {
                        float var69 = Math.min(1.0F, (float)var41 / (float)HwidGen.LicenseResult);
                        int var44 = Math.max(var37, Math.round(var64 * var69));
                        int var45 = HwidGen(var15 & 16777215, (int)(200.0F * var5));
                        Obj_dr.HwidGen(drawContext, (float)var63, (float)var34, (float)var44, (float)var37, var37 / 2.0F, var45, false);
                     }

                     long var70 = var41 / 1000L;
                     long var71 = HwidGen.LicenseResult / 1000L;
                     String var47 = HwidGen(var70);
                     String var48 = var71 > 0L ? HwidGen(var71) : "--:--";
                     int var49 = Math.round(var13.getWidth(var48) * var14);
                     drawContext.getMatrices().pushMatrix();
                     drawContext.getMatrices().translate(var63, var35);
                     drawContext.getMatrices().scale(var14, var14);
                     drawContext.drawText(var13, var47, 0, 0, var20, false);
                     drawContext.getMatrices().popMatrix();
                     drawContext.getMatrices().pushMatrix();
                     drawContext.getMatrices().translate(var63 + var64 - var49, var35);
                     drawContext.getMatrices().scale(var14, var14);
                     drawContext.drawText(var13, var48, 0, 0, var20, false);
                     drawContext.getMatrices().popMatrix();
                     String var50 = "◀◀";
                     String var51 = HwidGen.Module ? "❙❙" : "▶";
                     String var52 = "▶▶";
                     int var53 = Math.round(var13.getWidth(var50) * var14);
                     int var54 = Math.round(var13.getWidth(var51) * var14);
                     int var55 = Math.round(var13.getWidth(var52) * var14);
                     int var56 = var11 + var6 / 2;
                     int var57 = HwidGen(14);
                     int var58 = var56 - var54 / 2;
                     int var59 = var58 - var57 - var53;
                     int var60 = var58 + var54 + var57;
                     int var61 = HwidGen.Module ? HwidGen(var15 & 16777215, (int)(230.0F * var5)) : var20;
                     drawContext.getMatrices().pushMatrix();
                     drawContext.getMatrices().translate(var59, var36);
                     drawContext.getMatrices().scale(var14, var14);
                     drawContext.drawText(var13, var50, 0, 0, var20, false);
                     drawContext.getMatrices().popMatrix();
                     drawContext.getMatrices().pushMatrix();
                     drawContext.getMatrices().translate(var58, var36);
                     drawContext.getMatrices().scale(var14, var14);
                     drawContext.drawText(var13, var51, 0, 0, var61, false);
                     drawContext.getMatrices().popMatrix();
                     drawContext.getMatrices().pushMatrix();
                     drawContext.getMatrices().translate(var60, var36);
                     drawContext.getMatrices().scale(var14, var14);
                     drawContext.drawText(var13, var52, 0, 0, var20, false);
                     drawContext.getMatrices().popMatrix();
                  }
               }
            }
         }
      }
   }

   private static String HwidGen(long l) {
      return String.format("%d:%02d", l / 60L, l % 60L);
   }

   private static int HwidGen(int i, int j) {
      return Math.max(0, Math.min(255, j)) << 24 | i & 16777215;
   }
}
