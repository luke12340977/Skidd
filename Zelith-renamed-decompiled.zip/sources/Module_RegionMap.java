import java.awt.Color;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;

public final class Module_RegionMap extends Module {
   private static final Color[] HwidGen = new Color[]{
      new Color(159, 206, 99), new Color(0, 166, 99), new Color(79, 173, 234), new Color(47, 110, 186), new Color(245, 194, 66), new Color(252, 136, 3)
   };
   private static final String[] KeyFile = new String[]{"EU Central", "EU West", "NA East", "NA West", "Asia", "Oceania"};
   private static final int[][] HwidGen = new int[9][9];
   private static final int[][] KeyFile = new int[9][9];
   private final dd aJ = new Setting("Height", 320.0, 0.0, 400.0);
   private final dd aK = new Setting("Show Grid", true);
   private final dd aL = new Setting("Show Player", true);
   private final dd aM = new Setting("Player Color", new Color(255, 255, 255));
   private final dd aN = new Setting("Show Current Region", true);

   public Module_RegionMap() {
      super("Region Map", Category.LicenseState);
      this.HwidGen(this.aJ);
      this.HwidGen(this.aK);
      this.HwidGen(this.aL);
      this.HwidGen(this.aM);
      this.HwidGen(this.aN);
   }

   @Override
   public void HwidGen(MatrixStack matrixStack, float f) {
      if (HwidGen.world != null && HwidGen.player != null) {
         Camera var3 = Render_dm.HwidGen();
         if (var3 != null) {
            Vec3d var4 = Render_dm.HwidGen(var3);
            double var5 = (Double)this.aJ.HwidGen() - var4.y;
            double var7 = HwidGen.player.getX();
            double var9 = HwidGen.player.getZ();
            matrixStack.push();
            do var11 = Render_dm.HwidGen(matrixStack);

            for (int var12 = 0; var12 < 9; var12++) {
               for (int var13 = 0; var13 < 9; var13++) {
                  int var14 = HwidGen[var12][var13];
                  if (var14 >= 0 && var14 < HwidGen.length) {
                     Color var15 = HwidGen[var14];
                     Color var16 = new Color(var15.getRed(), var15.getGreen(), var15.getBlue(), 120);
                     double var17 = var13 * 50000.0 - 225000.0;
                     double var19 = var12 * 50000.0 - 225000.0;
                     double var21 = var17 + 50000.0;
                     double var23 = var19 + 50000.0;
                     double var25 = var17 - var4.x;
                     double var27 = var19 - var4.z;
                     double var29 = var21 - var4.x;
                     double var31 = var23 - var4.z;
                     var11.HwidGen(var25, var5, var27, var29, var5 + 0.1, var31, var16);
                     if ((Boolean)this.aK.HwidGen()) {
                        Color var33 = new Color(0, 0, 0, 150);
                        var11.KeyFile(var25, var5, var27, var29, var5 + 0.1, var31, var33);
                     }
                  }
               }
            }

            if ((Boolean)this.aL.HwidGen()) {
               double var34 = var7 - var4.x;
               double var35 = var9 - var4.z;
               Color var36 = (Color)this.aM.HwidGen();
               var11.HwidGen(
                  var34 - 500.0,
                  var5 + 0.2,
                  var35 - 500.0,
                  var34 + 500.0,
                  var5 + 0.3,
                  var35 + 500.0,
                  new Color(var36.getRed(), var36.getGreen(), var36.getBlue(), 200)
               );
            }

            var11.Module_FakePay();
            matrixStack.pop();
         }
      }
   }

   static {
      int[][] var0 = new int[][]{
         {0, 0, 5, 82},
         {0, 1, 3, 100},
         {0, 2, 3, 101},
         {0, 3, 3, 102},
         {0, 4, 2, 103},
         {0, 5, 2, 104},
         {0, 6, 2, 105},
         {0, 7, 2, 106},
         {0, 8, 2, 91},
         {1, 0, 5, 83},
         {1, 1, 3, 44},
         {1, 2, 3, 75},
         {1, 3, 3, 42},
         {1, 4, 2, 41},
         {1, 5, 2, 40},
         {1, 6, 2, 39},
         {1, 7, 2, 38},
         {1, 8, 2, 92},
         {2, 0, 5, 84},
         {2, 1, 3, 45},
         {2, 2, 3, 14},
         {2, 3, 3, 13},
         {2, 4, 2, 12},
         {2, 5, 2, 11},
         {2, 6, 2, 10},
         {2, 7, 2, 37},
         {2, 8, 2, 93},
         {3, 0, 5, 85},
         {3, 1, 5, 46},
         {3, 2, 5, 74},
         {3, 3, 3, 3},
         {3, 4, 2, 2},
         {3, 5, 2, 1},
         {3, 6, 2, 25},
         {3, 7, 2, 36},
         {3, 8, 2, 94},
         {4, 0, 4, 86},
         {4, 1, 4, 47},
         {4, 2, 4, 72},
         {4, 3, 4, 71},
         {4, 4, 2, 5},
         {4, 5, 2, 4},
         {4, 6, 2, 24},
         {4, 7, 2, 35},
         {4, 8, 2, 95},
         {5, 0, 4, 87},
         {5, 1, 1, 51},
         {5, 2, 1, 17},
         {5, 3, 0, 9},
         {5, 4, 0, 8},
         {5, 5, 0, 7},
         {5, 6, 0, 23},
         {5, 7, 0, 34},
         {5, 8, 2, 96},
         {6, 0, 4, 88},
         {6, 1, 1, 54},
         {6, 2, 1, 18},
         {6, 3, 0, 61},
         {6, 4, 0, 62},
         {6, 5, 0, 21},
         {6, 6, 0, 22},
         {6, 7, 0, 33},
         {6, 8, 0, 97},
         {7, 0, 0, 89},
         {7, 1, 1, 26},
         {7, 2, 0, 27},
         {7, 3, 0, 28},
         {7, 4, 0, 29},
         {7, 5, 0, 30},
         {7, 6, 0, 59},
         {7, 7, 0, 32},
         {7, 8, 0, 98},
         {8, 0, 0, 90},
         {8, 1, 1, 107},
         {8, 2, 1, 108},
         {8, 3, 1, 109},
         {8, 4, 1, 110},
         {8, 5, 1, 111},
         {8, 6, 1, 112},
         {8, 7, 1, 113},
         {8, 8, 0, 99}
      };

      for (int[] var4 : var0) {
         HwidGen[var4[0]][var4[1]] = var4[2];
         KeyFile[var4[0]][var4[1]] = var4[3];
      }
   }
}
