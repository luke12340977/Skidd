import java.awt.Color;
import java.util.Set;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShapes;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;

public final class Misc_do {
   private final MatrixStack KeyFile;
   private final BufferAllocator KeyFile;
   private final Immediate KeyFile;
   private boolean V;
   private boolean W;

   Misc_do(MatrixStack matrixStack) {
      this.KeyFile = matrixStack;
      this.KeyFile = new BufferAllocator(2097152);
      this.KeyFile = VertexConsumerProvider.immediate(this.KeyFile);
   }

   public void HwidGen(double d, double e, double f, double g, double h, double i, Color color) {
      VertexConsumer var14 = this.KeyFile.getBuffer(RenderLayers.debugFilledBox());
      int var15 = color.getAlpha() << 24 | color.getRed() << 16 | color.getGreen() << 8 | color.getBlue();
      Entry var16 = this.KeyFile.peek();
      float var17 = (float)d;
      float var18 = (float)e;
      float var19 = (float)f;
      float var20 = (float)g;
      float var21 = (float)h;
      float var22 = (float)i;
      var14.vertex(var16, var17, var18, var19).color(var15);
      var14.vertex(var16, var20, var18, var19).color(var15);
      var14.vertex(var16, var20, var18, var22).color(var15);
      var14.vertex(var16, var17, var18, var22).color(var15);
      var14.vertex(var16, var17, var21, var19).color(var15);
      var14.vertex(var16, var17, var21, var22).color(var15);
      var14.vertex(var16, var20, var21, var22).color(var15);
      var14.vertex(var16, var20, var21, var19).color(var15);
      var14.vertex(var16, var17, var18, var19).color(var15);
      var14.vertex(var16, var17, var21, var19).color(var15);
      var14.vertex(var16, var20, var21, var19).color(var15);
      var14.vertex(var16, var20, var18, var19).color(var15);
      var14.vertex(var16, var20, var18, var22).color(var15);
      var14.vertex(var16, var20, var21, var22).color(var15);
      var14.vertex(var16, var17, var21, var22).color(var15);
      var14.vertex(var16, var17, var18, var22).color(var15);
      var14.vertex(var16, var17, var18, var22).color(var15);
      var14.vertex(var16, var17, var21, var22).color(var15);
      var14.vertex(var16, var17, var21, var19).color(var15);
      var14.vertex(var16, var17, var18, var19).color(var15);
      var14.vertex(var16, var20, var18, var19).color(var15);
      var14.vertex(var16, var20, var21, var19).color(var15);
      var14.vertex(var16, var20, var21, var22).color(var15);
      var14.vertex(var16, var20, var18, var22).color(var15);
      this.V = true;
   }

   public void KeyFile(double d, double e, double f, double g, double h, double i, Color color) {
      VertexConsumer var14 = this.KeyFile.getBuffer(RenderLayers.lines());
      int var15 = color.getAlpha() << 24 | color.getRed() << 16 | color.getGreen() << 8 | color.getBlue();
      VertexRendering.drawOutline(this.KeyFile, var14, VoxelShapes.cuboid(d, e, f, g, h, i), 0.0, 0.0, 0.0, var15, 2.0F);
      this.V = true;
   }

   public void HwidGen(Color color, Vec3d vec3d, Vec3d vec3d2, float f) {
      VertexConsumer var5 = this.KeyFile.getBuffer(RenderLayers.lines());
      int var6 = color.getAlpha() << 24 | color.getRed() << 16 | color.getGreen() << 8 | color.getBlue();
      Entry var7 = this.KeyFile.peek();
      Vector3f var8 = new Vector3f((float)(vec3d2.x - vec3d.x), (float)(vec3d2.y - vec3d.y), (float)(vec3d2.z - vec3d.z)).normalize();
      float var9 = Math.max(1.0F, f);
      var5.vertex(var7, (float)vec3d.x, (float)vec3d.y, (float)vec3d.z).color(var6).normal(var7, var8).lineWidth(var9);
      var5.vertex(var7, (float)vec3d2.x, (float)vec3d2.y, (float)vec3d2.z).color(var6).normal(var7, var8).lineWidth(var9);
      this.V = true;
   }

   public void HwidGen(double d, double e, double f, double g, double h, double i, Color color, int j, ChunkPos chunkPos, Set set) {
      if (j <= 0) {
         this.HwidGen(d, e, f, g, h, i, color);
      } else {
         VertexConsumer var17 = this.KeyFile.getBuffer(RenderLayers.debugFilledBox());
         Entry var18 = this.KeyFile.peek();
         int var19 = color.getRed();
         int var20 = color.getGreen();
         int var21 = color.getBlue();
         int var22 = color.getAlpha();
         double var23 = g - d;
         double var25 = i - f;
         double var27 = var23 / j;
         double var29 = var25 / j;
         float var31 = (float)e;
         float var32 = (float)h;
         boolean var33 = set != null && chunkPos != null;
         ChunkPos var34 = null;
         ChunkPos var35 = null;
         ChunkPos var36 = null;
         ChunkPos var37 = null;
         if (var33) {
            var34 = new ChunkPos(chunkPos.x, chunkPos.z - 1);
            var35 = new ChunkPos(chunkPos.x, chunkPos.z + 1);
            var36 = new ChunkPos(chunkPos.x - 1, chunkPos.z);
            var37 = new ChunkPos(chunkPos.x + 1, chunkPos.z);
         }

         double var38 = Math.min(var23, var25) / 2.0;
         double var40 = Math.sqrt(var23 * var23 + var25 * var25) / 2.0;
         double var42 = (d + g) / 2.0;
         double var44 = (f + i) / 2.0;

         for (int var46 = 0; var46 < j; var46++) {
            for (int var47 = 0; var47 < j; var47++) {
               double var48 = d + var46 * var27;
               double var50 = f + var47 * var29;
               double var52 = var48 + var27;
               double var54 = var50 + var29;
               double var56 = (var48 + var52) / 2.0;
               double var58 = (var50 + var54) / 2.0;
               double var60;
               if (var33) {
                  double var62 = var56 - d;
                  double var64 = var58 - f;
                  double var66 = Double.MAX_VALUE;
                  if (!set.contains(var34)) {
                     var66 = Math.min(var66, var64);
                  }

                  if (!set.contains(var35)) {
                     var66 = Math.min(var66, 16.0 - var64);
                  }

                  if (!set.contains(var36)) {
                     var66 = Math.min(var66, var62);
                  }

                  if (!set.contains(var37)) {
                     var66 = Math.min(var66, 16.0 - var62);
                  }

                  var60 = Math.min(1.0, var66 / var38);
               } else {
                  double var69 = var56 - var42;
                  double var72 = var58 - var44;
                  double var73 = Math.sqrt(var69 * var69 + var72 * var72);
                  var60 = Math.min(1.0, var73 / var40);
               }

               var60 = var60 * var60 * (3.0 - 2.0 * var60);
               int var70 = (int)(var22 * (0.05 + 0.95 * (1.0 - var60)));
               var70 = Math.max(1, Math.min(255, var70));
               int var63 = var70 << 24 | var19 << 16 | var20 << 8 | var21;
               var17.vertex(var18, (float)var48, var32, (float)var50).color(var63);
               var17.vertex(var18, (float)var52, var32, (float)var50).color(var63);
               var17.vertex(var18, (float)var52, var32, (float)var54).color(var63);
               var17.vertex(var18, (float)var48, var32, (float)var54).color(var63);
               var17.vertex(var18, (float)var48, var31, (float)var50).color(var63);
               var17.vertex(var18, (float)var48, var31, (float)var54).color(var63);
               var17.vertex(var18, (float)var52, var31, (float)var54).color(var63);
               var17.vertex(var18, (float)var52, var31, (float)var50).color(var63);
            }
         }

         this.V = true;
      }
   }

   public void Module_FakePay() {
      if (!this.W) {
         try {
            if (this.V) {
               GL11.glDisable(2929);
               this.KeyFile.draw();
               GL11.glEnable(2929);
               this.V = false;
            }
         } finally {
            this.KeyFile.close();
            this.W = true;
         }
      }
   }
}
