import java.awt.Color;
import net.minecraft.util.math.Box;

class Obj_ct {
   double c;
   double LicenseResult;
   double LicenseState;
   Box HwidGen;
   Color Module;

   Obj_ct(double d, double e, double f, Box box, Color color) {
      this.c = d;
      this.LicenseResult = e;
      this.LicenseState = f;
      this.HwidGen = box;
      this.Module = color;
   }
}
