import java.awt.Color;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.render.VertexConsumerProvider.Immediate;
import net.minecraft.client.util.BufferAllocator;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.util.math.MatrixStack.Entry;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShapes;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;

final class Render_dn {
   private final BufferAllocator HwidGen = new BufferAllocator(524288);
   private final Immediate HwidGen = VertexConsumerProvider.immediate(this.HwidGen);
   private MatrixStack HwidGen;
   private boolean V;

   private Render_dn() {
   }

   void HwidGen(MatrixStack matrixStack) {
      this.HwidGen = matrixStack;
      this.V = false;
   }

   void HwidGen(double d, double e, double f, double g, double h, double i, Color color) {
      VertexConsumer var14 = this.HwidGen.getBuffer(RenderLayers.debugFilledBox());
      int var15 = color.getAlpha() << 24 | color.getRed() << 16 | color.getGreen() << 8 | color.getBlue();
      Entry var16 = this.HwidGen.peek();
      float var17 = (float)d;
      float var18 = (float)e;
      float var19 = (float)f;
      float var20 = (float)g;
      float var21 = (float)h;
      float var22 = (float)i;
      var14.vertex(var16, var17, var18, var19).color(var15);
      var14.vertex(var16, var20, var18, var19).color(var15);
      var14.vertex(var16, var20, var18, var22).color(var15);
      var14.vertex(var16, var17, var18, var22).color(var15);
      var14.vertex(var16, var17, var21, var19).color(var15);
      var14.vertex(var16, var17, var21, var22).color(var15);
      var14.vertex(var16, var20, var21, var22).color(var15);
      var14.vertex(var16, var20, var21, var19).color(var15);
      var14.vertex(var16, var17, var18, var19).color(var15);
      var14.vertex(var16, var17, var21, var19).color(var15);
      var14.vertex(var16, var20, var21, var19).color(var15);
      var14.vertex(var16, var20, var18, var19).color(var15);
      var14.vertex(var16, var20, var18, var22).color(var15);
      var14.vertex(var16, var20, var21, var22).color(var15);
      var14.vertex(var16, var17, var21, var22).color(var15);
      var14.vertex(var16, var17, var18, var22).color(var15);
      var14.vertex(var16, var17, var18, var22).color(var15);
      var14.vertex(var16, var17, var21, var22).color(var15);
      var14.vertex(var16, var17, var21, var19).color(var15);
      var14.vertex(var16, var17, var18, var19).color(var15);
      var14.vertex(var16, var20, var18, var19).color(var15);
      var14.vertex(var16, var20, var21, var19).color(var15);
      var14.vertex(var16, var20, var21, var22).color(var15);
      var14.vertex(var16, var20, var18, var22).color(var15);
      this.V = true;
   }

   void KeyFile(double d, double e, double f, double g, double h, double i, Color color) {
      VertexConsumer var14 = this.HwidGen.getBuffer(RenderLayers.lines());
      int var15 = color.getAlpha() << 24 | color.getRed() << 16 | color.getGreen() << 8 | color.getBlue();
      VertexRendering.drawOutline(this.HwidGen, var14, VoxelShapes.cuboid(d, e, f, g, h, i), 0.0, 0.0, 0.0, var15, 2.0F);
      this.V = true;
   }

   void HwidGen(Color color, Vec3d vec3d, Vec3d vec3d2, float f) {
      VertexConsumer var5 = this.HwidGen.getBuffer(RenderLayers.lines());
      int var6 = color.getAlpha() << 24 | color.getRed() << 16 | color.getGreen() << 8 | color.getBlue();
      Entry var7 = this.HwidGen.peek();
      Vector3f var8 = new Vector3f((float)(vec3d2.x - vec3d.x), (float)(vec3d2.y - vec3d.y), (float)(vec3d2.z - vec3d.z)).normalize();
      float var9 = Math.max(1.0F, f);
      var5.vertex(var7, (float)vec3d.x, (float)vec3d.y, (float)vec3d.z).color(var6).normal(var7, var8).lineWidth(var9);
      var5.vertex(var7, (float)vec3d2.x, (float)vec3d2.y, (float)vec3d2.z).color(var6).normal(var7, var8).lineWidth(var9);
      this.V = true;
   }

   void Module_FakePay() {
      if (this.V) {
         GL11.glDisable(2929);
         this.HwidGen.draw();
         GL11.glEnable(2929);
         this.V = false;
      }
   }
}
