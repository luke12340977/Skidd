import com.zelith.gui.ConfigsScreen;

public final class Module_Configs extends Module {
   public Module_Configs() {
      super("Configs", Category.Module_f);
   }

   @Override
   public void LicenseState() {
      if (HwidGen != null) {
         HwidGen.execute(() -> HwidGen.setScreen(new ConfigsScreen(this)));
      }
   }

   @Override
   public void Module_f() {
      if (HwidGen != null && HwidGen.currentScreen instanceof ConfigsScreen) {
         HwidGen.execute(() -> HwidGen.setScreen(null));
      }
   }
}
