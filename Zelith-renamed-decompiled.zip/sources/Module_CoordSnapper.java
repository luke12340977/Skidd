import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.zelith.ZelithClient;
import com.zelith.gui.notification.NotificationManager;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpClient.Redirect;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Util;

public final class Module_CoordSnapper extends Module_f {
   private static final Duration KeyFile = Duration.ofSeconds(8L);
   private static final ItemStack LicenseResult = new ItemStack(Items.RECOVERY_COMPASS);
   private static final DateTimeFormatter KeyFile = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss z", Locale.ROOT);
   private static final HttpClient c;
   private final dd bp = new bl$1(this, "Webhook", "");
   private final dd Module_HomeSetter = new Setting("Notification", true);
   private volatile long HudElement;

   public Module_CoordSnapper() {
      super("Coord Snapper", Category.HwidGen);
      this.HwidGen(this.bp);
      this.HwidGen(this.Module_HomeSetter);
   }

   @Override
   public void KeyFile() {
      if (this.HwidGen() && HwidGen.player != null) {
         long var1 = System.currentTimeMillis();
         if (var1 - this.HudElement >= 250L) {
            this.HudElement = var1;
            String var3 = this.LicenseState((String)this.bp.HwidGen());
            if (!this.KeyFile(var3)) {
               this.HwidGen("Webhook invalid", "Set a Discord webhook URL.", -1002662);
            } else {
               bm var4 = this.HwidGen(var3);
               CompletableFuture.runAsync(() -> this.HwidGen(var4), Util.getIoWorkerExecutor().named("coordsnapper-send"))
                  .whenComplete((void_, throwable) -> HwidGen.execute(() -> {
                     if (throwable != null) {
                        this.HwidGen("Send failed", this.HwidGen(throwable), -1938838);
                     } else {
                        this.HwidGen("Coords sent", var4.Module_WaterMark(), -11152222);
                     }
                  }));
            }
         }
      }
   }

   private bm HwidGen(String string) {
      int var2 = HwidGen.player.getBlockX();
      int var3 = HwidGen.player.getBlockY();
      int var4 = HwidGen.player.getBlockZ();
      String var5 = HwidGen.player.getName().getString();
      String var6 = this.Category();
      String var7 = KeyFile.format(ZonedDateTime.now());
      String var8 = this.Module_f(var5);
      String var9 = "https://mc-heads.net/body/" + var8;
      return new Rec_bm(string, var5, var2, var3, var4, var6, var7, var9);
   }

   private void HwidGen(bm arg) {
      JsonObject var2 = new JsonObject();
      var2.addProperty("username", "CoordSnapper");
      JsonObject var3 = new JsonObject();
      var3.addProperty("title", "CoordSnapper");
      var3.addProperty("color", 5624994);
      JsonArray var4 = new JsonArray();
      var4.add(this.HwidGen("Name", arg.Module_ActiveModules(), false));
      var4.add(this.HwidGen("Coords", arg.Module_Themes(), false));
      var4.add(this.HwidGen("IP", arg.Module_Friends(), true));
      var4.add(this.HwidGen("Time", arg.Module_Hud(), true));
      var3.add("fields", var4);
      JsonObject var5 = new JsonObject();
      var5.addProperty("url", arg.HudElement());
      var3.add("thumbnail", var5);
      JsonArray var6 = new JsonArray();
      var6.add(var3);
      var2.add("embeds", var6);
      HttpRequest var7 = HttpRequest.newBuilder(this.HwidGen(arg.Module()))
         .timeout(KeyFile)
         .header("Content-Type", "application/json")
         .header("Accept", "application/json")
         .header("User-Agent", "zelith-CoordSnapper")
         .POST(BodyPublishers.ofString(var2.toString()))
         .build();

      HttpResponse var8;
      try {
         var8 = c.send(var7, BodyHandlers.ofString());
      } catch (Exception var11) {
         ZelithClient.LOGGER.error("CoordSnapper webhook request failed", (Throwable)var11);
         throw new IllegalStateException("Webhook request failed", var11);
      }

      int var9 = var8.statusCode();
      if (var9 >= 200 && var9 < 300) {
         ZelithClient.LOGGER.info("CoordSnapper sent coords for {}", arg.Module_ActiveModules());
      } else {
         String var10 = (String)var8.body();
         if (var10 != null && !var10.isBlank()) {
            ZelithClient.LOGGER.warn("CoordSnapper webhook rejected with status {} and body {}", var9, this.KeyFile(var10, 240));
            throw new IllegalStateException("HTTP " + var9 + ": " + this.KeyFile(var10, 120));
         } else {
            ZelithClient.LOGGER.warn("CoordSnapper webhook rejected with status {}", var9);
            throw new IllegalStateException("HTTP " + var9);
         }
      }
   }

   private JsonObject HwidGen(String string, String string2, boolean bl) {
      JsonObject var4 = new JsonObject();
      var4.addProperty("name", string);
      var4.addProperty("value", string2 != null && !string2.isBlank() ? string2 : "-");
      var4.addProperty("inline", bl);
      return var4;
   }

   private String Category() {
      ServerInfo var1 = HwidGen.getCurrentServerEntry();
      if (var1 != null && var1.address != null && !var1.address.isBlank()) {
         String var2 = this.LicenseResult(var1.address);
         return var2.isEmpty() ? "Singleplayer" : var2;
      } else {
         return "Singleplayer";
      }
   }

   private String LicenseResult(String string) {
      String var2 = string == null ? "" : string.trim().toLowerCase(Locale.ROOT);
      int var3 = var2.indexOf(47);
      if (var3 >= 0) {
         var2 = var2.substring(0, var3);
      }

      int var4 = var2.indexOf(58);
      if (var4 >= 0) {
         var2 = var2.substring(0, var4);
      }

      return var2;
   }

   private String LicenseState(String string) {
      return string == null ? "" : string.trim();
   }

   private String Module_f(String string) {
      return string != null && !string.isBlank() ? string.trim() : "Steve";
   }

   private URI HwidGen(String string) {
      URI var2 = URI.create(string);
      String var3 = var2.getQuery();
      if (var3 == null || var3.isBlank()) {
         return URI.create(string + "?wait=true");
      } else {
         return var3.contains("wait=") ? var2 : URI.create(string + "&wait=true");
      }
   }

   private boolean KeyFile(String string) {
      if (string.isEmpty()) {
         return false;
      } else {
         try {
            URI var2 = URI.create(string);
            String var3 = var2.getScheme();
            String var4 = var2.getHost();
            String var5 = var2.getPath();
            return ("https".equalsIgnoreCase(var3) || "http".equalsIgnoreCase(var3))
               && var4 != null
               && !var4.isBlank()
               && var5 != null
               && var5.contains("/api/webhooks/");
         } catch (Exception var6) {
            return false;
         }
      }
   }

   private void HwidGen(String string, String string2, int i) {
      if (HwidGen != null && (Boolean)this.Module_HomeSetter.HwidGen()) {
         HwidGen.execute(() -> NotificationManager.INSTANCE.push(string, string2, LicenseResult, i));
      }
   }

   private String HwidGen(Throwable throwable) {
      Throwable var2 = throwable;

      while (var2.getCause() != null) {
         var2 = var2.getCause();
      }

      String var3 = var2.getMessage();
      return var3 != null && !var3.isBlank() ? this.KeyFile(var3, 120) : var2.getClass().getSimpleName();
   }

   private String KeyFile(String string, int i) {
      if (string == null) {
         return "";
      } else {
         String var3 = string.replace('\n', ' ').replace('\r', ' ').trim();
         return var3.length() <= i ? var3 : var3.substring(0, Math.max(0, i - 3)) + "...";
      }
   }

   static {
      c = HttpClient.newBuilder().connectTimeout(KeyFile).followRedirects(Redirect.NORMAL).build();
   }
}
