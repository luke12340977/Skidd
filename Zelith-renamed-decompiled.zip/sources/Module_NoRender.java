import net.minecraft.world.biome.Biome.Precipitation;

public final class Module_NoRender extends Module {
   public static cn HwidGen;
   private final dd Module_PlayerESP = new Setting("Rain", true);
   private final dd Toast_cp = new Setting("Snow", true);
   private final dd Obj_cq = new Setting("Thunder", true);

   public Module_NoRender() {
      super("No Render", Category.KeyFile);
      HwidGen = this;
      this.HwidGen(this.Module_PlayerESP);
      this.HwidGen(this.Toast_cp);
      this.HwidGen(this.Obj_cq);
   }

   public static boolean Module_f() {
      return HwidGen != null && HwidGen.HwidGen() && HwidGen != null && HwidGen.world != null;
   }

   public static boolean G() {
      return Module_f() && (Boolean)HwidGen.Module_PlayerESP.HwidGen();
   }

   public static boolean H() {
      return Module_f() && (Boolean)HwidGen.Toast_cp.HwidGen();
   }

   public static boolean I() {
      return Module_f() && (Boolean)HwidGen.Obj_cq.HwidGen();
   }

   public static boolean J() {
      return G() && H();
   }

   public static Precipitation HwidGen(Precipitation precipitation) {
      if (!Module_f() || precipitation == null) {
         return precipitation;
      } else if (precipitation == Precipitation.RAIN && G()) {
         return Precipitation.NONE;
      } else {
         return precipitation == Precipitation.SNOW && H() ? Precipitation.NONE : precipitation;
      }
   }
}
