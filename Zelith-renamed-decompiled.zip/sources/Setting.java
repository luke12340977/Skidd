import java.util.function.Supplier;

public class Setting {
   private final String I;
   private final Object c;
   private Object LicenseResult;
   private Object LicenseState;
   private Object Module_f;
   private Supplier HwidGen = () -> true;

   public Setting(String string, Object object) {
      this.I = string;
      this.LicenseResult = object;
      this.c = object;
   }

   public Setting(String string, Object object, Object object2, Object object3) {
      this.I = string;
      this.LicenseResult = object;
      this.c = object;
      this.LicenseState = object2;
      this.Module_f = object3;
   }

   public String c() {
      return this.I;
   }

   public Object HwidGen() {
      return this.LicenseResult;
   }

   public boolean LicenseResult(String string) {
      return this.I.equalsIgnoreCase(string);
   }

   public dd HwidGen(Supplier supplier) {
      this.HwidGen = supplier == null ? () -> true : supplier;
      return this;
   }

   public boolean K() {
      try {
         return this.HwidGen == null || (Boolean)this.HwidGen.get();
      } catch (Exception var2) {
         return true;
      }
   }

   public void HwidGen(Object object) {
      this.LicenseResult = object;
      SwapHelper.HwidGen.SwapHelper();
   }

   public Object KeyFile() {
      return this.LicenseState;
   }

   public Object c() {
      return this.Module_f;
   }
}
