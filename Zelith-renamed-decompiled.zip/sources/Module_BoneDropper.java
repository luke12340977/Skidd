import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult.Type;

public final class Module_BoneDropper extends Module {
   private final cy c = new Misc_cy("Mode", "Spawner", "Spawner", "Orders");
   private final dd Toast_ai = new Setting("Delay", 300, 100, 2000);
   private ak HwidGen = Enum_ak.KeyFile;
   private String Module_j = (String)this.c.HwidGen();
   private long Module;
   private int Module_SpotifyHUD;
   private long SwapHelper;
   private boolean Module_AutoCrystal;

   public Module_BoneDropper() {
      super("Bone Dropper", Category.LicenseState);
      this.HwidGen(this.c);
      this.HwidGen(this.Toast_ai);
   }

   @Override
   public void LicenseState() {
      this.Module_AutoCrystal();
   }

   @Override
   public void Module_f() {
      this.HwidGen = Enum_ak.KeyFile;
      this.Module = 0L;
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.world != null && HwidGen.interactionManager != null) {
         if (HwidGen.currentScreen == null || HwidGen.currentScreen instanceof HandledScreen) {
            if (!((String)this.c.HwidGen()).equalsIgnoreCase(this.Module_j)) {
               this.Module_AutoCrystal();
            }

            long var1 = System.currentTimeMillis();
            if (var1 >= this.Module) {
               if (this.c.Module_f("Spawner")) {
                  this.A();
               } else {
                  this.B();
               }
            }
         }
      }
   }

   private void A() {
      switch (this.HwidGen) {
         case KeyFile:
            if (this.Module_Configs()) {
               this.HwidGen = Enum_ak.c;
               this.E();
               return;
            }

            this.C();
            this.HwidGen = Enum_ak.c;
            this.E();
            break;
         case c:
            if (!this.Module_Configs()) {
               this.HwidGen = Enum_ak.KeyFile;
               this.E();
               return;
            }

            this.HwidGen = Enum_ak.LicenseResult;
            this.E();
            break;
         case LicenseResult:
            ScreenHandler var7 = this.HwidGen();
            if (var7 == null) {
               this.HwidGen = Enum_ak.KeyFile;
               this.E();
               return;
            }

            if (!this.HwidGen(var7)) {
               this.E();
               return;
            }

            this.HwidGen = Enum_ak.LicenseState;
            this.E();
            break;
         case LicenseState:
            ScreenHandler var6 = this.HwidGen();
            if (var6 == null) {
               this.HwidGen = Enum_ak.KeyFile;
               this.E();
               return;
            }

            Slot var2 = this.HwidGen(var6);
            if (var2 == null) {
               this.E();
               return;
            }

            this.Module_AutoCrystal = this.HwidGen(var6);
            if (!this.Module_AutoCrystal) {
               this.HwidGen = Enum_ak.LicenseResult;
               this.E();
               return;
            }

            this.Module_SpotifyHUD = this.LicenseResult(Items.BONE);
            this.SwapHelper = System.currentTimeMillis();
            this.HwidGen(var2);
            this.HwidGen = Enum_ak.Module_f;
            this.E();
            break;
         case Module_f:
            long var1 = System.currentTimeMillis();
            ScreenHandler var3 = this.HwidGen();
            boolean var4 = this.Module_AutoCrystal && var3 != null && !this.HwidGen(var3);
            boolean var5 = this.LicenseResult(Items.BONE) > this.Module_SpotifyHUD;
            if (var4 || var5) {
               if (var3 != null) {
                  this.D();
               }

               this.HwidGen = Enum_ak.Category;
               this.Module = Long.MAX_VALUE;
               return;
            }

            if (this.SwapHelper > 0L && var1 - this.SwapHelper > 4000L) {
               this.HwidGen = var3 == null ? Enum_ak.KeyFile : Enum_ak.LicenseResult;
               this.E();
               return;
            }

            this.E();
         case Category:
            break;
         default:
            this.HwidGen = Enum_ak.KeyFile;
            this.E();
      }
   }

   private void B() {
      switch (this.HwidGen) {
         case Module:
            if (!this.Module_Configs()) {
               this.Module("/order");
               this.HwidGen = Enum_ak.SwapHelper;
               this.E();
               return;
            }

            this.HwidGen = Enum_ak.Module_j;
            this.E();
            break;
         case SwapHelper:
            if (!this.Module_Configs()) {
               this.Module("/order");
               this.E();
               return;
            }

            this.HwidGen = Enum_ak.Module_j;
            this.E();
            break;
         case Module_j:
            this.HwidGen(Enum_al.KeyFile, Enum_ak.Module_ActiveModules);
            break;
         case Module_ActiveModules:
            this.HwidGen(Enum_al.HwidGen, Enum_ak.ClickBuf);
            break;
         case ClickBuf:
            this.HwidGen(Enum_al.KeyFile, Enum_ak.Module_Configs);
            break;
         case Module_Configs:
            this.HwidGen(Enum_al.c, Enum_ak.Module_Friends);
            break;
         case Module_Friends:
            this.HwidGen(Enum_al.LicenseResult, Enum_ak.Module_Hud);
            break;
         case Module_Hud:
            this.HwidGen(Enum_al.c, Enum_ak.Module_j);
            break;
         default:
            this.HwidGen = Enum_ak.Module;
            this.E();
      }
   }

   private void HwidGen(al arg, ak arg2) {
      ScreenHandler var3 = this.HwidGen();
      if (var3 == null) {
         this.Module("/order");
         this.E();
      } else {
         Slot var4 = this.HwidGen(var3, arg, arg == Enum_al.c || arg == Enum_al.LicenseResult);
         if (var4 == null) {
            this.E();
         } else {
            this.HwidGen(var4);
            this.HwidGen = arg2;
            this.E();
         }
      }
   }

   private boolean HwidGen(ScreenHandler screenHandler) {
      List var2 = this.HwidGen(screenHandler);
      if (var2.isEmpty()) {
         return false;
      } else {
         for (Slot var4 : var2) {
            if (var4.isEnabled()) {
               ItemStack var5 = var4.getStack();
               if (var5.isEmpty() || !this.HwidGen(var5, Enum_al.HwidGen)) {
                  return false;
               }
            }
         }

         return true;
      }
   }

   private List HwidGen(ScreenHandler screenHandler) {
      List var2 = this.KeyFile(screenHandler);
      if (var2.isEmpty()) {
         return List.of();
      } else {
         int var3 = var2.stream().mapToInt(slot -> slot.y).max().orElse(Integer.MIN_VALUE);
         ArrayList var4 = new ArrayList();

         for (Slot var6 : var2) {
            if (var6.y < var3) {
               var4.add(var6);
            }
         }

         return (List)(var4.isEmpty() ? var2 : var4);
      }
   }

   private Slot HwidGen(ScreenHandler screenHandler) {
      List var2 = this.KeyFile(screenHandler);
      if (var2.isEmpty()) {
         return null;
      } else {
         int var3 = var2.stream().mapToInt(slot -> slot.y).max().orElse(Integer.MIN_VALUE);
         Slot var4 = this.HwidGen(var2, Enum_al.c, true, var3);
         if (var4 != null) {
            return var4;
         } else {
            Slot var5 = this.HwidGen(var2, Enum_al.c, true, Integer.MIN_VALUE);
            if (var5 != null) {
               return var5;
            } else {
               for (int var6 = var2.size() - 1; var6 >= 0; var6--) {
                  Slot var7 = (Slot)var2.get(var6);
                  if (var7.isEnabled()) {
                     return var7;
                  }
               }

               return null;
            }
         }
      }
   }

   private Slot HwidGen(ScreenHandler screenHandler, al arg, boolean bl) {
      return this.HwidGen(this.KeyFile(screenHandler), arg, bl, Integer.MIN_VALUE);
   }

   private Slot HwidGen(List list, al arg, boolean bl, int i) {
      Slot var5 = null;

      for (Slot var7 : list) {
         if (var7.isEnabled() && (i == Integer.MIN_VALUE || var7.y == i) && this.HwidGen(var7.getStack(), arg)) {
            if (var5 == null) {
               var5 = var7;
            } else if (bl) {
               if (var7.y > var5.y || var7.y == var5.y && var7.x >= var5.x) {
                  var5 = var7;
               }
            } else if (var7.y < var5.y || var7.y == var5.y && var7.x < var5.x) {
               var5 = var7;
            }
         }
      }

      return var5;
   }

   private boolean HwidGen(ItemStack itemStack, al arg) {
      if (itemStack != null && !itemStack.isEmpty()) {
         Item var3 = itemStack.getItem();
         String var4 = itemStack.getName().getString().toLowerCase(Locale.ROOT);

         return switch (arg) {
            case HwidGen -> var3 == Items.BONE || var4.contains("bone");
            case KeyFile -> var3 == Items.CHEST || var3 == Items.TRAPPED_CHEST || var3 == Items.ENDER_CHEST || var4.contains("chest") || var4.contains("truhe");
            case c -> var3 == Items.DROPPER || var4.contains("dropper");
            case LicenseResult -> var3 == Items.ARROW || var4.contains("arrow") || var4.contains("pfeil");
         };
      } else {
         return false;
      }
   }

   private List KeyFile(ScreenHandler screenHandler) {
      if (screenHandler != null && screenHandler.slots != null && !screenHandler.slots.isEmpty()) {
         int var2 = Math.max(0, screenHandler.slots.size() - 36);
         if (var2 == 0) {
            var2 = screenHandler.slots.size();
         }

         ArrayList var3 = new ArrayList(var2);

         for (int var4 = 0; var4 < var2; var4++) {
            var3.add((Slot)screenHandler.slots.get(var4));
         }

         return var3;
      } else {
         return List.of();
      }
   }

   private int LicenseResult(Item item) {
      if (HwidGen.player == null) {
         return 0;
      } else {
         int var2 = 0;

         for (int var3 = 0; var3 < HwidGen.player.getInventory().size(); var3++) {
            ItemStack var4 = HwidGen.player.getInventory().getStack(var3);
            if (!var4.isEmpty() && var4.isOf(item)) {
               var2 += var4.getCount();
            }
         }

         return var2;
      }
   }

   private void HwidGen(Slot slot) {
      if (slot != null && HwidGen.player != null && HwidGen.interactionManager != null) {
         HwidGen.interactionManager.clickSlot(HwidGen.player.currentScreenHandler.syncId, slot.id, 0, SlotActionType.PICKUP, HwidGen.player);
      }
   }

   private void C() {
      if (HwidGen.crosshairTarget instanceof BlockHitResult var1 && HwidGen.crosshairTarget.getType() == Type.BLOCK) {
         HwidGen.interactionManager.interactBlock(HwidGen.player, Hand.MAIN_HAND, var1);
         HwidGen.player.swingHand(Hand.MAIN_HAND);
      }
   }

   private void D() {
      if (HwidGen.player != null) {
         if (HwidGen.currentScreen instanceof HandledScreen) {
            HwidGen.player.closeHandledScreen();
            HwidGen.setScreen(null);
         }
      }
   }

   private ScreenHandler HwidGen() {
      return HwidGen.currentScreen instanceof HandledScreen && HwidGen.player != null ? HwidGen.player.currentScreenHandler : null;
   }

   private boolean Module_Configs() {
      return this.HwidGen() != null;
   }

   private void Module(String string) {
      ClientPlayNetworkHandler var2 = HwidGen.player != null ? HwidGen.player.networkHandler : HwidGen.getNetworkHandler();
      if (var2 != null) {
         String var3 = string.startsWith("/") ? string.substring(1) : string;

         try {
            var2.sendChatCommand(var3);
         } catch (Throwable var5) {
            var2.sendChatMessage(string);
         }
      }
   }

   private void Module_AutoCrystal() {
      this.Module_j = (String)this.c.HwidGen();
      this.HwidGen = this.c.Module_f("Spawner") ? Enum_ak.KeyFile : Enum_ak.Module;
      this.Module = 0L;
      this.Module_SpotifyHUD = 0;
      this.SwapHelper = 0L;
      this.Module_AutoCrystal = false;
   }

   private void E() {
      this.Module = System.currentTimeMillis() + ((Integer)this.Toast_ai.HwidGen()).intValue();
   }
}
