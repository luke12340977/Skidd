import com.zelith.gui.notification.NotificationManager;
import java.awt.Color;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ChunkDeltaUpdateS2CPacket;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;

public final class Module_ActivityFinder extends Module {
   private final dd Module_Hitbox = new Setting("y-level", 16.0F, -64.0F, 320.0F);
   private final dd Module_HoverTotem = new Setting("Notification", false);
   private final Set HwidGen = Collections.newSetFromMap(new ConcurrentHashMap());
   private final Map KeyFile = new ConcurrentHashMap();
   private static final Color HwidGen = new Color(255, 220, 0, 180);
   private static final Color KeyFile = new Color(255, 220, 0, 255);
   private final Map c = new ConcurrentHashMap();
   private final Map LicenseResult = new ConcurrentHashMap();
   private final Map LicenseState = new ConcurrentHashMap();
   private final Map Module_f = new ConcurrentHashMap();
   private final ThreadLocal HwidGen = ThreadLocal.withInitial(() -> Collections.newSetFromMap(new ConcurrentHashMap()));

   public Module_ActivityFinder() {
      super("Activity Finder", Category.LicenseState);
      this.HwidGen(this.Module_Hitbox);
      this.HwidGen(this.Module_HoverTotem);
   }

   @Override
   public void Module_f() {
      this.HwidGen.clear();
      this.KeyFile.clear();
      this.c.clear();
      this.LicenseResult.clear();
      this.LicenseState.clear();
      this.Module_f.clear();
   }

   @Override
   public void HwidGen(Packet packet) {
      if (packet instanceof ChunkDeltaUpdateS2CPacket var4) {
         var4.visitUpdates((blockPos, blockState) -> this.HwidGen(blockPos.getX(), blockPos.getY(), blockPos.getZ()));
      } else if (packet instanceof BlockUpdateS2CPacket var2) {
         BlockPos var3 = var2.getPos();
         this.HwidGen(var3.getX(), var3.getY(), var3.getZ());
      } else {
         ((Set)this.HwidGen.get()).clear();
         this.HwidGen(packet, 0);
      }
   }

   private void HwidGen(Object object, int i) {
      if (object != null && i <= 3) {
         int var3 = System.identityHashCode(object);
         if (((Set)this.HwidGen.get()).add(var3)) {
            Class var4 = object.getClass();
            this.LicenseState.computeIfAbsent(var4, class_ -> this.HwidGen(class_, BlockPos.class));
            this.Module_f.computeIfAbsent(var4, class_ -> this.HwidGen(class_, Vec3d.class));
            this.c.computeIfAbsent(var4, class_ -> this.HwidGen(class_, double.class));
            this.LicenseResult
               .computeIfAbsent(
                  var4,
                  class_ -> {
                     ArrayList var1 = new ArrayList();

                     while (class_ != null && class_ != Object.class) {
                        for (Field var5 : class_.getDeclaredFields()) {
                           if (!Modifier.isStatic(var5.getModifiers())
                              && !var5.getType().isPrimitive()
                              && !var5.getType().getName().startsWith("java.")
                              && !var5.getType().isEnum()) {
                              var5.setAccessible(true);
                              var1.add(var5);
                           }
                        }

                        class_ = class_.getSuperclass();
                     }

                     return var1;
                  }
               );

            for (Field var6 : (List)this.LicenseState.get(var4)) {
               try {
                  BlockPos var7 = (BlockPos)var6.get(object);
                  if (var7 != null) {
                     this.HwidGen(var7.getX(), var7.getY(), var7.getZ());
                  }
               } catch (Exception var15) {
               }
            }

            for (Field var18 : (List)this.Module_f.get(var4)) {
               try {
                  Vec3d var21 = (Vec3d)var18.get(object);
                  if (var21 != null) {
                     this.HwidGen(var21.x, var21.y, var21.z);
                  }
               } catch (Exception var14) {
               }
            }

            List var17 = (List)this.c.get(var4);
            if (var17.size() >= 3) {
               try {
                  double var19 = ((Field)var17.get(0)).getDouble(object);
                  double var8 = ((Field)var17.get(1)).getDouble(object);
                  double var10 = ((Field)var17.get(2)).getDouble(object);
                  if (Math.abs(var19) < 3.0E7 && Math.abs(var10) < 3.0E7 && var8 > -2048.0 && var8 < 2048.0) {
                     this.HwidGen(var19, var8, var10);
                  }
               } catch (Exception var13) {
               }
            }

            for (Field var22 : (List)this.LicenseResult.get(var4)) {
               try {
                  Object var23 = var22.get(object);
                  if (var23 != null) {
                     this.HwidGen(var23, i + 1);
                  }
               } catch (Exception var12) {
               }
            }
         }
      }
   }

   private List HwidGen(Class class_, Class class2) {
      ArrayList var3 = new ArrayList();

      while (class_ != null && class_ != Object.class) {
         for (Field var7 : class_.getDeclaredFields()) {
            if (!Modifier.isStatic(var7.getModifiers()) && var7.getType() == class2) {
               var7.setAccessible(true);
               var3.add(var7);
            }
         }

         class_ = class_.getSuperclass();
      }

      return var3;
   }

   private void HwidGen(double d, double e, double f) {
      if (HwidGen.player == null || !(HwidGen.player.getY() < 0.0)) {
         if (e <= ((Float)this.Module_Hitbox.HwidGen()).floatValue()) {
            ChunkPos var7 = new ChunkPos((int)Math.floor(d) >> 4, (int)Math.floor(f) >> 4);
            if (this.HwidGen.add(var7)) {
               this.HwidGen(var7, e);
            }
         }
      }
   }

   private void HwidGen(ChunkPos chunkPos, double d) {
      if ((Boolean)this.Module_HoverTotem.HwidGen() && HwidGen.player != null && HwidGen.world != null) {
         long var4 = chunkPos.toLong();
         long var6 = System.currentTimeMillis();
         long var8 = this.KeyFile.getOrDefault(var4, 0L);
         if (var6 - var8 >= 1250L) {
            this.KeyFile.put(var4, var6);
            NotificationManager.INSTANCE
               .push(
                  "Activity detected", "Chunk " + chunkPos.x + ", " + chunkPos.z + "  Y " + (int)Math.floor(d), new ItemStack(Items.COMPASS), KeyFile.getRGB()
               );
            HwidGen.world
               .playSound(
                  HwidGen.player,
                  HwidGen.player.getX(),
                  HwidGen.player.getY(),
                  HwidGen.player.getZ(),
                  SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP,
                  SoundCategory.MASTER,
                  0.6F,
                  1.05F
               );
         }
      }
   }

   @Override
   public void HwidGen(MatrixStack matrixStack, float f) {
      if (HwidGen.world != null) {
         Camera var3 = Render_dm.HwidGen();
         if (var3 != null) {
            Vec3d var4 = Render_dm.HwidGen(var3);
            double var5 = Math.max((double)HwidGen.world.getBottomY(), Math.min(57.0, (double)HwidGen.world.getTopYInclusive()));
            do var7 = Render_dm.HwidGen(matrixStack);

            for (ChunkPos var9 : this.HwidGen) {
               if (Render_dm.HwidGen(var9.getStartX(), 57.0, var9.getStartZ(), var9.getEndX(), 57.05, var9.getEndZ())) {
                  double var10 = var9.getStartX() - var4.x;
                  double var12 = var9.getStartZ() - var4.z;
                  double var14 = var5 - var4.y;
                  double var16 = var10 + 16.0;
                  double var18 = var14 + 0.05;
                  double var20 = var12 + 16.0;
                  var7.HwidGen(var10, var14, var12, var16, var18, var20, HwidGen);
               }
            }

            var7.Module_FakePay();
         }
      }
   }
}
