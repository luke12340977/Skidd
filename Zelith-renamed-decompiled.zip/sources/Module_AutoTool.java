import java.util.function.Predicate;
import net.minecraft.block.BambooBlock;
import net.minecraft.block.BambooShootBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.LeavesBlock;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.AttributeModifiersComponent.Entry;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ShearsItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;

public final class Module_AutoTool extends Module {
   public Module_AutoTool() {
      super("Auto Tool", Category.HwidGen);
   }

   @Override
   public void Category() {
      if (HwidGen.player != null && HwidGen.world != null && HwidGen.interactionManager != null) {
         if (HwidGen.options.attackKey.isPressed() && HwidGen.crosshairTarget != null) {
            HitResult var1 = HwidGen.crosshairTarget;
            if (var1.getType() == Type.ENTITY && var1 instanceof EntityHitResult) {
               this.T();
            } else {
               if (var1.getType() == Type.BLOCK && var1 instanceof BlockHitResult var2) {
                  this.HwidGen(var2.getBlockPos());
               }
            }
         }
      }
   }

   private void HwidGen(BlockPos blockPos) {
      BlockState var2 = HwidGen.world.getBlockState(blockPos);
      ItemStack var3 = HwidGen.player.getMainHandStack();
      int var4 = -1;
      double var5 = -1.0;

      for (int var7 = 0; var7 < 9; var7++) {
         ItemStack var8 = HwidGen.player.getInventory().getStack(var7);
         double var9 = HwidGen(var8, var2, itemStack -> true);
         if (var9 > var5) {
            var5 = var9;
            var4 = var7;
         }
      }

      if (var4 != -1) {
         double var11 = HwidGen(var3, var2, itemStack -> true);
         if (var5 > var11 || !LicenseResult(var3)) {
            this.Module_f(var4);
         }
      }
   }

   private void T() {
      int var1 = -1;
      double var2 = Double.NEGATIVE_INFINITY;

      for (int var4 = 0; var4 < 9; var4++) {
         ItemStack var5 = HwidGen.player.getInventory().getStack(var4);
         if (!var5.isEmpty()) {
            double var6 = this.HwidGen(var5);
            if (var6 > var2) {
               var2 = var6;
               var1 = var4;
            }
         }
      }

      if (var1 != -1) {
         this.Module_f(var1);
      }
   }

   private double HwidGen(ItemStack itemStack) {
      AttributeModifiersComponent var2 = (AttributeModifiersComponent)itemStack.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
      double var3 = 0.0;
      if (var2 != null) {
         for (Entry var6 : var2.modifiers()) {
            if (var6.attribute().toString().contains("attack_damage")) {
               var3 += var6.modifier().value();
            }
         }
      }

      if (var3 > 0.0) {
         return var3;
      } else {
         String var7 = Registries.ITEM.getId(itemStack.getItem()).getPath();
         if (var7.endsWith("_sword")) {
            return 10.0 + this.HwidGen(var7);
         } else {
            return var7.endsWith("_axe") ? 5.0 + this.HwidGen(var7) : 0.0;
         }
      }
   }

   private void Module_f(int i) {
      if (i >= 0 && i <= 8) {
         if (HwidGen.player.getInventory().getSelectedSlot() != i) {
            HwidGen.player.getInventory().setSelectedSlot(i);
         }
      }
   }

   public static double HwidGen(ItemStack itemStack, BlockState blockState, Predicate predicate) {
      if (predicate.test(itemStack) && LicenseResult(itemStack)) {
         String var3 = Registries.ITEM.getId(itemStack.getItem()).getPath();
         boolean var4 = var3.endsWith("_sword");
         return !itemStack.isSuitableFor(blockState)
               && (!var4 || !(blockState.getBlock() instanceof BambooBlock) && !(blockState.getBlock() instanceof BambooShootBlock))
               && (!(itemStack.getItem() instanceof ShearsItem) || !(blockState.getBlock() instanceof LeavesBlock))
               && !blockState.isIn(BlockTags.WOOL)
            ? -1.0
            : itemStack.getMiningSpeedMultiplier(blockState) * 1000.0F;
      } else {
         return -1.0;
      }
   }

   public static boolean LicenseResult(ItemStack itemStack) {
      return KeyFile(itemStack.getItem());
   }

   public static boolean KeyFile(Item item) {
      if (item instanceof ShearsItem) {
         return true;
      } else {
         String var1 = Registries.ITEM.getId(item).getPath();
         return var1.endsWith("_pickaxe") || var1.endsWith("_axe") || var1.endsWith("_shovel") || var1.endsWith("_hoe") || var1.endsWith("_sword");
      }
   }

   private double HwidGen(String string) {
      if (string.startsWith("netherite_")) {
         return 6.0;
      } else if (string.startsWith("diamond_")) {
         return 5.0;
      } else if (string.startsWith("iron_")) {
         return 4.0;
      } else if (string.startsWith("golden_")) {
         return 3.0;
      } else if (string.startsWith("stone_")) {
         return 2.0;
      } else {
         return string.startsWith("wooden_") ? 1.0 : 0.0;
      }
   }
}
