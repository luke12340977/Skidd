import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import net.minecraft.client.MinecraftClient;

public final class ConfigMan {
   private static final Pattern KeyFile = Pattern.compile("[^A-Za-z0-9_\\- ]");

   public static Path KeyFile() {
      Path var0 = MinecraftClient.getInstance().runDirectory.toPath().resolve("zelith_configs");

      try {
         Files.createDirectories(var0);
      } catch (IOException var2) {
      }

      return var0;
   }

   private static Path c() {
      return MinecraftClient.getInstance().runDirectory.toPath().resolve("zelith_config.txt");
   }

   public static String sanitize(String string) {
      return string == null ? "" : KeyFile.matcher(string.trim()).replaceAll("_");
   }

   public static List Module() {
      ArrayList var0 = new ArrayList();
      Path var1 = KeyFile();
      if (!Files.isDirectory(var1)) {
         return var0;
      } else {
         try {
            Files.list(var1).forEach(path -> {
               String var2 = path.getFileName().toString();
               if (var2.endsWith(".txt")) {
                  var0.add(var2.substring(0, var2.length() - ".txt".length()));
               }
            });
         } catch (IOException var3) {
         }

         Collections.sort(var0, String.CASE_INSENSITIVE_ORDER);
         return var0;
      }
   }

   public static boolean Module(String string) {
      String var1 = sanitize(string);
      if (var1.isEmpty()) {
         return false;
      } else {
         SwapHelper.HwidGen.Module_j();
         Path var2 = c();
         Path var3 = KeyFile().resolve(var1 + ".txt");

         try {
            Files.copy(var2, var3, StandardCopyOption.REPLACE_EXISTING);
            return true;
         } catch (IOException var5) {
            return false;
         }
      }
   }

   public static boolean SwapHelper(String string) {
      Path var1 = KeyFile().resolve(sanitize(string) + ".txt");
      return !Files.isRegularFile(var1) ? false : HwidGen(var1);
   }

   public static boolean Module_j(String string) {
      try {
         return Files.deleteIfExists(KeyFile().resolve(sanitize(string) + ".txt"));
      } catch (IOException var2) {
         return false;
      }
   }

   public static String Module_AutoTotem() {
      try {
         SwapHelper.HwidGen.Module_j();
         byte[] var0 = Files.readAllBytes(c());
         return "XCFG-" + Base64.getUrlEncoder().withoutPadding().encodeToString(var0);
      } catch (IOException var1) {
         return null;
      }
   }

   public static boolean Module_ActiveModules(String string) {
      if (string == null) {
         return false;
      } else {
         String var1 = string.trim();
         if (var1.startsWith("XCFG-")) {
            var1 = var1.substring(5);
         }

         try {
            byte[] var2 = Base64.getUrlDecoder().decode(var1);
            Path var3 = KeyFile().resolve(".__shared_tmp.txt");
            Files.write(var3, var2);
            boolean var4 = HwidGen(var3);

            try {
               Files.deleteIfExists(var3);
            } catch (IOException var6) {
            }

            return var4;
         } catch (IOException | IllegalArgumentException var7) {
            return false;
         }
      }
   }

   private static boolean HwidGen(Path path) {
      Map var1 = HwidGen();

      try {
         Files.copy(path, c(), StandardCopyOption.REPLACE_EXISTING);
      } catch (IOException var9) {
         return false;
      }

      SwapHelper.HwidGen.Module_ActiveModules();
      Map var2 = HwidGen();

      for (Module var4 : SwapHelper.HwidGen.KeyFile()) {
         boolean var5 = var1.getOrDefault(var4.c(), false);
         boolean var6 = var2.getOrDefault(var4.c(), false);
         if (var5 != var6) {
            try {
               if (var6) {
                  var4.LicenseState();
               } else {
                  var4.Module_f();
               }
            } catch (Throwable var8) {
            }
         }
      }

      SwapHelper.HwidGen.Module_j();
      return true;
   }

   private static Map HwidGen() {
      HashMap var0 = new HashMap();

      for (Module var2 : SwapHelper.HwidGen.KeyFile()) {
         var0.put(var2.c(), var2.HwidGen());
      }

      return var0;
   }

   public static String Module_DoubleAnchor() {
      try {
         return MinecraftClient.getInstance().keyboard.getClipboard();
      } catch (Throwable var1) {
         return "";
      }
   }

   public static void HudElement(String string) {
      try {
         MinecraftClient.getInstance().keyboard.setClipboard(string == null ? "" : string);
      } catch (Throwable var2) {
      }
   }
}
